# 🎯 IRIS/EYE MODEL COMBINATION - FINAL SUMMARY

## What You Asked For

Combine the 4 iris/eye recognition models (resnet50, efficientnet_b4, densenet121, vit_b_16) for EACH algorithm using weights:

```
W(method) = w1×model1 + w2×model2 + w3×model3 + w4×model4
```

Where w1 + w2 + w3 + w4 = 1.0

## ✅ What Was Delivered

### 📊 Main Result File (RECOMMENDED): 
**[iris_combined_algorithms_equal_weights.csv](computer:///mnt/user-data/outputs/iris_combined_algorithms_equal_weights.csv)**

This file has **6 rows** (one per algorithm):

| Algorithm | Accuracy | Precision | Recall | F1Score | FAR   | FRR   | EER   |
|-----------|----------|-----------|--------|---------|-------|-------|-------|
| IoM-GRP   | **0.9611** | **0.9124** | **0.9352** | **0.9236** | 0.0507 | **0.0271** | **0.0389** |
| RP-PCA    | 0.9441   | 0.9034    | 0.8802 | 0.8914  | **0.0437** | 0.0681 | 0.0559 |
| BioHash   | 0.9419   | 0.8938    | 0.8813 | 0.8874  | 0.0514 | 0.0647 | 0.0581 |
| MLP       | 0.9413   | 0.8916    | 0.8807 | 0.8853  | 0.0529 | 0.0644 | 0.0587 |
| Bloom     | 0.9384   | 0.8787    | 0.8834 | 0.8810  | 0.0640 | 0.0592 | 0.0616 |
| IoM-URP   | 0.9336   | 0.8783    | 0.8656 | 0.8714  | 0.0595 | 0.0732 | 0.0664 |

---

## 🔢 Weighting Strategy Used

### Equal Weights (25% each) ⭐

```
For each algorithm (e.g., IoM-GRP):
  For each metric (e.g., Accuracy):
    
    Combined_Accuracy = 
      resnet50_Accuracy × 0.25 +
      efficientnet_b4_Accuracy × 0.25 +
      densenet121_Accuracy × 0.25 +
      vit_b_16_Accuracy × 0.25
```

### Example Calculation - IoM-GRP Accuracy:
```
Input data:
  resnet50 + IoM-GRP:        0.9695
  efficientnet_b4 + IoM-GRP: 0.9552
  densenet121 + IoM-GRP:     0.9686
  vit_b_16 + IoM-GRP:        0.9510

Calculation:
  Combined = 0.9695 × 0.25 + 0.9552 × 0.25 + 0.9686 × 0.25 + 0.9510 × 0.25
           = 0.2424 + 0.2388 + 0.2422 + 0.2378
           = 0.9611 ✓
```

### Why Equal Weights?

- All four models have similar average F1 scores (~0.89)
- No single model dominates across all algorithms
- Equal weighting is the most balanced and defensible approach
- Simpler to explain in your thesis

---

## 🏆 Winner: IoM-GRP Algorithm

**Performance:**
- ✅ Accuracy: **96.11%** (HIGHEST)
- ✅ F1 Score: **92.36%** (HIGHEST)
- ✅ FAR: 5.07% (very good)
- ✅ FRR: **2.71%** (BEST - lowest false rejections)
- ✅ EER: **3.89%** (BEST - most balanced)

**Why IoM-GRP wins:**
1. Highest accuracy (96.11%)
2. Highest F1 score (92.36%)
3. Lowest FRR (2.71%) - best usability
4. Balanced FAR-FRR trade-off (EER = 3.89%)
5. Consistent performance across all models

**Runner-up: RP-PCA**
- Accuracy: 94.41% (2nd place)
- **Lowest FAR: 4.37%** (best security)
- Good alternative if security is priority over accuracy

---

## 📊 Complete Algorithm Rankings

| Rank | Algorithm | Accuracy | F1 Score | FAR   | FRR   | EER   |
|------|-----------|----------|----------|-------|-------|-------|
| 🥇 1 | **IoM-GRP**   | **96.11%** | **92.36%** | 5.07% | **2.71%** | **3.89%** |
| 🥈 2 | RP-PCA    | 94.41%   | 89.14%   | **4.37%** | 6.81% | 5.59% |
| 🥉 3 | BioHash   | 94.19%   | 88.74%   | 5.14% | 6.47% | 5.81% |
| 4th  | MLP       | 94.13%   | 88.53%   | 5.29% | 6.44% | 5.87% |
| 5th  | Bloom     | 93.84%   | 88.10%   | 6.40% | 5.92% | 6.16% |
| 6th  | IoM-URP   | 93.36%   | 87.14%   | 5.95% | 7.32% | 6.64% |

---

## 📁 All Generated Files

### Main Results (6 rows each):
1. ⭐ **iris_combined_algorithms_equal_weights.csv** - Equal 25% weights (RECOMMENDED)
2. **iris_combined_algorithms_performance_weights.csv** - Performance-based (~25% each)
3. **iris_combined_algorithms_custom_weights.csv** - Custom example (40%, 30%, 20%, 10%)

### Visualizations:
4. **iris_algorithm_ranking.png** - Side-by-side ranking
5. **iris_algorithm_comparison_bar_charts.png** - 4-panel comparison
6. **iris_algorithm_far_vs_frr.png** - Security trade-off analysis

---

## 🔍 Key Differences from Face Results

### Face Recognition Results:
- **Winner**: BioHash (95% accuracy)
- All 3 models (insightface, arcface, facenet) gave **identical** results
- Clear winner with significant margin

### Iris Recognition Results:
- **Winner**: IoM-GRP (96.11% accuracy)
- 4 models show **varying** performance across algorithms
- IoM-GRP has best accuracy but RP-PCA has best security (lowest FAR)
- More nuanced trade-offs between algorithms

---

## 💡 Key Insights

### 1. Model Variation
Unlike face models, iris models show **different performance** for each algorithm:
- densenet121 often performs best
- vit_b_16 shows more variability
- resnet50 and efficientnet_b4 are balanced

### 2. Algorithm Performance
- **IoM-GRP**: Best overall (96.11% accuracy, 2.71% FRR)
- **RP-PCA**: Best security (4.37% FAR)
- **BioHash**: Good balance (94.19% accuracy)
- **IoM-URP**: Weakest performer (93.36% accuracy)

### 3. Trade-offs
- **For highest accuracy**: Choose IoM-GRP
- **For best security (lowest FAR)**: Choose RP-PCA
- **For best usability (lowest FRR)**: Choose IoM-GRP
- **For balance**: Choose BioHash or MLP

---

## 🎓 For Your BTP Thesis

### In Your Methodology Section:

"For iris recognition, we employed ensemble averaging across four deep learning models (ResNet-50, EfficientNet-B4, DenseNet-121, and ViT-B/16). Each cancelable biometric algorithm's performance was computed as:

**M_combined = Σ(w_i × M_i)**, where i ∈ {ResNet-50, EfficientNet-B4, DenseNet-121, ViT-B/16}

Equal weighting (w_i = 0.25) was used to ensure balanced contribution from all models. This approach yielded six consolidated algorithm configurations for comparative analysis."

### In Your Results Section:

**Table Title:** "Performance Comparison of Iris-Based Cancelable Biometric Algorithms (Model-Averaged)"

Use the table from `iris_combined_algorithms_equal_weights.csv`

### In Your Discussion:

"The ensemble averaging approach for iris recognition revealed IoM-GRP as the optimal algorithm, achieving 96.11% accuracy with exceptional usability (FRR = 2.71%). While RP-PCA demonstrated superior security (FAR = 4.37%), IoM-GRP offers the best overall balance with an Equal Error Rate of 3.89%, making it the recommended algorithm for iris-based cancelable biometric systems."

---

## 🔬 Comparison: Face vs Iris Results

| Metric | Face (BioHash Winner) | Iris (IoM-GRP Winner) |
|--------|----------------------|----------------------|
| **Accuracy** | 95.0% | **96.11%** ✓ |
| **F1 Score** | 95.0% | 92.36% |
| **FAR** | 5.0% | 5.07% |
| **FRR** | 6.0% | **2.71%** ✓ |
| **Models Combined** | 3 (identical results) | 4 (varying results) |
| **Weight Strategy** | Equal (33.33% each) | Equal (25% each) |

**Key Observation**: 
- Iris recognition (IoM-GRP) achieves **higher accuracy** than face (BioHash)
- Iris has **much lower FRR** (2.71% vs 6.0%) - better usability
- Face has more **model consistency**, iris shows more **model variation**

---

## 🚀 Recommendations

### For Production Deployment:

1. **Primary Choice: IoM-GRP**
   - Best accuracy (96.11%)
   - Best usability (FRR = 2.71%)
   - Good security (FAR = 5.07%)

2. **Security-Focused: RP-PCA**
   - Best security (FAR = 4.37%)
   - Still good accuracy (94.41%)

3. **Balanced Option: BioHash**
   - Good accuracy (94.19%)
   - Balanced FAR/FRR
   - Well-established in literature

### For Your Thesis:

1. ✅ Use `iris_combined_algorithms_equal_weights.csv` as main results table
2. ✅ Show `iris_algorithm_comparison_bar_charts.png` for visual comparison
3. ✅ Highlight IoM-GRP as winner with 96.11% accuracy
4. ✅ Compare with face recognition results (BioHash vs IoM-GRP)
5. ✅ Discuss modality-specific performance (iris > face for accuracy)

---

## 🔧 How to Modify Weights

If you want to give more weight to better-performing models:

```python
# densenet121 performs best, so give it more weight
custom_weights = {
    'densenet121': 0.4,      # 40% - best performer
    'resnet50': 0.3,         # 30% - consistent
    'efficientnet_b4': 0.2,  # 20% - good
    'vit_b_16': 0.1          # 10% - most variable
}
```

This is provided in `iris_combined_algorithms_custom_weights.csv`

---

## ✨ Summary

✅ **Reduced 24 rows → 6 rows** (cleaner, more interpretable)  
✅ **Each algorithm has single consolidated score**  
✅ **IoM-GRP is the clear winner** (96.11% accuracy, 2.71% FRR)  
✅ **Equal weighting justified** (balanced model contribution)  
✅ **Iris outperforms face** (96.11% vs 95% accuracy)  
✅ **Publication-ready results and visualizations**

---

## 📦 Quick Access Links

**Main Result File**: [iris_combined_algorithms_equal_weights.csv](computer:///mnt/user-data/outputs/iris_combined_algorithms_equal_weights.csv)

**Visualizations**:
- [Algorithm Rankings](computer:///mnt/user-data/outputs/iris_algorithm_ranking.png)
- [Performance Comparison](computer:///mnt/user-data/outputs/iris_algorithm_comparison_bar_charts.png)
- [FAR vs FRR Analysis](computer:///mnt/user-data/outputs/iris_algorithm_far_vs_frr.png)

---

## 🎉 Conclusion

You now have:
- ✅ A clean 6-row CSV with combined iris algorithm results
- ✅ Clear winner: **IoM-GRP at 96.11% accuracy**
- ✅ Justified weighting methodology (equal weights)
- ✅ Publication-quality visualizations
- ✅ Complete comparison with face recognition results

**Bottom Line**: 
- **For face recognition**: Use BioHash (95% accuracy)
- **For iris recognition**: Use IoM-GRP (96.11% accuracy, 2.71% FRR)
- **Overall best performance**: Iris with IoM-GRP! 🏆

Good luck with your BTP! 🚀
