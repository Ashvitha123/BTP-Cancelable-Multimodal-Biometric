#!/usr/bin/env python3
"""Train Iris Models on IITD Database - FIXED VERSION"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import os
import numpy as np
import cv2
from pathlib import Path
import json
from datetime import datetime
import logging

from iris_models import create_model, get_model_info

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class IrisDataset(Dataset):
    """IITD Iris Dataset"""
    
    def __init__(self, dataset_path='dataset', input_size=224):
        self.dataset_path = dataset_path
        self.input_size = input_size
        self.images = []
        self.labels = []
        self.user_id_map = {}
        self.next_label = 0
        
        for user_id in sorted(os.listdir(dataset_path)):
            user_path = os.path.join(dataset_path, user_id)
            if not os.path.isdir(user_path):
                continue
            
            try:
                # Map user_id to sequential label (0, 1, 2, ...)
                user_int = int(user_id)
                if user_int not in self.user_id_map:
                    self.user_id_map[user_int] = self.next_label
                    self.next_label += 1
                user_label = self.user_id_map[user_int]
            except ValueError:
                # Skip non-numeric folders
                continue
            
            for img_name in os.listdir(user_path):
                if img_name.lower().endswith(('.bmp', '.jpg', '.jpeg', '.png')):
                    img_path = os.path.join(user_path, img_name)
                    self.images.append(img_path)
                    self.labels.append(user_label)
        
        self.num_users = len(self.user_id_map)
        logger.info(f"Loaded {len(self.images)} iris images from {self.num_users} users")
    
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        img_path = self.images[idx]
        label = self.labels[idx]
        
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            return None
        
        img = cv2.resize(img, (self.input_size, self.input_size))
        img = img.astype(np.float32) / 255.0
        img = np.expand_dims(img, axis=0)
        
        return {
            'image': torch.from_numpy(img),
            'label': torch.tensor(label, dtype=torch.long),
            'path': img_path
        }


def collate_fn(batch):
    batch = [item for item in batch if item is not None]
    if not batch:
        return None
    
    return {
        'image': torch.stack([item['image'] for item in batch]),
        'label': torch.stack([item['label'] for item in batch]),
        'path': [item['path'] for item in batch]
    }


def train_epoch(model, dataloader, criterion, optimizer, device, num_classes):
    model.train()
    total_loss = 0
    correct = 0
    total = 0
    
    for batch_idx, batch in enumerate(dataloader):
        if batch is None:
            continue
        
        images = batch['image'].to(device)
        labels = batch['label'].to(device)
        
        embeddings = model(images)
        
        # Create dynamic classifier
        classifier = nn.Linear(embeddings.shape[1], num_classes).to(device)
        logits = classifier(embeddings)
        loss = criterion(logits, labels)
        
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
        _, predicted = logits.max(1)
        correct += predicted.eq(labels).sum().item()
        total += labels.size(0)
        
        if (batch_idx + 1) % 10 == 0:
            logger.info(f"Batch {batch_idx+1}: Loss={loss.item():.4f}, Acc={100.*correct/total:.2f}%")
    
    return total_loss / (batch_idx + 1) if batch_idx >= 0 else 0, correct / total


def train_model(model_name, num_epochs=20, batch_size=32, learning_rate=0.001):
    logger.info(f"\n{'='*70}\nTraining {model_name.upper()}\n{'='*70}\n")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logger.info(f"Using device: {device}")
    
    dataset = IrisDataset('dataset')
    num_classes = dataset.num_users
    
    logger.info(f"Number of classes (users): {num_classes}")
    
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, collate_fn=collate_fn)
    
    model = create_model(model_name).to(device)
    logger.info(f"Model created: {model_name}")
    
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=3)
    
    history = {'train_loss': [], 'train_acc': []}
    
    for epoch in range(num_epochs):
        logger.info(f"\nEpoch {epoch+1}/{num_epochs}")
        train_loss, train_acc = train_epoch(model, dataloader, criterion, optimizer, device, num_classes)
        history['train_loss'].append(train_loss)
        history['train_acc'].append(train_acc)
        logger.info(f"Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.4f}")
    
    model_dir = 'pretrained_models'
    os.makedirs(model_dir, exist_ok=True)
    model_path = os.path.join(model_dir, f'{model_name}_iitd.pth')
    torch.save(model.state_dict(), model_path)
    logger.info(f"\nModel saved to {model_path}")
    
    return model, history, num_classes


def train_all_models(num_epochs=5, batch_size=32):
    models_info = get_model_info()
    results = {}
    
    for model_name in ['irisnet', 'depiris', 'irisconvnet']:
        try:
            model, history, num_classes = train_model(model_name, num_epochs, batch_size)
            results[model_name] = {
                'status': 'success',
                'final_loss': history['train_loss'][-1],
                'final_acc': history['train_acc'][-1],
                'num_classes': num_classes,
            }
        except Exception as e:
            logger.error(f"Failed to train {model_name}: {e}")
            results[model_name] = {'status': 'failed', 'error': str(e)}
    
    logger.info(f"\n{'='*70}\nTraining Summary\n{'='*70}")
    for model_name, result in results.items():
        if result['status'] == 'success':
            logger.info(f"{model_name:15} - Loss: {result['final_loss']:.4f}, Acc: {result['final_acc']:.4f}, Classes: {result['num_classes']}")
        else:
            logger.info(f"{model_name:15} - FAILED: {result['error']}")


if __name__ == '__main__':
    train_all_models(num_epochs=5, batch_size=32)