#!/usr/bin/env python3
"""
Auto-verify all iris users using IOM-URP scheme
Tests all enrolled users automatically
"""

import os
import joblib
import numpy as np
from extract_embedding_iris import extract_iris_embedding
from iom_urp_hash import ION_URP

TEMPLATE_DIR = 'templates_iris'
DATASET_DIR = 'dataset'

def verify_iom_urp_iris_auto(threshold=0.271):
    """Auto-verify all users by testing against their own templates"""
    
    results = {
        'total_users': 0,
        'successful_verifications': 0,
        'failed_verifications': 0,
        'distances': [],
        'threshold': threshold
    }
    
    user_folders = sorted([d for d in os.listdir(DATASET_DIR) 
                          if os.path.isdir(os.path.join(DATASET_DIR, d))])
    
    if len(user_folders) == 0:
        print("❌ No user folders found!")
        return results
    
    print(f"\n{'='*70}")
    print(f"AUTO-VERIFYING {len(user_folders)} USERS WITH IOM-URP")
    print(f"Threshold: {threshold}")
    print(f"{'='*70}\n")
    
    iom_urp = ION_URP()
    
    for user_id in user_folders:
        results['total_users'] += 1
        
        # Check template exists
        template_path = os.path.join(TEMPLATE_DIR, f'iom_urp_iris_{user_id}.pkl')
        
        if not os.path.exists(template_path):
            print(f"[IOM-URP-IRIS:{user_id}] ✗ Template not found")
            results['failed_verifications'] += 1
            continue
        
        # Load template
        try:
            template = joblib.load(template_path)
        except Exception as e:
            print(f"[IOM-URP-IRIS:{user_id}] ✗ Error loading template: {e}")
            results['failed_verifications'] += 1
            continue
        
        # Get first iris image for verification
        dataset_path = os.path.join(DATASET_DIR, user_id)
        iris_files = sorted([f for f in os.listdir(dataset_path) 
                            if f.lower().endswith(('.bmp', '.jpg', '.jpeg', '.png'))])
        
        if len(iris_files) == 0:
            print(f"[IOM-URP-IRIS:{user_id}] ✗ No iris images found")
            results['failed_verifications'] += 1
            continue
        
        # Use first image as probe
        probe_path = os.path.join(dataset_path, iris_files[0])
        
        try:
            # Extract probe embedding
            emb = extract_iris_embedding(probe_path)
            if emb is None:
                print(f"[IOM-URP-IRIS:{user_id}] ✗ No iris detected in probe")
                results['failed_verifications'] += 1
                continue
            
            # Compare using IOM-URP with reference_id
            distance = iom_urp.compare(template, emb, reference_id=user_id)
            results['distances'].append(distance)
            
            match = distance < threshold
            
            if match:
                print(f"[IOM-URP-IRIS:{user_id}] ✓ VERIFIED (Distance: {distance:.3f})")
                results['successful_verifications'] += 1
            else:
                print(f"[IOM-URP-IRIS:{user_id}] ✗ REJECTED (Distance: {distance:.3f})")
                results['failed_verifications'] += 1
        
        except Exception as e:
            print(f"[IOM-URP-IRIS:{user_id}] ✗ Error: {e}")
            results['failed_verifications'] += 1
    
    # Print summary
    print(f"\n{'='*70}")
    print("VERIFICATION SUMMARY - IOM-URP")
    print(f"{'='*70}")
    print(f"Threshold used: {threshold}")
    print(f"Total users tested: {results['total_users']}")
    print(f"✓ Verified: {results['successful_verifications']}")
    print(f"✗ Rejected: {results['failed_verifications']}")
    
    if results['total_users'] > 0:
        verification_rate = (results['successful_verifications'] / results['total_users']) * 100
        print(f"Verification Rate: {verification_rate:.1f}%")
    
    if results['distances']:
        print(f"\nDistance Statistics:")
        print(f"  Min: {min(results['distances']):.3f}")
        print(f"  Max: {max(results['distances']):.3f}")
        print(f"  Avg: {np.mean(results['distances']):.3f}")
        print(f"  Std: {np.std(results['distances']):.3f}")
        
        # Suggest optimal threshold
        mean_dist = np.mean(results['distances'])
        std_dist = np.std(results['distances'])
        optimal_threshold = mean_dist + std_dist
        print(f"\n💡 Suggested optimal threshold: {optimal_threshold:.3f}")
    
    print(f"{'='*70}\n")
    
    return results


if __name__ == '__main__':
    import sys
    threshold = 0.271
    if len(sys.argv) > 1:
        try:
            threshold = float(sys.argv[1])
        except:
            pass
    verify_iom_urp_iris_auto(threshold=threshold)