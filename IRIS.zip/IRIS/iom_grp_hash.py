#!/usr/bin/env python3
"""
IOM-GRP (Index-of-Max Gammatone Random Projection)

Cancelable biometric template protection using Gaussian random projections and index selection.
Encodes the index of maximum projection for each group.
"""

import numpy as np
import hashlib

class ION_GRP:
    """IoM-GRP transformer for biometric template protection."""
    
    def __init__(self, m=600, k=8, seed_offset=0):
        """
        Initialize IoM-GRP.
        
        Args:
            m: Number of hash groups (output length)
            k: Number of projections per group
            seed_offset: Seed offset
        """
        self.m = m
        self.k = k
        self.seed_offset = seed_offset
    
    def generate_user_seed(self, reference_id):
        """Generate deterministic seed from reference ID."""
        h = hashlib.sha256(reference_id.encode('utf-8')).hexdigest()
        seed = self.seed_offset + int(h, 16) % (10**8)
        return seed
    
    def generate_template(self, feature_vector, reference_id=None):
        """
        Create IoM-GRP protected template.
        
        Args:
            feature_vector: Input embedding
            reference_id: User-specific identifier
        
        Returns:
            Protected template (integer indices)
        """
        if reference_id is None:
            seed = self.seed_offset
        else:
            seed = self.generate_user_seed(reference_id)
        
        np.random.seed(seed)
        
        d = feature_vector.shape[0]
        
        # Generate Gaussian random projection matrix (d x m*k)
        R = np.random.randn(d, self.m * self.k)
        
        # Normalize each column
        R = R / np.linalg.norm(R, axis=0, keepdims=True)
        
        # Split into m groups of k projections each
        indices = []
        for i in range(self.m):
            R_i = R[:, i*self.k:(i+1)*self.k]
            proj = np.dot(feature_vector, R_i)
            idx = np.argmax(proj)
            indices.append(idx)
        
        return np.array(indices, dtype=np.uint8)
    
    def compare(self, template1, feature_vector2, reference_id=None):
        """
        Compare template with features from another embedding.
        
        Args:
            template1: First template (index-of-max codes)
            feature_vector2: Second feature vector
            reference_id: User reference
        
        Returns:
            Similarity/distance metric
        """
        # Generate template for second feature
        template2 = self.generate_template(feature_vector2, reference_id)
        
        # Compute Hamming similarity
        matches = np.sum(template1 == template2)
        similarity = matches / len(template1)
        
        return 1.0 - similarity  # Return distance
    
    def hamming_similarity(self, hash1, hash2):
        """Compute Hamming similarity between two hashes."""
        if len(hash1) != len(hash2):
            raise ValueError("Hashes must have same length")
        matches = np.sum(hash1 == hash2)
        return matches / len(hash1)
    
    def get_hash_statistics(self, hash_code):
        """Get statistics for IoM-GRP hash."""
        unique, counts = np.unique(hash_code, return_counts=True)
        probabilities = counts / len(hash_code)
        entropy = -np.sum(probabilities * np.log2(probabilities + 1e-10))
        
        return {
            'entropy': entropy,
            'unique_values': len(unique),
            'max_value': np.max(hash_code),
            'min_value': np.min(hash_code),
            'mean': np.mean(hash_code),
            'std': np.std(hash_code)
        }


if __name__ == '__main__':
    print("IoM-GRP Hash module loaded")
