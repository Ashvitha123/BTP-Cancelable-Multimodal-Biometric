#!/usr/bin/env python3
"""
BioHash (Biometric Hashing)

Cancelable biometric template protection using random projections and user-specific tokens.
Combines biometric features with user-specific randomness for security.
"""

import numpy as np
import hashlib
from typing import Optional, Tuple

class BioHash:
    """BioHash transformer for biometric template protection."""
    
    def __init__(self, hash_length=1024, seed_offset=1000, threshold_method='adaptive', normalize_input=True):
        """
        Initialize BioHash parameters.
        
        Args:
            hash_length: Length of binary hash code
            seed_offset: Offset for user seed generation
            threshold_method: 'adaptive', 'zero', or 'mean'
            normalize_input: Whether to L2-normalize input
        """
        self.hash_length = hash_length
        self.seed_offset = seed_offset
        self.threshold_method = threshold_method
        self.normalize_input = normalize_input
    
    def generate_user_seed(self, reference_id: str) -> int:
        """Generate user-specific seed from reference ID."""
        h = hashlib.sha256(reference_id.encode('utf-8')).hexdigest()
        seed = self.seed_offset + int(h, 16) % (10**8)
        return seed
    
    def generate_random_projections(self, feature_dim: int, reference_id: str = None) -> np.ndarray:
        """Generate user-specific random projection matrix."""
        if reference_id is None:
            seed = self.seed_offset
        else:
            seed = self.generate_user_seed(reference_id)
        
        np.random.seed(seed)
        
        # Generate Gaussian random projection matrix
        R = np.random.randn(feature_dim, self.hash_length)
        
        # Normalize each projection vector
        R = R / np.linalg.norm(R, axis=0, keepdims=True)
        
        return R
    
    def compute_threshold(self, projections: np.ndarray, method: str = None) -> float:
        """Compute binarization threshold."""
        if method is None:
            method = self.threshold_method
        
        if method == 'zero':
            return 0.0
        elif method == 'mean':
            return np.mean(projections)
        elif method == 'adaptive':
            return np.median(projections)
        else:
            raise ValueError(f"Unknown threshold method: {method}")
    
    def generate(self, feature_vector: np.ndarray, reference_id: str = None) -> np.ndarray:
        """
        Create BioHash from feature vector.
        
        Args:
            feature_vector: Input biometric embedding
            reference_id: User reference identifier
        
        Returns:
            Binary BioHash code
        """
        # Normalize input if requested
        if self.normalize_input:
            norm = np.linalg.norm(feature_vector)
            if norm > 0:
                feature_vector = feature_vector / norm
        
        # Generate random projection matrix
        R = self.generate_random_projections(len(feature_vector), reference_id)
        
        # Project features
        projections = feature_vector @ R
        
        # Compute threshold
        threshold = self.compute_threshold(projections)
        
        # Binarize
        bio_hash = (projections > threshold).astype(np.uint8)
        
        return bio_hash
    
    def hamming_distance(self, hash1: np.ndarray, hash2: np.ndarray) -> float:
        """Compute normalized Hamming distance."""
        if len(hash1) != len(hash2):
            raise ValueError("Hashes must have same length")
        return np.count_nonzero(hash1 != hash2) / len(hash1)
    
    def compare(self, hash1: np.ndarray, hash2: np.ndarray) -> float:
        """Compute Hamming distance (for compatibility)."""
        return self.hamming_distance(hash1, hash2)
    
    def hamming_similarity(self, hash1: np.ndarray, hash2: np.ndarray) -> float:
        """Compute Hamming similarity (0 to 1)."""
        return 1.0 - self.hamming_distance(hash1, hash2)


if __name__ == '__main__':
    print("BioHash module loaded")
