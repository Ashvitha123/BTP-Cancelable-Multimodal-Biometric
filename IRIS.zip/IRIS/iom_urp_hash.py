#!/usr/bin/env python3
"""
IOM-URP (Index-of-Max User-specific Random Permutation)

Cancelable biometric template protection using user-specific random permutations and index selection.
Applies random permutations and encodes index of maximum value in each permuted window.
"""

import numpy as np
import hashlib

class ION_URP:
    """IoM-URP transformer for biometric template protection."""
    
    def __init__(self, m=600, k=8, seed_offset=0):
        """
        Initialize IoM-URP.
        
        Args:
            m: Number of hash groups (output length)
            k: Window size for index selection
            seed_offset: Seed offset
        """
        self.m = m
        self.k = k
        self.seed_offset = seed_offset
    
    def generate_user_seed(self, reference_id):
        """Generate deterministic seed from reference ID."""
        h = hashlib.sha256(reference_id.encode('utf-8')).hexdigest()
        seed = self.seed_offset + int(h, 16) % (10**8)
        return seed
    
    def generate_template(self, feature_vector, reference_id=None):
        """
        Create IoM-URP protected template.
        
        Args:
            feature_vector: Input embedding
            reference_id: User-specific identifier
        
        Returns:
            Protected template (integer indices)
        """
        if reference_id is None:
            seed = self.seed_offset
        else:
            seed = self.generate_user_seed(reference_id)
        
        np.random.seed(seed)
        
        d = feature_vector.shape[0]
        
        # Generate m different permutations
        indices = []
        for _ in range(self.m):
            perm = np.random.permutation(d)
            subset = feature_vector[perm[:self.k]]
            idx = np.argmax(subset)
            indices.append(idx)
        
        return np.array(indices, dtype=np.uint8)
    
    def compare(self, template1, feature_vector2, reference_id=None):
        """
        Compare template with features from another embedding.
        
        Args:
            template1: First template (index-of-max codes)
            feature_vector2: Second feature vector
            reference_id: User reference
        
        Returns:
            Similarity/distance metric
        """
        # Generate template for second feature
        template2 = self.generate_template(feature_vector2, reference_id)
        
        # Compute Hamming similarity
        matches = np.sum(template1 == template2)
        similarity = matches / len(template1)
        
        return 1.0 - similarity  # Return distance
    
    def hamming_similarity(self, hash1, hash2):
        """Compute Hamming similarity between two hashes."""
        if len(hash1) != len(hash2):
            raise ValueError("Hashes must have same length")
        matches = np.sum(hash1 == hash2)
        return matches / len(hash1)
    
    def get_hash_statistics(self, hash_code):
        """Get statistics for IoM-URP hash."""
        unique, counts = np.unique(hash_code, return_counts=True)
        probabilities = counts / len(hash_code)
        entropy = -np.sum(probabilities * np.log2(probabilities + 1e-10))
        
        return {
            'entropy': entropy,
            'unique_values': len(unique),
            'max_value': np.max(hash_code),
            'min_value': np.min(hash_code),
            'mean': np.mean(hash_code),
            'std': np.std(hash_code)
        }


if __name__ == '__main__':
    print("IoM-URP Hash module loaded")
