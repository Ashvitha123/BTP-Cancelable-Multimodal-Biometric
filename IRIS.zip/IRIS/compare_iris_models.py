#!/usr/bin/env python3
"""Compare All 4 Iris Models"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
import numpy as np
import cv2
import os
import csv
import time
import json
from datetime import datetime
import logging

from iris_models import create_model, get_model_info

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class IrisDataset(Dataset):
    def __init__(self, dataset_path='dataset', input_size=224):
        self.dataset_path = dataset_path
        self.input_size = input_size
        self.images = []
        self.labels = []
        self.user_ids = []
        
        for user_id in sorted(os.listdir(dataset_path)):
            user_path = os.path.join(dataset_path, user_id)
            if not os.path.isdir(user_path):
                continue
            
            for img_name in os.listdir(user_path):
                if img_name.lower().endswith(('.bmp', '.jpg', '.jpeg', '.png')):
                    img_path = os.path.join(user_path, img_name)
                    self.images.append(img_path)
                    self.labels.append(int(user_id))
                    self.user_ids.append(user_id)
    
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        img_path = self.images[idx]
        label = self.labels[idx]
        
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            return None
        
        img = cv2.resize(img, (self.input_size, self.input_size))
        img = img.astype(np.float32) / 255.0
        img = np.expand_dims(img, axis=0)
        
        return {
            'image': torch.from_numpy(img),
            'label': torch.tensor(label, dtype=torch.long),
            'user_id': self.user_ids[idx],
            'path': img_path
        }


def collate_fn(batch):
    batch = [item for item in batch if item is not None]
    if not batch:
        return None
    return {
        'image': torch.stack([item['image'] for item in batch]),
        'label': torch.stack([item['label'] for item in batch]),
        'user_id': [item['user_id'] for item in batch],
        'path': [item['path'] for item in batch]
    }


def extract_embeddings(model, dataloader, device):
    model.eval()
    embeddings = []
    labels = []
    
    with torch.no_grad():
        for batch in dataloader:
            if batch is None:
                continue
            images = batch['image'].to(device)
            batch_labels = batch['label']
            emb = model(images)
            embeddings.append(emb.cpu())
            labels.append(batch_labels)
    
    embeddings = torch.cat(embeddings, dim=0)
    labels = torch.cat(labels, dim=0)
    return embeddings, labels


def rank_1_accuracy(embeddings, labels):
    distances = torch.cdist(embeddings, embeddings, p=2)
    correct = 0
    for i in range(len(embeddings)):
        sorted_indices = torch.argsort(distances[i])
        for j in sorted_indices[1:]:
            if labels[i] == labels[j]:
                correct += 1
                break
    return correct / len(embeddings)


def rank_5_accuracy(embeddings, labels):
    distances = torch.cdist(embeddings, embeddings, p=2)
    correct = 0
    for i in range(len(embeddings)):
        sorted_indices = torch.argsort(distances[i])
        top_5 = sorted_indices[1:6]
        if any(labels[i] == labels[j] for j in top_5):
            correct += 1
    return correct / len(embeddings)


def equal_error_rate(embeddings, labels):
    distances = torch.cdist(embeddings, embeddings, p=2)
    genuine_distances = []
    impostor_distances = []
    
    for i in range(len(embeddings)):
        for j in range(i+1, len(embeddings)):
            dist = distances[i, j].item()
            if labels[i] == labels[j]:
                genuine_distances.append(dist)
            else:
                impostor_distances.append(dist)
    
    genuine_distances = np.array(genuine_distances)
    impostor_distances = np.array(impostor_distances)
    
    thresholds = np.linspace(0, max(genuine_distances.max(), impostor_distances.max()), 1000)
    min_diff = float('inf')
    eer = 0
    
    for threshold in thresholds:
        far = (impostor_distances < threshold).sum() / len(impostor_distances)
        frr = (genuine_distances >= threshold).sum() / len(genuine_distances)
        if abs(far - frr) < min_diff:
            min_diff = abs(far - frr)
            eer = (far + frr) / 2
    
    return eer


def compute_metrics(embeddings, labels):
    metrics = {
        'rank_1': rank_1_accuracy(embeddings, labels),
        'rank_5': rank_5_accuracy(embeddings, labels),
        'eer': equal_error_rate(embeddings, labels),
    }
    return metrics


def evaluate_model(model_name, model_path=None, batch_size=32):
    logger.info(f"\n{'='*70}\nEvaluating {model_name.upper()}\n{'='*70}")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = create_model(model_name).to(device)
    
    if model_path and os.path.exists(model_path):
        try:
            model.load_state_dict(torch.load(model_path, map_location=device))
            logger.info(f"Loaded model from {model_path}")
        except:
            logger.warning("Could not load model weights")
    
    dataset = IrisDataset('dataset')
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=False, collate_fn=collate_fn)
    
    logger.info("Extracting embeddings...")
    start_time = time.time()
    embeddings, labels = extract_embeddings(model, dataloader, device)
    extraction_time = time.time() - start_time
    
    logger.info("Computing metrics...")
    metrics = compute_metrics(embeddings, labels)
    total_params = sum(p.numel() for p in model.parameters())
    
    results = {
        'model': model_name,
        'rank_1_accuracy': metrics['rank_1'],
        'rank_5_accuracy': metrics['rank_5'],
        'eer': metrics['eer'],
        'extraction_time': extraction_time,
        'num_samples': len(embeddings),
        'num_parameters': total_params,
        'avg_time_per_sample': extraction_time / len(embeddings),
    }
    
    logger.info(f"Rank-1 Accuracy: {metrics['rank_1']:.4f}")
    logger.info(f"Rank-5 Accuracy: {metrics['rank_5']:.4f}")
    logger.info(f"EER: {metrics['eer']:.4f}")
    logger.info(f"Total Time: {extraction_time:.2f}s")
    
    return results


def compare_all_models(batch_size=32):
    logger.info(f"\n{'='*70}\nIRIS MODEL COMPARISON ON IITD DATABASE\n{'='*70}\n")
    
    model_names = ['resnet50', 'efficientnet_b4', 'vgg16', 'mobilenet_v2']
    model_info = get_model_info()
    results = []
    
    for model_name in model_names:
        model_path = f'pretrained_models/{model_name}_iitd.pth'
        try:
            result = evaluate_model(model_name, model_path, batch_size)
            results.append(result)
        except Exception as e:
            logger.error(f"Failed to evaluate {model_name}: {e}")
    
    print("\n" + "="*100)
    print("MODEL COMPARISON RESULTS")
    print("="*100)
    print(f"\n{'Model':<15} {'Rank-1 Acc':<12} {'Rank-5 Acc':<12} {'EER':<10} {'Time(ms)':<10} {'Params':<12}")
    print("-"*100)
    
    for result in results:
        model_name = result['model']
        r1 = result['rank_1_accuracy']
        r5 = result['rank_5_accuracy']
        eer = result['eer']
        time_ms = result['avg_time_per_sample'] * 1000
        params = result['num_parameters'] / 1e6
        print(f"{model_name:<15} {r1:.4f}        {r5:.4f}        {eer:.4f}    {time_ms:<8.2f}  {params:.1f}M")
    
    print("="*100 + "\n")
    
    results_dir = 'model_comparison_results'
    os.makedirs(results_dir, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    csv_path = os.path.join(results_dir, f'iris_model_comparison_{timestamp}.csv')
    
    with open(csv_path, 'w', newline='') as f:
        fieldnames = ['Model', 'Rank-1 Accuracy', 'Rank-5 Accuracy', 'EER', 'Avg Time(ms)', 'Parameters']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for result in results:
            writer.writerow({
                'Model': result['model'],
                'Rank-1 Accuracy': f"{result['rank_1_accuracy']:.4f}",
                'Rank-5 Accuracy': f"{result['rank_5_accuracy']:.4f}",
                'EER': f"{result['eer']:.4f}",
                'Avg Time(ms)': f"{result['avg_time_per_sample']*1000:.2f}",
                'Parameters': f"{result['num_parameters']/1e6:.1f}M",
            })
    
    logger.info(f"Results saved to {csv_path}")
    return csv_path


if __name__ == '__main__':
    compare_all_models(batch_size=32)
