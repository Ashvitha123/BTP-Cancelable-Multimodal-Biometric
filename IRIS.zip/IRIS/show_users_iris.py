#!/usr/bin/env python3
"""
List all enrolled iris users across all schemes
Adapted from face project for iris biometric data (IITD database)
"""

import os
import csv
from pathlib import Path
from datetime import datetime

TEMPLATE_DIR = 'templates_iris'
ENROLLMENT_LOG = os.path.join(TEMPLATE_DIR, 'enrollments.csv')

def show_enrolled_users():
    """Display all enrolled users and their scheme status"""
    
    print("\n" + "=" * 80)
    print("  ENROLLED IRIS USERS - BIOMETRIC TEMPLATE PROTECTION SYSTEM")
    print("=" * 80)
    
    # Define schemes
    schemes = ['mlp', 'biohash', 'rppca', 'iom_grp', 'iom_urp', 'bloom']
    scheme_names = {
        'mlp': 'MLP-Hash',
        'biohash': 'BioHash',
        'rppca': 'RP-PCA',
        'iom_grp': 'IOM-GRP',
        'iom_urp': 'IOM-URP',
        'bloom': 'Bloom Filter'
    }
    
    # Scan templates directory
    enrolled = {}
    
    if not os.path.exists(TEMPLATE_DIR):
        print(f"\n✗ Templates directory not found: {TEMPLATE_DIR}\n")
        return
    
    for file in os.listdir(TEMPLATE_DIR):
        if file.endswith(('.bin', '.pkl')):
            # Parse filename to extract scheme and user_id
            parts = file.split('_')
            if len(parts) >= 3:
                user_id = parts[-1].split('.')[0]
                
                for scheme in schemes:
                    if scheme in file:
                        if user_id not in enrolled:
                            enrolled[user_id] = []
                        enrolled[user_id].append(scheme_names[scheme])
                        break
    
    if not enrolled:
        print(f"\n✗ No enrolled users found in {TEMPLATE_DIR}\n")
        return
    
    # Display results
    print(f"\n{'User ID':<12} {'Schemes Enrolled':<60} {'Status':<10}")
    print("-" * 80)
    
    for user_id in sorted(enrolled.keys()):
        schemes_str = ", ".join(sorted(enrolled[user_id]))
        num_schemes = len(enrolled[user_id])
        
        if num_schemes == len(schemes):
            status = "✓ COMPLETE"
        elif num_schemes > 0:
            status = f"⚠ {num_schemes}/6"
        else:
            status = "✗ NONE"
        
        print(f"{user_id:<12} {schemes_str:<60} {status:<10}")
    
    print("-" * 80)
    print(f"Total enrolled users: {len(enrolled)}")
    print(f"Total schemes: {len(schemes)}")
    print(f"Total templates: {sum(len(v) for v in enrolled.values())}")
    print("=" * 80 + "\n")

def export_enrollment_log():
    """Export enrollment log to CSV"""
    
    schemes = ['mlp', 'biohash', 'rppca', 'iom_grp', 'iom_urp', 'bloom']
    
    with open(ENROLLMENT_LOG, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['user_id', 'scheme', 'enrollment_date', 'status'])
        
        if os.path.exists(TEMPLATE_DIR):
            for file in os.listdir(TEMPLATE_DIR):
                if file.endswith(('.bin', '.pkl')):
                    parts = file.split('_')
                    if len(parts) >= 3:
                        user_id = parts[-1].split('.')[0]
                        
                        for scheme in schemes:
                            if scheme in file:
                                file_path = os.path.join(TEMPLATE_DIR, file)
                                mtime = os.path.getmtime(file_path)
                                date = datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M:%S')
                                writer.writerow([user_id, scheme, date, 'enrolled'])
                                break

def get_user_templates(user_id):
    """Get all templates for a specific user"""
    
    templates = {}
    
    if not os.path.exists(TEMPLATE_DIR):
        return templates
    
    schemes = ['mlp', 'biohash', 'rppca', 'iom_grp', 'iom_urp', 'bloom']
    
    for scheme in schemes:
        # Check for binary file
        bin_path = os.path.join(TEMPLATE_DIR, f'{scheme}_iris_{user_id}.bin')
        if os.path.exists(bin_path):
            templates[scheme] = {
                'path': bin_path,
                'size': os.path.getsize(bin_path),
                'date': datetime.fromtimestamp(os.path.getmtime(bin_path))
            }
        
        # Check for pickle file
        pkl_path = os.path.join(TEMPLATE_DIR, f'{scheme}_iris_{user_id}.pkl')
        if os.path.exists(pkl_path):
            templates[scheme] = {
                'path': pkl_path,
                'size': os.path.getsize(pkl_path),
                'date': datetime.fromtimestamp(os.path.getmtime(pkl_path))
            }
    
    return templates

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1] == '--export':
            print("[*] Exporting enrollment log...")
            export_enrollment_log()
            print(f"[✓] Log saved to {ENROLLMENT_LOG}")
        elif sys.argv[1] == '--user':
            if len(sys.argv) > 2:
                user_id = sys.argv[2]
                print(f"\nTemplates for user {user_id}:")
                templates = get_user_templates(user_id)
                for scheme, info in templates.items():
                    print(f"  {scheme}: {info['size']} bytes ({info['date']})")
            else:
                print("Usage: python show_users_iris.py --user <user_id>")
        else:
            print("Usage: python show_users_iris.py [--export] [--user <user_id>]")
    else:
        show_enrolled_users()
