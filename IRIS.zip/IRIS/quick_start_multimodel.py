#!/usr/bin/env python3
"""
Quick Start: Multi-Model Iris Recognition Evaluation
Automates testing of all 4 models
"""

import subprocess
import sys
import time

def run_command(cmd, description):
    """Run a command and show progress"""
    print(f"\n{'='*70}")
    print(f"  {description}")
    print(f"{'='*70}\n")
    
    start_time = time.time()
    result = subprocess.run(cmd, shell=True)
    elapsed = time.time() - start_time
    
    print(f"\n⏱️  Completed in {elapsed:.1f} seconds")
    return result.returncode == 0

def main():
    print("\n" + "="*70)
    print("  MULTI-MODEL IRIS RECOGNITION - QUICK START")
    print("="*70 + "\n")
    
    models = ['resnet50', 'efficientnet_b4', 'densenet121', 'vit_b_16']
    
    print("This script will:")
    print("1. Test all 4 models (ResNet-50, EfficientNet-B4, DenseNet-121, ViT-B/16)")
    print("2. Enroll users with each model (BioHash method)")
    print("3. Generate comparison CSVs")
    print(f"\nEstimated time: 30-40 minutes")
    
    choice = input("\nContinue? (y/n): ").strip().lower()
    
    if choice != 'y':
        print("Canceled.")
        return
    
    # Phase 1: Test each model
    print("\n\n" + "="*70)
    print("PHASE 1: Testing Models")
    print("="*70)
    
    for model_name in models:
        success = run_command(
            f'python extract_embedding_iris_multi.py {model_name}',
            f'Testing {model_name}'
        )
        if not success:
            print(f"⚠️  Warning: {model_name} test failed")
    
    # Phase 2: Enroll with each model
    print("\n\n" + "="*70)
    print("PHASE 2: Enrolling Users")
    print("="*70)
    
    for model_name in models:
        success = run_command(
            f'python enroll_templates_biohash_iris_multi.py {model_name}',
            f'Enrolling with {model_name}'
        )
        if not success:
            print(f"⚠️  Warning: {model_name} enrollment failed")
    
    # Phase 3: Generate comparison CSVs
    print("\n\n" + "="*70)
    print("PHASE 3: Generating Comparisons")
    print("="*70)
    
    success = run_command(
        'python compare_models_comprehensive.py',
        'Running comprehensive comparison'
    )
    
    # Done
    print("\n\n" + "="*70)
    print("✅ COMPLETE!")
    print("="*70 + "\n")
    print("Check the following CSV files:")
    print("  • embedding_characteristics_TIMESTAMP.csv")
    print("  • model_comparison_output_TIMESTAMP.csv")
    print("  • template_quality_comparison_TIMESTAMP.csv")
    print("\n" + "="*70 + "\n")

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user.\n")
    except Exception as e:
        print(f"\n❌ Error: {e}\n")
