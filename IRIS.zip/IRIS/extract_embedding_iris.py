#!/usr/bin/env python3
"""
Extract iris embeddings using ResNet50 - FINAL WORKING VERSION
"""

import os
import cv2
import numpy as np
import torch
import torch.nn as nn
from torchvision import models

# ImageNet normalization
IMAGENET_MEAN = np.array([0.485, 0.456, 0.406])
IMAGENET_STD = np.array([0.229, 0.224, 0.225])

# Set seeds ONCE at module import for reproducibility
np.random.seed(42)
torch.manual_seed(42)
torch.cuda.manual_seed_all(42)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

_model_cache = {}

def load_model():
    """Load pretrained ResNet50 - cached"""
    global _model_cache
    
    if 'resnet50' in _model_cache:
        return _model_cache['resnet50']
    
    print("Loading resnet50...")
    model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
    model = nn.Sequential(*list(model.children())[:-1])
    model = model.to('cpu')
    model.eval()
    
    for param in model.parameters():
        param.requires_grad = False
    
    _model_cache['resnet50'] = model
    return model


def extract_iris_embedding(image_path):
    """
    Extract iris embedding - DETERMINISTIC and REPRODUCIBLE
    
    Args:
        image_path: Path to iris image
    
    Returns:
        np.ndarray: 2048-dim embedding (float32), or None if error
    """
    try:
        # Read image
        img = cv2.imread(image_path)
        if img is None:
            return None
        
        # Convert to RGB
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # Handle grayscale
        if len(img.shape) == 2 or img.shape[2] == 1:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
        
        # Resize to 224x224
        img = cv2.resize(img, (224, 224))
        
        # Normalize to float32 [0, 1]
        img_norm = img.astype(np.float32) / 255.0
        
        # Apply ImageNet normalization
        img_norm = (img_norm - IMAGENET_MEAN) / IMAGENET_STD
        
        # Convert to tensor: (C, H, W) with batch
        img_tensor = torch.from_numpy(img_norm).permute(2, 0, 1).unsqueeze(0).float()
        
        # Extract features
        model = load_model()
        with torch.no_grad():
            features = model(img_tensor)
        
        # Convert to numpy and flatten
        embedding = features.cpu().numpy().flatten().astype(np.float32)
        
        return embedding
    
    except Exception as e:
        print(f"Error extracting embedding: {e}")
        return None