#!/usr/bin/env python3
"""
AUTOMATED FIX SCRIPT - Iris Biometric Template Protection System
Fixes all critical import and parameter issues
"""

import os
import re
import shutil
from datetime import datetime

def backup_file(filepath):
    """Create backup before modifying"""
    backup_dir = "backup"
    os.makedirs(backup_dir, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_path = os.path.join(backup_dir, f"{os.path.basename(filepath)}.{timestamp}.bak")
    shutil.copy2(filepath, backup_path)
    print(f"  ✓ Backup: {backup_path}")

def fix_import_statements(filepath):
    """Fix: extract_embedding_iris_dl → extract_embedding_iris"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    if 'extract_embedding_iris_dl' in content:
        backup_file(filepath)
        content = content.replace('extract_embedding_iris_dl', 'extract_embedding_iris')
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"  ✓ Fixed import in: {filepath}")
        return True
    return False

def fix_bloom_filter_enrollment(filepath):
    """Fix Bloom Filter enrollment - remove .tobytes() and add user_id"""
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    modified = False
    for i, line in enumerate(lines):
        # Fix: bf.add(emb) should have user_id parameter
        if 'bf.add(emb)' in line and 'user_id' not in line:
            backup_file(filepath)
            lines[i] = line.replace('bf.add(emb)', 'bf.add(emb, user_id=user_id)')
            modified = True
            print(f"  ✓ Fixed Bloom Filter add() at line {i+1}")
    
    if modified:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.writelines(lines)
    
    return modified

def fix_bloom_filter_verification(filepath):
    """Fix Bloom Filter verification - remove .tobytes() and add user_id"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    modified = False
    
    # Fix: bf.query(emb.tobytes()) → bf.query(emb, user_id=user_id)
    if 'bf.query(emb.tobytes())' in content:
        backup_file(filepath)
        content = content.replace('bf.query(emb.tobytes())', 'bf.query(emb, user_id=user_id)')
        modified = True
        print(f"  ✓ Fixed Bloom Filter query() in: {filepath}")
    
    if modified:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
    
    return modified

def fix_iom_grp_enrollment(filepath):
    """Fix IOM-GRP enrollment - add reference_id parameter"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    modified = False
    
    # Fix: generate_template(mean_embedding) → generate_template(mean_embedding, reference_id=user_id)
    if 'iom_grp.generate_template(mean_embedding)' in content:
        backup_file(filepath)
        content = content.replace(
            'iom_grp.generate_template(mean_embedding)',
            'iom_grp.generate_template(mean_embedding, reference_id=user_id)'
        )
        modified = True
        print(f"  ✓ Fixed IOM-GRP generate_template() in: {filepath}")
    
    if modified:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
    
    return modified

def fix_iom_grp_verification(filepath):
    """Fix IOM-GRP verification - add reference_id parameter"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    modified = False
    
    # Fix: iom_grp.compare(template, emb) → iom_grp.compare(template, emb, reference_id=user_id)
    if 'iom_grp.compare(template, emb)' in content and 'reference_id' not in content:
        backup_file(filepath)
        content = content.replace(
            'iom_grp.compare(template, emb)',
            'iom_grp.compare(template, emb, reference_id=user_id)'
        )
        modified = True
        print(f"  ✓ Fixed IOM-GRP compare() in: {filepath}")
    
    if modified:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
    
    return modified

def fix_iom_urp_enrollment(filepath):
    """Fix IOM-URP enrollment - add reference_id parameter"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    modified = False
    
    # Fix: generate_template(mean_embedding) → generate_template(mean_embedding, reference_id=user_id)
    if 'iom_urp.generate_template(mean_embedding)' in content:
        backup_file(filepath)
        content = content.replace(
            'iom_urp.generate_template(mean_embedding)',
            'iom_urp.generate_template(mean_embedding, reference_id=user_id)'
        )
        modified = True
        print(f"  ✓ Fixed IOM-URP generate_template() in: {filepath}")
    
    if modified:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
    
    return modified

def fix_iom_urp_verification(filepath):
    """Fix IOM-URP verification - add reference_id parameter"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    modified = False
    
    # Fix: iom_urp.compare(template, emb) → iom_urp.compare(template, emb, reference_id=user_id)
    if 'iom_urp.compare(template, emb)' in content and 'reference_id' not in content:
        backup_file(filepath)
        content = content.replace(
            'iom_urp.compare(template, emb)',
            'iom_urp.compare(template, emb, reference_id=user_id)'
        )
        modified = True
        print(f"  ✓ Fixed IOM-URP compare() in: {filepath}")
    
    if modified:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
    
    return modified

def fix_mlp_enrollment(filepath):
    """Fix MLP-Hash enrollment - add reference_id parameter"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    modified = False
    
    # Fix: mlp.hash_feature_vector(mean_embedding) → mlp.hash_feature_vector(mean_embedding, reference_id=user_id)
    if 'mlp.hash_feature_vector(mean_embedding)' in content and 'reference_id' not in content:
        backup_file(filepath)
        content = content.replace(
            'mlp.hash_feature_vector(mean_embedding)',
            'mlp.hash_feature_vector(mean_embedding, reference_id=user_id)'
        )
        modified = True
        print(f"  ✓ Fixed MLP-Hash hash_feature_vector() in: {filepath}")
    
    if modified:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
    
    return modified

def fix_mlp_verification(filepath):
    """Fix MLP-Hash verification - add reference_id parameter"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    modified = False
    
    # Fix: mlp.hash_feature_vector(emb) → mlp.hash_feature_vector(emb, reference_id=user_id)
    if 'mlp.hash_feature_vector(emb)' in content and 'reference_id' not in content:
        backup_file(filepath)
        content = content.replace(
            'mlp.hash_feature_vector(emb)',
            'mlp.hash_feature_vector(emb, reference_id=user_id)'
        )
        modified = True
        print(f"  ✓ Fixed MLP-Hash hash_feature_vector() in: {filepath}")
    
    if modified:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
    
    return modified

def fix_compare_iris_models(filepath):
    """Fix model names in compare_iris_models.py"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    modified = False
    
    # Fix model names
    old_line = "model_names = ['resnet50', 'irisnet', 'depiris', 'irisconvnet']"
    new_line = "model_names = ['resnet50', 'efficientnet_b4', 'vgg16', 'mobilenet_v2']"
    
    if old_line in content:
        backup_file(filepath)
        content = content.replace(old_line, new_line)
        modified = True
        print(f"  ✓ Fixed model names in: {filepath}")
    
    if modified:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
    
    return modified

def main():
    """Main fix execution"""
    print("\n" + "="*70)
    print("  AUTOMATED FIX SCRIPT - Iris Biometric System")
    print("="*70 + "\n")
    
    fixes_applied = 0
    
    # Files to fix
    files_to_fix = {
        # Import fixes
        'enroll_templates_biohash_iris.py': [fix_import_statements],
        'enroll_templates_bloom_iris.py': [fix_import_statements, fix_bloom_filter_enrollment],
        'enroll_templates_iom_grp_iris.py': [fix_import_statements, fix_iom_grp_enrollment],
        'enroll_templates_iom_urp_iris.py': [fix_import_statements, fix_iom_urp_enrollment],
        'enroll_templates_mlp_iris.py': [fix_import_statements, fix_mlp_enrollment],
        'enroll_templates_rppca_iris.py': [fix_import_statements],
        'verify_face_biohash_iris.py': [fix_import_statements],
        'verify_face_bloom_iris.py': [fix_bloom_filter_verification],
        'verify_face_iom_grp_iris.py': [fix_iom_grp_verification],
        'verify_face_iom_urp_iris.py': [fix_iom_urp_verification],
        'verify_face_mlp_iris.py': [fix_mlp_verification],
        'compare_iris_models.py': [fix_compare_iris_models],
    }
    
    print("🔧 Applying fixes...\n")
    
    for filename, fix_functions in files_to_fix.items():
        if not os.path.exists(filename):
            print(f"  ⚠️  File not found: {filename}")
            continue
        
        print(f"📄 Processing: {filename}")
        file_modified = False
        
        for fix_func in fix_functions:
            if fix_func(filename):
                file_modified = True
                fixes_applied += 1
        
        if not file_modified:
            print(f"  ℹ️  No changes needed")
        print()
    
    print("="*70)
    print(f"✅ COMPLETE: {fixes_applied} fixes applied")
    print(f"💾 Backups saved in: ./backup/")
    print("="*70 + "\n")
    
    print("📋 NEXT STEPS:")
    print("1. Review changes in backup/ folder")
    print("2. Test enrollment: python enroll_templates_biohash_iris.py")
    print("3. Test verification: python verify_face_biohash_iris.py <image> <user_id>")
    print("4. Run comparison: python iris_comparison.py")
    print()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Interrupted by user. Some fixes may be incomplete.\n")
    except Exception as e:
        print(f"\n❌ ERROR: {e}\n")
