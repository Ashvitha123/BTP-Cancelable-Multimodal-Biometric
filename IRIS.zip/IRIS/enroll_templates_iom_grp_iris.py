#!/usr/bin/env python3
"""
Enroll iris users using IOM-GRP scheme (AUTO-ENROLL ALL USERS)
MULTI-MODEL SUPPORT: Works with ResNet-50, EfficientNet-B4, DenseNet-121, ViT-B/16
"""

import os
import sys
import numpy as np
import joblib
from extract_embedding_iris_multi import extract_iris_embedding
from iom_grp_hash import ION_GRP

TEMPLATE_DIR = 'templates_iris'
os.makedirs(TEMPLATE_DIR, exist_ok=True)

def enroll_iom_grp_iris(user_id, model_name='resnet50'):
    """
    Enroll iris user using IOM-GRP scheme.
    Extracts iris embeddings and generates IOM-GRP template.
    
    Args:
        user_id: User ID (e.g., '001', '002', ..., '224')
        model_name: CNN model to use ('resnet50', 'efficientnet_b4', 'densenet121', 'vit_b_16')
    
    Returns:
        bool: True if enrollment successful, False otherwise
    """
    dataset_path = f'dataset/{user_id}'
    
    if not os.path.exists(dataset_path):
        print(f"[IOM-GRP-IRIS:{user_id}] ✗ Dataset folder not found: {dataset_path}")
        return False
    
    embeddings = []
    
    # Extract embeddings from all iris images for this user
    for img_name in sorted(os.listdir(dataset_path)):
        if img_name.lower().endswith(('.bmp', '.jpg', '.jpeg', '.png')):
            img_path = os.path.join(dataset_path, img_name)
            emb = extract_iris_embedding(img_path, model_name=model_name)
            if emb is not None:
                embeddings.append(emb)
    
    if len(embeddings) == 0:
        print(f"[IOM-GRP-IRIS:{user_id}] ✗ No embeddings extracted")
        return False
    
    print(f"[IOM-GRP-IRIS:{user_id}] Extracted {len(embeddings)} embeddings")
    
    # Compute mean embedding
    mean_embedding = np.mean(embeddings, axis=0)
    
    # Apply IOM-GRP
    iom_grp = ION_GRP()
    template = iom_grp.generate_template(mean_embedding, reference_id=user_id)
    
    # Save template
    template_path = os.path.join(TEMPLATE_DIR, f'iom_grp_iris_{model_name}_{user_id}.pkl')
    joblib.dump(template, template_path)
    print(f"[IOM-GRP-IRIS:{user_id}] ✓ Template saved ({model_name})")
    
    return True


def main():
    """Auto-enroll all users in dataset/ folder"""
    # Get model name from command line
    model_name = sys.argv[1] if len(sys.argv) > 1 else 'resnet50'
    
    dataset_dir = "dataset"
    
    if not os.path.exists(dataset_dir):
        print(f"⌧ ERROR: Dataset directory '{dataset_dir}' not found!")
        return
    
    user_folders = sorted([d for d in os.listdir(dataset_dir) 
                          if os.path.isdir(os.path.join(dataset_dir, d))])
    
    if len(user_folders) == 0:
        print(f"⌧ ERROR: No user folders found in '{dataset_dir}'!")
        return
    
    print(f"\n{'='*70}")
    print(f"AUTO-ENROLLING {len(user_folders)} USERS WITH IOM-GRP")
    print(f"Model: {model_name}")
    print(f"{'='*70}\n")
    
    success_count = 0
    failed_users = []
    
    for user_id in user_folders:
        print(f"\n{'='*70}")
        print(f"Processing user: {user_id}")
        print(f"{'='*70}")
        
        if enroll_iom_grp_iris(user_id, model_name=model_name):
            success_count += 1
        else:
            failed_users.append(user_id)
    
    print(f"\n{'='*70}")
    print("ENROLLMENT SUMMARY")
    print(f"{'='*70}")
    print(f"✓ Successfully enrolled: {success_count}/{len(user_folders)} users")
    
    if failed_users:
        print(f"✗ Failed users: {', '.join(failed_users)}")
    else:
        print(f"✓ All users enrolled successfully!")
    
    print(f"{'='*70}\n")


if __name__ == '__main__':
    main()