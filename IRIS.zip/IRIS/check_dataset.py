#!/usr/bin/env python3
"""
Dataset Structure Verification & Setup Helper
Checks if IITD dataset is properly organized
"""

import os
import sys

def check_dataset_structure():
    """Check if dataset is properly structured"""
    
    print("\n" + "="*70)
    print("  DATASET STRUCTURE VERIFICATION")
    print("="*70 + "\n")
    
    # Check if dataset folder exists
    if not os.path.exists('dataset'):
        print("❌ ERROR: 'dataset' folder not found!")
        print("\n📁 Required Structure:")
        print("   BTP_IRIS/")
        print("   └── dataset/")
        print("       ├── 001/")
        print("       │   ├── 001_1_L.bmp")
        print("       │   ├── 001_1_R.bmp")
        print("       │   └── ...")
        print("       ├── 002/")
        print("       └── ...")
        print("\n💡 Action Required:")
        print("   1. Create 'dataset' folder in project root")
        print("   2. Extract IITD iris database into it")
        print("   3. Ensure folder structure matches above")
        return False
    
    print("✓ 'dataset' folder exists")
    
    # List what's inside dataset
    contents = os.listdir('dataset')
    
    if len(contents) == 0:
        print("❌ ERROR: 'dataset' folder is EMPTY!")
        print("\n💡 Action Required:")
        print("   1. Download IITD Iris Database")
        print("   2. Extract user folders into 'dataset/'")
        print("   3. Each user should have folder like '001', '002', etc.")
        return False
    
    print(f"✓ Found {len(contents)} items in dataset/")
    
    # Check for user folders
    user_folders = [d for d in contents if os.path.isdir(os.path.join('dataset', d))]
    
    if len(user_folders) == 0:
        print("❌ ERROR: No user folders found in dataset/")
        print("\n💡 Current contents of dataset/:")
        for item in contents:
            print(f"   - {item}")
        return False
    
    print(f"✓ Found {len(user_folders)} user folders")
    
    # Check first few folders for images
    print("\n📊 Checking user folders:")
    valid_users = 0
    
    for user_id in sorted(user_folders)[:5]:  # Check first 5
        user_path = os.path.join('dataset', user_id)
        images = [f for f in os.listdir(user_path) 
                 if f.lower().endswith(('.bmp', '.jpg', '.jpeg', '.png'))]
        
        if len(images) > 0:
            print(f"   ✓ {user_id}: {len(images)} images")
            valid_users += 1
        else:
            print(f"   ❌ {user_id}: No images found")
    
    if valid_users == 0:
        print("\n❌ ERROR: No images found in user folders!")
        print("\n💡 Action Required:")
        print("   1. Ensure iris images (.bmp files) are inside user folders")
        print("   2. Check file permissions")
        return False
    
    print(f"\n✅ Dataset structure looks good!")
    print(f"   Total users: {len(user_folders)}")
    print(f"   Valid users checked: {valid_users}/5")
    
    # Test image reading
    print("\n🧪 Testing image loading:")
    test_folder = sorted(user_folders)[0]
    test_path = os.path.join('dataset', test_folder)
    test_images = [f for f in os.listdir(test_path) 
                  if f.lower().endswith(('.bmp', '.jpg', '.jpeg', '.png'))]
    
    if len(test_images) > 0:
        test_image = os.path.join(test_path, test_images[0])
        print(f"   Testing: {test_image}")
        
        try:
            import cv2
            img = cv2.imread(test_image)
            if img is not None:
                print(f"   ✓ Image loaded successfully: shape={img.shape}")
                return True
            else:
                print(f"   ❌ cv2.imread() returned None")
                print(f"   💡 Check file integrity and format")
                return False
        except Exception as e:
            print(f"   ❌ Error: {e}")
            return False
    
    return True


def create_sample_structure():
    """Create sample dataset structure"""
    print("\n" + "="*70)
    print("  CREATING SAMPLE DATASET STRUCTURE")
    print("="*70 + "\n")
    
    os.makedirs('dataset', exist_ok=True)
    
    for i in range(1, 4):  # Create 3 sample folders
        user_id = f"{i:03d}"
        user_path = os.path.join('dataset', user_id)
        os.makedirs(user_path, exist_ok=True)
        
        # Create README in each folder
        readme_path = os.path.join(user_path, 'README.txt')
        with open(readme_path, 'w') as f:
            f.write(f"Place iris images for user {user_id} here\n")
            f.write(f"Expected format: {user_id}_1_L.bmp, {user_id}_1_R.bmp, etc.\n")
        
        print(f"✓ Created: dataset/{user_id}/")
    
    print("\n✅ Sample structure created!")
    print("💡 Now copy your IITD iris images into these folders")


def show_current_directory():
    """Show current working directory"""
    print("\n" + "="*70)
    print("  CURRENT DIRECTORY INFORMATION")
    print("="*70 + "\n")
    
    cwd = os.getcwd()
    print(f"Current Directory: {cwd}")
    print(f"\nContents:")
    
    for item in sorted(os.listdir('.')):
        if os.path.isdir(item):
            print(f"   📁 {item}/")
        else:
            print(f"   📄 {item}")


def main():
    """Main verification"""
    show_current_directory()
    
    if not check_dataset_structure():
        print("\n" + "="*70)
        print("  SETUP REQUIRED")
        print("="*70 + "\n")
        
        choice = input("Create sample dataset structure? (y/n): ").strip().lower()
        
        if choice == 'y':
            create_sample_structure()
        
        print("\n📋 Next Steps:")
        print("1. Obtain IITD Iris Database")
        print("2. Extract user folders (001, 002, ..., 018) into 'dataset/'")
        print("3. Run this script again to verify")
        print("4. Then run: python -c \"from extract_embedding_iris import extract_iris_embedding; emb = extract_iris_embedding('dataset/001/001_1_L.bmp'); print('✅ Works!' if emb else '❌ Failed')\"")
    else:
        print("\n" + "="*70)
        print("  ✅ READY TO GO!")
        print("="*70 + "\n")
        print("Next steps:")
        print("1. Run: python auto_fix.py")
        print("2. Run: python enroll_templates_biohash_iris.py")
        print("3. Test system!")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user.\n")
    except Exception as e:
        print(f"\n❌ Error: {e}\n")
