#!/usr/bin/env python3
"""
Verify iris users using BioHash scheme - OPTIMIZED VERSION
Uses optimal threshold based on genuine score distribution
"""

import os
import numpy as np
import joblib
from extract_embedding_iris import extract_iris_embedding
from bio_hash import BioHash

TEMPLATE_DIR = 'templates_iris'
DATASET_DIR = 'dataset'

def verify_biohash_iris(threshold=0.45):  # LOWERED from 0.5 to 0.45
    """Auto-verify all users by testing against their own templates"""
    
    results = {
        'total_users': 0,
        'successful_verifications': 0,
        'failed_verifications': 0,
        'genuine_scores': [],
        'threshold': threshold
    }
    
    user_folders = sorted([d for d in os.listdir(DATASET_DIR) 
                          if os.path.isdir(os.path.join(DATASET_DIR, d))])
    
    if len(user_folders) == 0:
        print("❌ No user folders found!")
        return results
    
    print(f"\n{'='*70}")
    print(f"AUTO-VERIFYING {len(user_folders)} USERS WITH BIOHASH")
    print(f"Threshold: {threshold}")
    print(f"{'='*70}\n")
    
    # Initialize BioHash
    biohash = BioHash()
    
    for user_id in user_folders:
        results['total_users'] += 1
        
        # Load enrolled data
        template_path = os.path.join(TEMPLATE_DIR, f'biohash_iris_{user_id}.pkl')
        
        if not os.path.exists(template_path):
            print(f"[BioHash-Verify:{user_id}] ✗ Template not found")
            results['failed_verifications'] += 1
            continue
        
        try:
            enrollment_data = joblib.load(template_path)
            
            if 'template' in enrollment_data:
                enrolled_hash = enrollment_data['template']
            else:
                enrolled_embedding = enrollment_data['mean_embedding']
                enrolled_hash = biohash.generate(enrolled_embedding, reference_id=user_id)
                
        except Exception as e:
            print(f"[BioHash-Verify:{user_id}] ✗ Error loading template: {e}")
            results['failed_verifications'] += 1
            continue
        
        # Get first iris image for verification
        dataset_path = os.path.join(DATASET_DIR, user_id)
        iris_files = sorted([f for f in os.listdir(dataset_path) 
                            if f.lower().endswith(('.bmp', '.jpg', '.jpeg', '.png'))])
        
        if len(iris_files) == 0:
            print(f"[BioHash-Verify:{user_id}] ✗ No iris images found")
            results['failed_verifications'] += 1
            continue
        
        # Use first image as probe
        probe_path = os.path.join(dataset_path, iris_files[0])
        
        try:
            # Extract embedding from probe
            probe_emb = extract_iris_embedding(probe_path)
            
            if probe_emb is None:
                print(f"[BioHash-Verify:{user_id}] ✗ Could not extract embedding")
                results['failed_verifications'] += 1
                continue
            
            # Generate BioHash for probe
            probe_hash = biohash.generate(probe_emb, reference_id=user_id)
            
            # Compare hashes using Hamming similarity
            similarity = biohash.hamming_similarity(enrolled_hash, probe_hash)
            
            results['genuine_scores'].append(similarity)
            
            # Use configurable threshold
            if similarity > threshold:
                print(f"[BioHash-Verify:{user_id}] ✓ VERIFIED (Similarity: {similarity:.3f})")
                results['successful_verifications'] += 1
            else:
                print(f"[BioHash-Verify:{user_id}] ✗ REJECTED (Similarity: {similarity:.3f})")
                results['failed_verifications'] += 1
        
        except Exception as e:
            print(f"[BioHash-Verify:{user_id}] ✗ Error: {e}")
            results['failed_verifications'] += 1
    
    # Print summary
    print(f"\n{'='*70}")
    print("VERIFICATION SUMMARY - OPTIMIZED")
    print(f"{'='*70}")
    print(f"Threshold used: {threshold}")
    print(f"Total users tested: {results['total_users']}")
    print(f"✓ Verified: {results['successful_verifications']}")
    print(f"✗ Rejected: {results['failed_verifications']}")
    
    if results['successful_verifications'] > 0:
        verification_rate = (results['successful_verifications'] / results['total_users']) * 100
        print(f"Verification Rate: {verification_rate:.1f}%")
    
    if results['genuine_scores']:
        print(f"\nGenuine Match Scores:")
        print(f"  Min: {min(results['genuine_scores']):.3f}")
        print(f"  Max: {max(results['genuine_scores']):.3f}")
        print(f"  Avg: {np.mean(results['genuine_scores']):.3f}")
        print(f"  Std: {np.std(results['genuine_scores']):.3f}")
        
        # Suggest optimal threshold
        mean_score = np.mean(results['genuine_scores'])
        std_score = np.std(results['genuine_scores'])
        optimal_threshold = mean_score - std_score
        print(f"\n💡 Suggested optimal threshold: {optimal_threshold:.3f}")
    
    print(f"{'='*70}\n")
    
    return results


if __name__ == '__main__':
    import sys
    
    # Allow threshold to be passed as command line argument
    threshold = 0.45  # Default
    if len(sys.argv) > 1:
        try:
            threshold = float(sys.argv[1])
            print(f"Using custom threshold: {threshold}")
        except:
            print(f"Invalid threshold, using default: {threshold}")
    
    verify_biohash_iris(threshold=threshold)