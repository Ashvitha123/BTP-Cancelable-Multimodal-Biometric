#!/usr/bin/env python3
"""
RP-PCA (Random Projection + PCA)

Cancelable biometric template protection using PCA and user-specific random permutations.
Extracts principal components and applies user-specific transformations.
"""

import numpy as np
import hashlib
from sklearn.decomposition import PCA

class RPPCAHash:
    """RP-PCA transformer for biometric template protection."""
    
    def __init__(self, n_components=256, offset=0):
        """
        Initialize RP-PCA.
        
        Args:
            n_components: Number of PCA components
            offset: Seed offset
        """
        self.n_components = n_components
        self.offset = offset
        self.pca = None
    
    def generate_user_seed(self, user_id, offset=None):
        """Generate deterministic user-specific seed."""
        if offset is None:
            offset = self.offset
        h = hashlib.sha256(user_id.encode('utf-8')).hexdigest()
        return offset + int(h, 16) % (10**8)
    
    def fit(self, embeddings):
        """Fit PCA model on training embeddings."""
        self.pca = PCA(n_components=self.n_components)
        self.pca.fit(embeddings)
    
    def transform(self, x, user_id):
        """Transform feature to protected template."""
        if self.pca is None:
            raise ValueError("PCA model not fitted. Call fit() first.")
        
        # PCA transformation
        x_pca = self.pca.transform(x.reshape(1, -1))[0]
        
        # User-specific random permutation
        seed = self.generate_user_seed(user_id)
        np.random.seed(seed)
        permuted_indices = np.random.permutation(self.n_components)
        
        # Apply permutation
        x_perm = x_pca[permuted_indices]
        
        # Binarize using median threshold
        threshold = np.median(x_perm)
        template = (x_perm >= threshold).astype(np.uint8)
        
        return template
    
    def hamming_similarity(self, a, b):
        """Compute Hamming similarity between two templates."""
        if len(a) != len(b):
            raise ValueError("Templates must have same length")
        return 1 - np.count_nonzero(a != b) / len(a)
    
    def compare(self, a, b):
        """Compare two templates (returns distance for compatibility)."""
        return 1 - self.hamming_similarity(a, b)


if __name__ == '__main__':
    print("RP-PCA Hash module loaded")
