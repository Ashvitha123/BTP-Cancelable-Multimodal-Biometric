#!/usr/bin/env python3
"""
Enroll All Users with All Models and All Methods
Comprehensive enrollment for complete comparison
"""

import subprocess
import time
import sys

def run_command(cmd, description):
    """Run command and show progress"""
    print(f"\n{'='*70}")
    print(f"  {description}")
    print(f"{'='*70}\n")
    
    start_time = time.time()
    result = subprocess.run(cmd, shell=True)
    elapsed = time.time() - start_time
    
    print(f"\n⏱️  Completed in {elapsed:.1f} seconds")
    return result.returncode == 0

def main():
    models = ['resnet50', 'efficientnet_b4', 'densenet121', 'vit_b_16']
    methods = ['biohash', 'bloom', 'mlp', 'iom_grp', 'iom_urp', 'rppca']
    
    print("\n" + "="*70)
    print("  COMPREHENSIVE ENROLLMENT - ALL MODELS × ALL METHODS")
    print("="*70 + "\n")
    
    print(f"Models: {len(models)}")
    for model in models:
        print(f"  • {model}")
    
    print(f"\nMethods: {len(methods)}")
    for method in methods:
        print(f"  • {method}")
    
    total = len(models) * len(methods)
    print(f"\nTotal enrollments: {total}")
    print(f"Estimated time: {total * 3} minutes")
    
    choice = input("\nContinue? (y/n): ").strip().lower()
    if choice != 'y':
        print("Canceled.")
        return
    
    completed = 0
    failed = 0
    
    for model in models:
        print(f"\n\n{'='*70}")
        print(f"  MODEL: {model.upper()}")
        print(f"{'='*70}")
        
        for method in methods:
            completed += 1
            progress = f"[{completed}/{total}]"
            
            # Construct enrollment command
            # Note: You'll need enrollment scripts that accept model_name parameter
            # For now, this assumes you have them or will create them
            
            cmd = f"python enroll_templates_{method}_iris.py {model}"
            
            success = run_command(
                cmd,
                f"{progress} {model} + {method}"
            )
            
            if not success:
                print(f"⚠️  Warning: Failed")
                failed += 1
                # Continue anyway
    
    print("\n\n" + "="*70)
    print("  ENROLLMENT COMPLETE")
    print("="*70)
    print(f"✓ Completed: {completed}")
    print(f"✗ Failed: {failed}")
    print("="*70 + "\n")
    
    print("Now run: python compare_models_comprehensive.py")
    print("to generate complete comparison CSVs!")

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user.\n")
