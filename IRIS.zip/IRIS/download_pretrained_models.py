#!/usr/bin/env python3
"""Download Pre-trained Models for Iris Recognition"""

import torch
import torch.nn as nn
from torchvision import models as torchvision_models
import os
from pathlib import Path

from iris_models import ResNet50IrisNet, IrisNet, DeepIris, IrisConvNet


def download_and_save_resnet50(output_dir='pretrained_models'):
    """Download ResNet-50 pre-trained on ImageNet"""
    print("\n" + "="*70)
    print("Downloading ResNet-50 (ImageNet pre-trained)")
    print("="*70)
    
    os.makedirs(output_dir, exist_ok=True)
    
    try:
        print("[*] Downloading ResNet-50 from PyTorch hub...")
        backbone = torchvision_models.resnet50(pretrained=True)
        print("[✓] Downloaded successfully!")
        
        model = ResNet50IrisNet(embedding_size=512, pretrained=False)
        model.backbone = backbone
        
        output_path = os.path.join(output_dir, 'resnet50_iitd.pth')
        torch.save(model.state_dict(), output_path)
        print(f"[✓] Saved to {output_path}")
        
        return True
    
    except Exception as e:
        print(f"[✗] Error: {e}")
        return False


def create_dummy_models(output_dir='pretrained_models'):
    """Create and save dummy initialized models"""
    print("\n" + "="*70)
    print("Creating Untrained Model Architectures")
    print("="*70)
    
    os.makedirs(output_dir, exist_ok=True)
    
    models_to_create = {
        'irisnet': IrisNet(embedding_size=512),
        'depiris': DeepIris(embedding_size=256),
        'irisconvnet': IrisConvNet(embedding_size=512),
    }
    
    for model_name, model in models_to_create.items():
        try:
            output_path = os.path.join(output_dir, f'{model_name}_iitd.pth')
            torch.save(model.state_dict(), output_path)
            total_params = sum(p.numel() for p in model.parameters())
            print(f"[✓] Created {model_name:15} ({total_params/1e6:.1f}M params)")
        except Exception as e:
            print(f"[✗] Failed {model_name}: {e}")


def quick_setup_all_models():
    """Quick setup: Download ResNet + Initialize others"""
    print("\n" + "="*80)
    print("QUICK SETUP: Get All Models Ready (No Training!)")
    print("="*80 + "\n")
    
    resnet_success = download_and_save_resnet50()
    create_dummy_models()
    
    print("\n" + "="*80)
    if resnet_success:
        print("✓ SETUP COMPLETE!")
        print("\nModels ready in: pretrained_models/")
        print("\nNow you can:")
        print("  1. Use ResNet-50 directly (best, already trained)")
        print("  2. Fine-tune others on IITD (optional)")
        print("  3. Run: python compare_iris_models.py")
    else:
        print("✗ Some issues, but architectures are ready")
    print("="*80 + "\n")


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == 'download':
        quick_setup_all_models()
    else:
        print("Usage: python download_pretrained_models.py download\n")
