#!/usr/bin/env python3
"""
Bloom Filter Hash

Cancelable biometric template protection using Bloom filters.
Encodes biometric features as probabilistic data structure for efficient matching.
"""

import numpy as np
import hashlib
import pickle
import os

class BloomFilterHash:
    """Bloom Filter transformer for biometric template protection."""
    
    def __init__(self, m=10000, k=7, offset=0):
        """
        Initialize Bloom Filter.
        
        Args:
            m: Size of bit array
            k: Number of hash functions
            offset: Seed offset
        """
        self.m = m
        self.k = k
        self.offset = offset
        self.bits = np.zeros(m, dtype=np.uint8)
    
    def generate_user_seed(self, user_id, offset=None):
        """Generate deterministic user-specific seed."""
        if offset is None:
            offset = self.offset
        h = hashlib.sha256(user_id.encode('utf-8')).hexdigest()
        return offset + int(h, 16) % (10**8)
    
    def _hash_functions(self, x, user_id):
        """Generate k hash values for element x."""
        seed = self.generate_user_seed(user_id)
        base = int(np.sum(x)*1e6) ^ seed
        
        hashes = []
        for i in range(self.k):
            h = hashlib.sha256((str(base) + str(i)).encode()).hexdigest()
            hashes.append(int(h, 16) % self.m)
        
        return hashes
    
    def add(self, x, user_id=None):
        """Add element to Bloom Filter."""
        hashes = self._hash_functions(x, user_id if user_id else "default")
        for h in hashes:
            self.bits[h] = 1
    
    def query(self, x, user_id=None):
        """Query if element is likely in Bloom Filter."""
        hashes = self._hash_functions(x, user_id if user_id else "default")
        return all(self.bits[h] == 1 for h in hashes)
    
    def transform(self, x, user_id):
        """Transform feature to Bloom Filter representation."""
        filter_copy = BloomFilterHash(self.m, self.k, self.offset)
        filter_copy.bits = self.bits.copy()
        filter_copy.add(x, user_id)
        return filter_copy.bits
    
    def serialize(self, filepath):
        """Save Bloom Filter to file."""
        with open(filepath, 'wb') as f:
            pickle.dump(self.bits, f)
    
    @staticmethod
    def deserialize(filepath):
        """Load Bloom Filter from file."""
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")
        
        with open(filepath, 'rb') as f:
            bits = pickle.load(f)
        
        bf = BloomFilterHash(m=len(bits), k=7)
        bf.bits = bits
        return bf
    
    def hamming_distance(self, other_bits):
        """Compute Hamming distance with another bit array."""
        if len(other_bits) != len(self.bits):
            raise ValueError("Bit arrays must have same length")
        return np.count_nonzero(self.bits != other_bits) / len(self.bits)
    
    def hamming_similarity(self, other_bits):
        """Compute Hamming similarity with another bit array."""
        return 1.0 - self.hamming_distance(other_bits)
    
    def compare(self, other_bits):
        """Compare with other bits (returns distance)."""
        return self.hamming_distance(other_bits)
    
    def get_statistics(self):
        """Get Bloom Filter statistics."""
        ones = np.sum(self.bits)
        fill_ratio = ones / self.m
        
        return {
            'size': self.m,
            'num_hashes': self.k,
            'bits_set': int(ones),
            'fill_ratio': fill_ratio,
            'density': fill_ratio
        }


if __name__ == '__main__':
    print("Bloom Filter Hash module loaded")
