# Testing Checklist - Iris Biometric System

## ✅ Pre-Testing Setup

- [ ] Python 3.8+ installed
- [ ] All dependencies installed (`pip install -r requirements.txt`)
- [ ] IITD dataset in `dataset/` folder
- [ ] Dataset contains 18 user folders (001-018)
- [ ] Each user folder contains .bmp iris images
- [ ] `auto_fix.py` executed successfully
- [ ] Backup folder created with original files

---

## ✅ Phase 1: Core Functionality Tests

### Test 1.1: Import Test
```bash
python -c "from extract_embedding_iris import extract_iris_embedding; print('✓ Import works')"
```
- [ ] No ModuleNotFoundError
- [ ] Prints: ✓ Import works

### Test 1.2: Model Loading Test
```bash
python -c "from extract_embedding_iris import load_model; m = load_model(); print('✓ Model loaded')"
```
- [ ] Downloads ResNet-50 (first run only)
- [ ] Prints: ✓ Model loaded
- [ ] No errors

### Test 1.3: Embedding Extraction Test
```bash
python -c "from extract_embedding_iris import extract_iris_embedding; \
emb = extract_iris_embedding('dataset/001/001_1_L.bmp'); \
print(f'✓ Embedding: shape={emb.shape if emb is not None else None}')"
```
- [ ] Prints: ✓ Embedding: shape=(2048,)
- [ ] No errors or warnings

---

## ✅ Phase 2: Enrollment Tests (All 6 Methods)

### Test 2.1: BioHash Enrollment
```bash
python enroll_templates_biohash_iris.py
```
**Expected Output**:
- [ ] "AUTO-ENROLLING 18 USERS WITH BIOHASH"
- [ ] "[BioHash-IRIS:001] ✓ Extracted X embeddings"
- [ ] "[BioHash-IRIS:001] ✓ Template saved"
- [ ] "✓ Successfully enrolled: 18/18 users"
- [ ] Files created in `templates_iris/biohash_iris_*.pkl`

### Test 2.2: Bloom Filter Enrollment
```bash
python enroll_templates_bloom_iris.py
```
**Expected Output**:
- [ ] "AUTO-ENROLLING 18 USERS WITH BLOOM FILTER"
- [ ] "[Bloom-IRIS:001] ✓ Added X embeddings to Bloom Filter"
- [ ] "[Bloom-IRIS:001] ✓ Template saved"
- [ ] "✓ Successfully enrolled: 18/18 users"
- [ ] Files created in `templates_iris/bloom_iris_*.bin`

### Test 2.3: MLP-Hash Enrollment
```bash
python enroll_templates_mlp_iris.py
```
**Expected Output**:
- [ ] "AUTO-ENROLLING 18 USERS WITH MLP-HASH"
- [ ] "[MLP-Hash-IRIS:001] Extracted X embeddings"
- [ ] "[MLP-Hash-IRIS:001] ✓ Template saved"
- [ ] "✓ Successfully enrolled: 18/18 users"
- [ ] Files created in `templates_iris/mlp_iris_*.bin`

### Test 2.4: IOM-GRP Enrollment
```bash
python enroll_templates_iom_grp_iris.py
```
**Expected Output**:
- [ ] "AUTO-ENROLLING 18 USERS WITH IOM-GRP"
- [ ] "[IOM-GRP-IRIS:001] Extracted X embeddings"
- [ ] "[IOM-GRP-IRIS:001] ✓ Template saved"
- [ ] "✓ Successfully enrolled: 18/18 users"
- [ ] Files created in `templates_iris/iom_grp_iris_*.pkl`

### Test 2.5: IOM-URP Enrollment
```bash
python enroll_templates_iom_urp_iris.py
```
**Expected Output**:
- [ ] "AUTO-ENROLLING 18 USERS WITH IOM-URP"
- [ ] "[IOM-URP-IRIS:001] Extracted X embeddings"
- [ ] "[IOM-URP-IRIS:001] ✓ Template saved"
- [ ] "✓ Successfully enrolled: 18/18 users"
- [ ] Files created in `templates_iris/iom_urp_iris_*.pkl`

### Test 2.6: RP-PCA Enrollment
```bash
python enroll_templates_rppca_iris.py
```
**Expected Output**:
- [ ] "AUTO-ENROLLING 18 USERS WITH RP-PCA"
- [ ] "[RP-PCA-IRIS:001] Extracted X embeddings"
- [ ] "[RP-PCA-IRIS:001] ✓ Template saved (n_components=X)"
- [ ] "✓ Successfully enrolled: 18/18 users"
- [ ] Files created in `templates_iris/rppca_iris_*.pkl`

---

## ✅ Phase 3: Verification Tests (Genuine Matches)

### Test 3.1: BioHash Verification (Genuine)
```bash
python verify_face_biohash_iris.py dataset/001/001_1_L.bmp 001
```
**Expected**:
- [ ] No ModuleNotFoundError
- [ ] Loads template successfully
- [ ] Extracts probe embedding
- [ ] **Should output VERIFIED** (genuine match)
- [ ] Similarity score > 0.7

### Test 3.2: Bloom Filter Verification (Genuine)
```bash
python verify_face_bloom_iris.py dataset/001/001_1_L.bmp 001
```
**Expected**:
- [ ] Loads Bloom Filter
- [ ] Extracts probe embedding
- [ ] Query returns True or match=YES

### Test 3.3: MLP-Hash Verification (Genuine)
```bash
python verify_face_mlp_iris.py dataset/001/001_1_L.bmp 001
```
**Expected**:
- [ ] Loads template
- [ ] Computes MLP-Hash for probe
- [ ] Distance < threshold
- [ ] match=YES

### Test 3.4: IOM-GRP Verification (Genuine)
```bash
python verify_face_iom_grp_iris.py dataset/001/001_1_L.bmp 001
```
**Expected**:
- [ ] Loads template
- [ ] Generates IOM-GRP for probe
- [ ] Distance < 0.5
- [ ] match=YES

### Test 3.5: IOM-URP Verification (Genuine)
```bash
python verify_face_iom_urp_iris.py dataset/001/001_1_L.bmp 001
```
**Expected**:
- [ ] Loads template
- [ ] Generates IOM-URP for probe
- [ ] Distance < 0.5
- [ ] match=YES

### Test 3.6: RP-PCA Verification (Genuine)
```bash
python verify_face_rppca_iris.py dataset/001/001_1_L.bmp 001
```
**Expected**:
- [ ] Loads PCA template
- [ ] Transforms probe
- [ ] Distance < threshold
- [ ] match=YES

---

## ✅ Phase 4: Verification Tests (Impostor Attempts)

### Test 4.1: Cross-User Verification (Should Reject)
```bash
# Try to verify user 002's image as user 001 (impostor)
python verify_face_biohash_iris.py dataset/002/002_1_L.bmp 001
```
**Expected**:
- [ ] **Should output REJECTED** (impostor)
- [ ] Similarity score < 0.7

### Test 4.2: Multiple Impostor Tests
```bash
# Test each method with impostor attempt
python verify_face_bloom_iris.py dataset/003/003_1_L.bmp 001
python verify_face_mlp_iris.py dataset/004/004_1_L.bmp 001
python verify_face_iom_grp_iris.py dataset/005/005_1_L.bmp 001
python verify_face_iom_urp_iris.py dataset/006/006_1_L.bmp 001
python verify_face_rppca_iris.py dataset/007/007_1_L.bmp 001
```
**Expected**:
- [ ] All should output REJECTED or match=NO
- [ ] Distance/similarity scores should be worse than genuine

---

## ✅ Phase 5: System Integration Tests

### Test 5.1: Show Enrolled Users
```bash
python show_users_iris.py
```
**Expected Output**:
- [ ] Lists all 18 enrolled users
- [ ] Shows 6 schemes for each user
- [ ] Status shows "✓ COMPLETE" for all users
- [ ] No errors

### Test 5.2: Model Comparison (Optional)
```bash
python iris_comparison.py
```
**Expected Output**:
- [ ] Loads ResNet-50, EfficientNet, VGG-16, MobileNet
- [ ] Extracts embeddings for all users
- [ ] Computes Rank-1, Rank-5, EER
- [ ] Saves results to CSV
- [ ] No errors

---

## ✅ Phase 6: Edge Cases & Error Handling

### Test 6.1: Missing Image
```bash
python verify_face_biohash_iris.py nonexistent.bmp 001
```
**Expected**:
- [ ] Graceful error message
- [ ] No crash
- [ ] "Probe image not found" or similar

### Test 6.2: Missing Template
```bash
python verify_face_biohash_iris.py dataset/001/001_1_L.bmp 999
```
**Expected**:
- [ ] Error: "Template missing" or "Template not found"
- [ ] No crash

### Test 6.3: Invalid Image Format
```bash
python verify_face_biohash_iris.py requirements.txt 001
```
**Expected**:
- [ ] Error: "No iris detected" or "Could not read image"
- [ ] No crash

---

## ✅ Phase 7: Performance Tests

### Test 7.1: Enrollment Time (Single User)
```bash
time python -c "from enroll_templates_biohash_iris import enroll_biohash_iris; \
enroll_biohash_iris('001')"
```
**Expected**:
- [ ] Completes in < 5 seconds
- [ ] Time recorded

### Test 7.2: Verification Time (Single Attempt)
```bash
time python verify_face_biohash_iris.py dataset/001/001_1_L.bmp 001
```
**Expected**:
- [ ] Completes in < 2 seconds
- [ ] Time recorded

### Test 7.3: Batch Enrollment Time (All Users)
```bash
time python enroll_templates_biohash_iris.py
```
**Expected**:
- [ ] Completes in < 2 minutes for 18 users
- [ ] Time recorded

---

## ✅ Phase 8: File Structure Validation

### Test 8.1: Template Directory Check
```bash
ls -lh templates_iris/
```
**Expected**:
- [ ] Directory exists
- [ ] Contains 108 files (18 users × 6 methods)
- [ ] File sizes are reasonable (KB range)
- [ ] Naming convention: `{method}_iris_{user_id}.{ext}`

### Test 8.2: Backup Directory Check
```bash
ls -lh backup/
```
**Expected**:
- [ ] Directory exists
- [ ] Contains backup files with timestamps
- [ ] Original files are preserved

---

## ✅ Phase 9: Clean System Test (Fresh Start)

### Test 9.1: Delete Templates and Re-enroll
```bash
# Clean templates
rm -rf templates_iris/*

# Re-enroll one method
python enroll_templates_biohash_iris.py

# Verify it works
python verify_face_biohash_iris.py dataset/001/001_1_L.bmp 001
```
**Expected**:
- [ ] Templates deleted successfully
- [ ] Re-enrollment works
- [ ] Verification works after re-enrollment

---

## ✅ Phase 10: Final Validation

### Test 10.1: All Methods Work End-to-End
- [ ] BioHash: Enroll ✓ + Verify ✓
- [ ] Bloom Filter: Enroll ✓ + Verify ✓
- [ ] MLP-Hash: Enroll ✓ + Verify ✓
- [ ] IOM-GRP: Enroll ✓ + Verify ✓
- [ ] IOM-URP: Enroll ✓ + Verify ✓
- [ ] RP-PCA: Enroll ✓ + Verify ✓

### Test 10.2: Documentation Completeness
- [ ] All 5 documentation files present
- [ ] README or setup guide available
- [ ] Requirements.txt accurate
- [ ] Issues documented

### Test 10.3: Code Quality
- [ ] No Python syntax errors
- [ ] No import errors
- [ ] Proper error handling
- [ ] Code is well-commented

---

## 📊 Success Criteria Summary

**PASS** if all of the following are true:
1. ✅ All 18 users enrolled successfully with all 6 methods
2. ✅ Genuine matches are ACCEPTED (>90% accuracy)
3. ✅ Impostor attempts are REJECTED (>90% accuracy)
4. ✅ No crashes or unhandled exceptions
5. ✅ Performance is acceptable (<2s per verification)
6. ✅ Files are created correctly in templates_iris/
7. ✅ System can re-enroll after template deletion

**FAIL** if any of the following occur:
1. ❌ ModuleNotFoundError or import errors
2. ❌ Enrollment fails for any user
3. ❌ Verification crashes
4. ❌ Genuine matches rejected consistently
5. ❌ Impostors accepted frequently
6. ❌ Templates not saved properly

---

## 🎯 Final Checklist

- [ ] All 60+ tests executed
- [ ] All critical tests passed
- [ ] Issues documented (if any)
- [ ] Performance benchmarks recorded
- [ ] System ready for production/research
- [ ] Documentation up to date

---

**Testing Completed**: _____ / _____ / _____  
**Tested By**: _____________________  
**Overall Result**: ⬜ PASS  ⬜ FAIL  ⬜ NEEDS WORK

---

*Use this checklist systematically to ensure complete system validation*
