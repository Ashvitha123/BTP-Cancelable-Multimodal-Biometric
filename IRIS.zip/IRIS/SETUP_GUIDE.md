# Quick Setup & Testing Guide

## 📦 Setup Instructions

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Apply Automatic Fixes
```bash
python auto_fix.py
```

This will:
- Fix all import statements
- Add missing parameters
- Create backups in `backup/` folder
- Fix model names in comparison scripts

### Step 3: Verify Dataset Structure
```
dataset/
├── 001/
│   ├── 001_1_L.bmp
│   ├── 001_1_R.bmp
│   └── ...
├── 002/
│   └── ...
└── 018/
    └── ...
```

## 🧪 Testing Workflow

### Test 1: Embedding Extraction (Foundation)
```bash
python -c "from extract_embedding_iris import extract_iris_embedding; \
emb = extract_iris_embedding('dataset/001/001_1_L.bmp'); \
print('✅ Embedding extraction works!' if emb is not None else '❌ Failed')"
```

**Expected**: ✅ Embedding extraction works!

---

### Test 2: Single User Enrollment (BioHash)
```bash
python enroll_templates_biohash_iris.py
```

**Expected Output**:
```
======================================================================
AUTO-ENROLLING 18 USERS WITH BIOHASH
======================================================================

[BioHash-IRIS:001] ✓ Extracted 10 embeddings
[BioHash-IRIS:001] ✓ Template saved
...
✓ Successfully enrolled: 18/18 users
```

---

### Test 3: Single User Verification (BioHash)
```bash
python verify_face_biohash_iris.py dataset/001/001_1_L.bmp 001
```

**Expected Output**:
```
[BioHash-Verify:001] ✓ VERIFIED (Similarity: 0.XXX)
```

---

### Test 4: Enroll All Methods (One User)
```bash
# BioHash
python enroll_templates_biohash_iris.py

# Bloom Filter
python enroll_templates_bloom_iris.py

# MLP-Hash
python enroll_templates_mlp_iris.py

# IOM-GRP
python enroll_templates_iom_grp_iris.py

# IOM-URP
python enroll_templates_iom_urp_iris.py

# RP-PCA
python enroll_templates_rppca_iris.py
```

---

### Test 5: Verify Enrolled Users
```bash
python show_users_iris.py
```

**Expected Output**:
```
============================================================================
  ENROLLED IRIS USERS - BIOMETRIC TEMPLATE PROTECTION SYSTEM
============================================================================

User ID      Schemes Enrolled                                    Status    
----------------------------------------------------------------------------
001          BioHash, Bloom Filter, IOM-GRP, IOM-URP, MLP-Hash  ✓ COMPLETE
002          BioHash, Bloom Filter, IOM-GRP, IOM-URP, MLP-Hash  ✓ COMPLETE
...
```

---

### Test 6: Run Model Comparison (Optional)
```bash
python iris_comparison.py
```

**Expected Output**:
```
============================================================================================
IRIS RECOGNITION - 4 PRE-TRAINED MODELS
============================================================================================

Model                Rank-1       Rank-5       EER        Time(ms)     Params      
--------------------------------------------------------------------------------------------
resnet50             0.XXXX       0.XXXX       0.XXXX    XX.XX        23.5M
efficientnet_b4      0.XXXX       0.XXXX       0.XXXX    XX.XX        19.3M
vgg16                0.XXXX       0.XXXX       0.XXXX    XX.XX        138.0M
mobilenet_v2         0.XXXX       0.XXXX       0.XXXX    XX.XX        3.5M
```

---

## 🐛 Troubleshooting

### Error: ModuleNotFoundError: No module named 'extract_embedding_iris_dl'
**Solution**: Run `python auto_fix.py` to fix import statements

### Error: Bloom Filter query() TypeError
**Solution**: Run `python auto_fix.py` to add user_id parameters

### Error: cv2.imread() returns None
**Solution**: Check dataset path and image file permissions

### Error: CUDA out of memory
**Solution**: Reduce batch size or use CPU:
```python
device = torch.device('cpu')  # Force CPU
```

### Warning: Deprecation warning for 'pretrained'
**Solution**: Update PyTorch to latest version or ignore (still works)

---

## 📊 Expected File Structure After Setup

```
BTP_IRIS/
├── dataset/                    # IITD iris images
│   ├── 001/
│   ├── 002/
│   └── ...
├── templates_iris/             # Generated templates
│   ├── biohash_iris_001.pkl
│   ├── bloom_iris_001.bin
│   ├── mlp_iris_001.bin
│   ├── iom_grp_iris_001.pkl
│   ├── iom_urp_iris_001.pkl
│   ├── rppca_iris_001.pkl
│   └── ...
├── backup/                     # Auto-generated backups
│   └── ...
├── pretrained_models/          # (Optional) Pre-trained weights
│   └── ...
├── model_comparison_results/   # Comparison outputs
│   └── ...
├── requirements.txt
├── auto_fix.py
├── ISSUES_AND_FIXES.md
└── [all .py files]
```

---

## ⚡ Quick Commands Cheat Sheet

```bash
# Install dependencies
pip install -r requirements.txt

# Apply fixes
python auto_fix.py

# Enroll all users (all methods)
for method in biohash bloom mlp iom_grp iom_urp rppca; do
    python enroll_templates_${method}_iris.py
done

# Show enrolled users
python show_users_iris.py

# Verify a user (BioHash example)
python verify_face_biohash_iris.py dataset/001/001_1_L.bmp 001

# Run comparison
python iris_comparison.py

# Use main menu
python main_iris.py
```

---

## 🎯 Success Criteria

✅ All 18 users enrolled with all 6 methods  
✅ Verification works for genuine matches  
✅ Verification rejects impostor attempts  
✅ Model comparison runs without errors  
✅ Templates are properly saved and loadable

---

## 📈 Performance Benchmarks (Expected)

| Method | Template Size | Enrollment Time | Verification Time | EER |
|--------|---------------|-----------------|-------------------|-----|
| BioHash | ~1KB | ~50ms | ~30ms | <5% |
| Bloom Filter | ~10KB | ~100ms | ~50ms | <8% |
| MLP-Hash | ~2KB | ~80ms | ~40ms | <6% |
| IOM-GRP | ~600B | ~60ms | ~35ms | <7% |
| IOM-URP | ~600B | ~60ms | ~35ms | <7% |
| RP-PCA | ~1KB | ~70ms | ~35ms | <6% |

*Actual performance may vary based on hardware and dataset*

---

## 📝 Notes

- ResNet-50 is used for feature extraction (2048-dim embeddings)
- All methods are cancelable and revocable
- Templates are user-specific (cannot be cross-matched)
- Threshold tuning may improve accuracy
- Consider using GPU for faster processing

---

*Last Updated: 2025-01-09*
