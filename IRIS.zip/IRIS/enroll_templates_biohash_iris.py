#!/usr/bin/env python3
"""
Enroll iris users using BioHash with multiple model support
"""

import os
import sys
import numpy as np
import joblib
from extract_embedding_iris_multi import extract_iris_embedding
from bio_hash import BioHash

TEMPLATE_DIR = 'templates_iris'
os.makedirs(TEMPLATE_DIR, exist_ok=True)

def enroll_biohash_iris(user_id, model_name='resnet50'):
    dataset_path = f'dataset/{user_id}'
    
    if not os.path.exists(dataset_path):
        print(f"[BioHash-IRIS:{user_id}] ✗ Dataset folder not found")
        return False
    
    embeddings = []
    
    for img_name in sorted(os.listdir(dataset_path)):
        if img_name.lower().endswith(('.bmp', '.jpg', '.jpeg', '.png')):
            img_path = os.path.join(dataset_path, img_name)
            try:
                emb = extract_iris_embedding(img_path, model_name=model_name)
                if emb is not None:
                    embeddings.append(emb)
            except Exception as e:
                print(f"[BioHash-IRIS:{user_id}] Warning: {img_name} - {e}")
                continue
    
    if len(embeddings) == 0:
        print(f"[BioHash-IRIS:{user_id}] ✗ No embeddings extracted")
        return False
    
    print(f"[BioHash-IRIS:{user_id}] ✓ Extracted {len(embeddings)} embeddings")
    
    # Compute mean embedding
    mean_embedding = np.mean(embeddings, axis=0)
    
    # Apply BioHash
    biohash = BioHash()
    template = biohash.generate(mean_embedding, reference_id=user_id)
    
    # Save template
    enrollment_data = {
        'template': template,
        'mean_embedding': mean_embedding,
        'embedding_dim': mean_embedding.shape[0],
        'num_images': len(embeddings),
        'model_name': model_name
    }
    
    template_path = os.path.join(TEMPLATE_DIR, f'biohash_iris_{model_name}_{user_id}.pkl')
    joblib.dump(enrollment_data, template_path)
    print(f"[BioHash-IRIS:{user_id}] ✓ Template saved ({model_name})")
    
    return True


def main():
    # Get model name from command line or use default
    model_name = sys.argv[1] if len(sys.argv) > 1 else 'resnet50'
    
    dataset_dir = "dataset"
    
    if not os.path.exists(dataset_dir):
        print(f"❌ ERROR: Dataset directory not found!")
        return
    
    user_folders = sorted([d for d in os.listdir(dataset_dir) 
                          if os.path.isdir(os.path.join(dataset_dir, d))])
    
    if len(user_folders) == 0:
        print(f"❌ ERROR: No user folders found!")
        return
    
    print(f"\n{'='*70}")
    print(f"AUTO-ENROLLING {len(user_folders)} USERS WITH BIOHASH")
    print(f"Model: {model_name}")
    print(f"{'='*70}\n")
    
    success_count = 0
    failed_users = []
    
    for user_id in user_folders:
        if enroll_biohash_iris(user_id, model_name=model_name):
            success_count += 1
        else:
            failed_users.append(user_id)
    
    print(f"\n{'='*70}")
    print(f"✓ Successfully enrolled: {success_count}/{len(user_folders)} users")
    if failed_users:
        print(f"✗ Failed: {len(failed_users)} users")
    print(f"{'='*70}\n")


if __name__ == '__main__':
    main()