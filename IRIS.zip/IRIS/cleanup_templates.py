#!/usr/bin/env python3
"""
Cleanup Script - Remove old/duplicate templates
"""

import os
import shutil

print("\n" + "="*70)
print("  TEMPLATE CLEANUP UTILITY")
print("="*70 + "\n")

# Check for multiple template folders
template_folders = []
for folder in ['templates_iris', 'templates_final', 'templates_iris_simple']:
    if os.path.exists(folder):
        template_folders.append(folder)
        count = len([f for f in os.listdir(folder) if f.endswith(('.pkl', '.bin'))])
        print(f"Found: {folder}/ with {count} templates")

if len(template_folders) == 0:
    print("No template folders found!")
    exit()

print(f"\nTotal folders: {len(template_folders)}")

if len(template_folders) > 1:
    print("\n⚠️  WARNING: Multiple template folders detected!")
    print("This can cause confusion and verification issues.")
    print("\nRecommendation: Keep only 'templates_iris' folder")
    
    choice = input("\nDelete other folders? (y/n): ").strip().lower()
    
    if choice == 'y':
        for folder in template_folders:
            if folder != 'templates_iris':
                print(f"\nDeleting: {folder}/")
                try:
                    shutil.rmtree(folder)
                    print(f"✓ Deleted: {folder}/")
                except Exception as e:
                    print(f"✗ Error deleting {folder}: {e}")
        
        print("\n✓ Cleanup complete!")
        print("Only 'templates_iris' folder remains.")
    else:
        print("\nNo cleanup performed.")

# Check templates_iris
if os.path.exists('templates_iris'):
    print(f"\n{'='*70}")
    print("  CURRENT TEMPLATES IN templates_iris/")
    print(f"{'='*70}\n")
    
    files = sorted([f for f in os.listdir('templates_iris') 
                   if f.endswith(('.pkl', '.bin'))])
    
    # Group by method
    methods = {}
    for f in files:
        if 'biohash' in f:
            method = 'biohash'
        elif 'bloom' in f:
            method = 'bloom'
        elif 'mlp' in f:
            method = 'mlp'
        elif 'iom_grp' in f:
            method = 'iom_grp'
        elif 'iom_urp' in f:
            method = 'iom_urp'
        elif 'rppca' in f:
            method = 'rppca'
        else:
            method = 'unknown'
        
        if method not in methods:
            methods[method] = []
        methods[method].append(f)
    
    print("Templates by method:")
    for method, files in sorted(methods.items()):
        print(f"  {method}: {len(files)} files")
    
    print(f"\nTotal templates: {len(files)}")
    
    # Option to delete all and re-enroll
    print("\n" + "="*70)
    print("  OPTIONS")
    print("="*70)
    print("1. Keep current templates")
    print("2. Delete ALL templates and re-enroll fresh")
    print("3. Exit")
    
    choice = input("\nChoose option (1/2/3): ").strip()
    
    if choice == '2':
        confirm = input("\n⚠️  This will delete ALL templates. Continue? (yes/no): ").strip().lower()
        if confirm == 'yes':
            for f in files:
                os.remove(os.path.join('templates_iris', f))
            print("\n✓ All templates deleted!")
            print("\nNext steps:")
            print("1. Run: python enroll_templates_biohash_iris.py")
            print("2. Run: python enroll_templates_bloom_iris.py")
            print("... (and other enrollment scripts)")
        else:
            print("\nCanceled.")
    else:
        print("\nNo changes made.")

print("\n" + "="*70 + "\n")
