#!/usr/bin/env python3
"""
Auto-verify all iris users using Bloom Filter scheme
Tests all enrolled users automatically
"""

import os
import sys
from extract_embedding_iris import extract_iris_embedding
from bloom_filter_hash import BloomFilterHash

TEMPLATE_DIR = 'templates_iris'
DATASET_DIR = 'dataset'

def verify_bloom_iris_auto():
    """Auto-verify all users by testing against their own templates"""
    
    results = {
        'total_users': 0,
        'successful_verifications': 0,
        'failed_verifications': 0,
    }
    
    user_folders = sorted([d for d in os.listdir(DATASET_DIR) 
                          if os.path.isdir(os.path.join(DATASET_DIR, d))])
    
    if len(user_folders) == 0:
        print("❌ No user folders found!")
        return results
    
    print(f"\n{'='*70}")
    print(f"AUTO-VERIFYING {len(user_folders)} USERS WITH BLOOM FILTER")
    print(f"{'='*70}\n")
    
    for user_id in user_folders:
        results['total_users'] += 1
        
        # Check template exists
        template_path = os.path.join(TEMPLATE_DIR, f'bloom_iris_{user_id}.bin')
        
        if not os.path.exists(template_path):
            print(f"[Bloom-IRIS:{user_id}] ✗ Template not found")
            results['failed_verifications'] += 1
            continue
        
        # Get first iris image for verification
        dataset_path = os.path.join(DATASET_DIR, user_id)
        iris_files = sorted([f for f in os.listdir(dataset_path) 
                            if f.lower().endswith(('.bmp', '.jpg', '.jpeg', '.png'))])
        
        if len(iris_files) == 0:
            print(f"[Bloom-IRIS:{user_id}] ✗ No iris images found")
            results['failed_verifications'] += 1
            continue
        
        # Use first image as probe
        probe_path = os.path.join(dataset_path, iris_files[0])
        
        try:
            # Load Bloom Filter
            bf = BloomFilterHash.deserialize(template_path)
            
            # Extract probe embedding
            emb = extract_iris_embedding(probe_path)
            if emb is None:
                print(f"[Bloom-IRIS:{user_id}] ✗ No iris detected in probe")
                results['failed_verifications'] += 1
                continue
            
            # Query Bloom Filter with user_id parameter
            match = bf.query(emb, user_id=user_id)
            
            if match:
                print(f"[Bloom-IRIS:{user_id}] ✓ VERIFIED")
                results['successful_verifications'] += 1
            else:
                print(f"[Bloom-IRIS:{user_id}] ✗ REJECTED")
                results['failed_verifications'] += 1
        
        except Exception as e:
            print(f"[Bloom-IRIS:{user_id}] ✗ Error: {e}")
            results['failed_verifications'] += 1
    
    # Print summary
    print(f"\n{'='*70}")
    print("VERIFICATION SUMMARY - BLOOM FILTER")
    print(f"{'='*70}")
    print(f"Total users tested: {results['total_users']}")
    print(f"✓ Verified: {results['successful_verifications']}")
    print(f"✗ Rejected: {results['failed_verifications']}")
    
    if results['total_users'] > 0:
        verification_rate = (results['successful_verifications'] / results['total_users']) * 100
        print(f"Verification Rate: {verification_rate:.1f}%")
    
    print(f"{'='*70}\n")
    
    return results


if __name__ == '__main__':
    verify_bloom_iris_auto()