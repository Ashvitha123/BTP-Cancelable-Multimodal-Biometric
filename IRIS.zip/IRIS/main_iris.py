#!/usr/bin/env python3
"""
Main menu driver for IRIS Biometric Template Protection System
Adapted from face project for iris biometric data (IITD database)
"""

import os
import sys
import subprocess

def main():
    """Main menu interface for iris biometric system"""
    
    while True:
        print("\n" + "=" * 70)
        print("  IRIS BIOMETRIC TEMPLATE PROTECTION - IITD DATABASE")
        print("  6 Cancelable Biometric Schemes")
        print("=" * 70)
        print("\n1. Enroll User (all 6 schemes)")
        print("2. Verify User (single scheme)")
        print("3. Run Full Comparison (all schemes)")
        print("4. List Enrolled Users")
        print("5. Exit")
        print("\n" + "=" * 70)
        
        choice = input("\nSelect option (1-5): ").strip()
        
        if choice == '1':
            enroll_user()
        elif choice == '2':
            verify_user()
        elif choice == '3':
            run_comparison()
        elif choice == '4':
            list_users()
        elif choice == '5':
            print("\nGoodbye!\n")
            sys.exit(0)
        else:
            print("\n✗ Invalid choice. Please try again.")

def enroll_user():
    """Enroll a user with all 6 schemes"""
    print("\n" + "-" * 70)
    user_id = input("Enter user ID (001-018): ").strip()
    
    if len(user_id) != 3 or not user_id.isdigit():
        print("✗ Invalid user ID format. Use 001-018")
        return
    
    dataset_path = f'dataset/{user_id}'
    if not os.path.exists(dataset_path):
        print(f"✗ User folder not found: {dataset_path}")
        return
    
    # List of all schemes
    schemes = [
        ('mlp', 'MLP-Hash'),
        ('biohash', 'BioHash'),
        ('rppca', 'RP-PCA'),
        ('iom_grp', 'IOM-GRP'),
        ('iom_urp', 'IOM-URP'),
        ('bloom', 'Bloom Filter')
    ]
    
    print(f"\n[*] Enrolling user {user_id} with all schemes...\n")
    
    for scheme_code, scheme_name in schemes:
        print(f"[*] Enrolling {scheme_name}...")
        cmd = f"python enroll_templates_{scheme_code}_iris.py {user_id}"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        
        if result.stdout:
            print(result.stdout.strip())
        if result.stderr:
            print(f"Error: {result.stderr.strip()}")
    
    print("\n✓ Enrollment complete!")

def verify_user():
    """Verify a user with a single scheme"""
    print("\n" + "-" * 70)
    
    probe = input("Probe image path: ").strip()
    if not os.path.exists(probe):
        print(f"✗ Image not found: {probe}")
        return
    
    user_id = input("Claimed user ID (001-018): ").strip()
    
    schemes = {
        '1': ('mlp', 'MLP-Hash'),
        '2': ('biohash', 'BioHash'),
        '3': ('rppca', 'RP-PCA'),
        '4': ('iom_grp', 'IOM-GRP'),
        '5': ('iom_urp', 'IOM-URP'),
        '6': ('bloom', 'Bloom Filter')
    }
    
    print("\nSelect scheme:")
    for key, (code, name) in schemes.items():
        print(f"{key}. {name}")
    
    choice = input("\nScheme (1-6): ").strip()
    
    if choice not in schemes:
        print("✗ Invalid choice")
        return
    
    scheme_code, scheme_name = schemes[choice]
    
    print(f"\n[*] Verifying with {scheme_name}...\n")
    cmd = f"python verify_face_{scheme_code}_iris.py {probe} {user_id}"
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    
    if result.stdout:
        print(result.stdout.strip())
    if result.stderr:
        print(f"Error: {result.stderr.strip()}")

def run_comparison():
    """Run comparison of all schemes"""
    print("\n" + "-" * 70)
    print("[*] Running iris_comparison.py...")
    print("-" * 70 + "\n")
    
    subprocess.run("python iris_comparison.py", shell=True)

def list_users():
    """List all enrolled users"""
    print("\n" + "-" * 70)
    print("[*] Running show_users_iris.py...")
    print("-" * 70 + "\n")
    
    subprocess.run("python show_users_iris.py", shell=True)

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user. Goodbye!\n")
        sys.exit(0)
