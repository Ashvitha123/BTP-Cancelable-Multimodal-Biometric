#!/usr/bin/env python3
"""
Multi-Model Iris Embedding Extraction
Supports: ResNet-50, EfficientNet-B4, DenseNet-121, ViT-B/16
"""

import os
import cv2
import numpy as np
import torch
import torch.nn as nn
from torchvision import models

# ImageNet normalization
IMAGENET_MEAN = np.array([0.485, 0.456, 0.406])
IMAGENET_STD = np.array([0.229, 0.224, 0.225])

# Set seeds for reproducibility
np.random.seed(42)
torch.manual_seed(42)
torch.cuda.manual_seed_all(42)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

_model_cache = {}

def load_model(model_name='resnet50'):
    """
    Load pretrained model - cached
    
    Supported models:
    - resnet50: ResNet-50 (25M params, 2048-dim)
    - efficientnet_b4: EfficientNet-B4 (19M params, 1792-dim)
    - densenet121: DenseNet-121 (8M params, 1024-dim)
    - vit_b_16: Vision Transformer (86M params, 768-dim)
    """
    global _model_cache
    
    if model_name in _model_cache:
        return _model_cache[model_name]
    
    print(f"Loading {model_name}...")
    
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    try:
        if model_name == 'resnet50':
            model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
            model = nn.Sequential(*list(model.children())[:-1])
            embedding_dim = 2048
            
        elif model_name == 'efficientnet_b4':
            model = models.efficientnet_b4(weights=models.EfficientNet_B4_Weights.IMAGENET1K_V1)
            model.classifier = nn.Identity()
            embedding_dim = 1792
            
        elif model_name == 'densenet121':
            model = models.densenet121(weights=models.DenseNet121_Weights.IMAGENET1K_V1)
            model.classifier = nn.Identity()
            embedding_dim = 1024
            
        elif model_name == 'vit_b_16':
            model = models.vit_b_16(weights=models.ViT_B_16_Weights.IMAGENET1K_V1)
            model.heads = nn.Identity()
            embedding_dim = 768
            
        else:
            raise ValueError(f"Unknown model: {model_name}")
        
        model = model.to(device)
        model.eval()
        
        for param in model.parameters():
            param.requires_grad = False
        
        _model_cache[model_name] = {
            'model': model,
            'embedding_dim': embedding_dim,
            'device': device
        }
        
        print(f"✓ Loaded {model_name} (embedding_dim={embedding_dim})")
        return _model_cache[model_name]
    
    except Exception as e:
        print(f"✗ Error loading {model_name}: {e}")
        return None


def extract_iris_embedding(image_path, model_name='resnet50', target_dim=512):
    """
    Extract iris embedding using specified model
    
    Args:
        image_path: Path to iris image
        model_name: 'resnet50', 'efficientnet_b4', 'densenet121', or 'vit_b_16'
        target_dim: Target embedding dimension (default: 512 for compatibility)
    
    Returns:
        np.ndarray: Embedding vector (float32), or None if error
    """
    try:
        # Read image
        img = cv2.imread(image_path)
        if img is None:
            return None
        
        # Convert to RGB
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # Handle grayscale
        if len(img.shape) == 2 or img.shape[2] == 1:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
        
        # Resize to 224x224
        img = cv2.resize(img, (224, 224))
        
        # Normalize to float32 [0, 1]
        img_norm = img.astype(np.float32) / 255.0
        
        # Apply ImageNet normalization
        img_norm = (img_norm - IMAGENET_MEAN) / IMAGENET_STD
        
        # Convert to tensor: (C, H, W) with batch
        img_tensor = torch.from_numpy(img_norm).permute(2, 0, 1).unsqueeze(0).float()
        
        # Load model
        model_dict = load_model(model_name)
        if model_dict is None:
            return None
            
        model = model_dict['model']
        device = model_dict['device']
        original_dim = model_dict['embedding_dim']
        
        img_tensor = img_tensor.to(device)
        
        # Extract features
        with torch.no_grad():
            features = model(img_tensor)
        
        # Convert to numpy and flatten
        embedding = features.cpu().numpy().flatten().astype(np.float32)
        
        # Project to target dimension if needed
        if target_dim and target_dim != original_dim:
            # Simple random projection for dimensionality reduction
            np.random.seed(42)  # Consistent projection
            projection_matrix = np.random.randn(original_dim, target_dim) / np.sqrt(original_dim)
            embedding = embedding @ projection_matrix
            embedding = embedding.astype(np.float32)
        
        return embedding
    
    except Exception as e:
        print(f"Error extracting embedding: {e}")
        return None


def get_available_models():
    """Return list of available models"""
    return {
        'resnet50': {'params': '25M', 'dim': 2048, 'type': 'CNN'},
        'efficientnet_b4': {'params': '19M', 'dim': 1792, 'type': 'CNN'},
        'densenet121': {'params': '8M', 'dim': 1024, 'type': 'CNN'},
        'vit_b_16': {'params': '86M', 'dim': 768, 'type': 'Transformer'},
    }


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1:
        model_name = sys.argv[1]
        print(f"\nTesting {model_name}...")
        
        # Test with a sample image
        test_image = 'dataset/001/01_L.bmp'
        if os.path.exists(test_image):
            emb = extract_iris_embedding(test_image, model_name=model_name)
            if emb is not None:
                print(f"✓ Embedding shape: {emb.shape}")
                print(f"✓ Embedding norm: {np.linalg.norm(emb):.3f}")
                print(f"✓ Embedding mean: {np.mean(emb):.6f}")
                print(f"✓ Embedding std: {np.std(emb):.6f}")
            else:
                print("✗ Failed to extract embedding")
        else:
            print(f"✗ Test image not found: {test_image}")
    else:
        print("\n" + "="*70)
        print("  MULTI-MODEL IRIS EMBEDDING EXTRACTION")
        print("="*70 + "\n")
        print("Available models:")
        for name, info in get_available_models().items():
            print(f"  • {name:20} {info['params']:>8} params, {info['dim']:>6}-dim, {info['type']}")
        print("\n" + "="*70)
        print("\nUsage:")
        print("  python extract_embedding_iris_multi.py <model_name>")
        print("\nExample:")
        print("  python extract_embedding_iris_multi.py efficientnet_b4")
        print("="*70 + "\n")
