#!/usr/bin/env python3
"""
MLP-Hash (Multilayer Perceptron Hash)

Cancelable biometric template protection using MLP-based random projections.
Generates user-specific cancelable templates with security and revocability.
"""

import numpy as np
import hashlib

class MLPHash:
    """MLP-Hash transformer for biometric template protection."""
    
    def __init__(self, mlp_length=None, seed_offset=0):
        """
        Initialize MLP-Hash.
        
        Args:
            mlp_length: List of layer sizes for MLP projections
            seed_offset: Offset for user seed generation
        """
        if mlp_length is None:
            mlp_length = [512, 512, 512]
        self.mlp_length = mlp_length
        self.seed_offset = seed_offset
    
    def generate_user_seed(self, reference_id):
        """Generate deterministic user-specific seed."""
        h = hashlib.sha256(reference_id.encode('utf-8')).hexdigest()
        seed = self.seed_offset + int(h, 16) % (10**8)
        return seed
    
    def relu(self, x):
        """ReLU activation function."""
        return np.maximum(0, x)
    
    def gram_schmidt(self, M):
        """Gram-Schmidt orthogonalization."""
        Q, _ = np.linalg.qr(M)
        return Q
    
    def hash_feature_vector(self, feature_vector, reference_id=None):
        """
        Create MLP-Hash from feature vector.
        
        Args:
            feature_vector: Input embedding
            reference_id: User ID for seed generation
        
        Returns:
            Binary hash code
        """
        if reference_id is None:
            seed = self.seed_offset
        else:
            seed = self.generate_user_seed(reference_id)
        
        np.random.seed(seed)
        
        # MLP forward pass with ReLU activations
        Γ = feature_vector.copy()
        
        for L in self.mlp_length:
            M = np.random.randn(Γ.size, L)
            M_orth = self.gram_schmidt(M)
            Γ = self.relu(Γ @ M_orth)
        
        # Binarization using mean threshold
        τ = np.mean(Γ)
        P = (Γ > τ).astype(np.uint8)
        
        return P
    
    def hamming_distance(self, hash1, hash2):
        """Compute Hamming distance between two hashes."""
        if len(hash1) != len(hash2):
            raise ValueError("Hashes must have same length")
        return np.count_nonzero(hash1 != hash2) / len(hash1)
    
    def hamming_similarity(self, hash1, hash2):
        """Compute Hamming similarity between two hashes."""
        return 1.0 - self.hamming_distance(hash1, hash2)


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1:
        print("[MLP-Hash] Initialized")
    else:
        print("MLP-Hash module loaded")
