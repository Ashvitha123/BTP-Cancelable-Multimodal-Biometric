# Project Architecture - Iris Biometric Template Protection

## 🏗️ System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    IRIS RECOGNITION SYSTEM                      │
│           Cancelable Biometric Template Protection             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────┐
        │      IITD IRIS DATASET (18 Users)  │
        │     - 10-15 images per user        │
        │     - Left & Right eyes            │
        │     - Format: .bmp                 │
        └─────────────────────────────────────┘
                              │
                              ▼
```

## 📊 Data Flow Architecture

```
┌─────────────┐
│ Iris Image  │
│  (.bmp)     │
└──────┬──────┘
       │
       ▼
┌──────────────────────────────────────────┐
│   FEATURE EXTRACTION (Deep Learning)     │
│   ────────────────────────────────────   │
│   Models Available:                      │
│   • ResNet-50      (23.5M params) ✓ Best│
│   • EfficientNet   (19.3M params)       │
│   • VGG-16         (138M params)        │
│   • MobileNet-v2   (3.5M params)        │
│   ────────────────────────────────────   │
│   Output: 2048-dim embedding vector      │
└──────────────┬───────────────────────────┘
               │
               ▼
┌──────────────────────────────────────────┐
│   TEMPLATE PROTECTION (6 Methods)        │
│   ────────────────────────────────────   │
│   1. BioHash           (Random Proj.)    │
│   2. Bloom Filter      (Probabilistic)   │
│   3. MLP-Hash          (Neural Hash)     │
│   4. IOM-GRP           (Index-of-Max)    │
│   5. IOM-URP           (Random Perm.)    │
│   6. RP-PCA            (PCA Transform)   │
│   ────────────────────────────────────   │
│   Properties:                            │
│   • Cancelable ✓                         │
│   • Revocable ✓                          │
│   • Non-invertible ✓                     │
└──────────────┬───────────────────────────┘
               │
               ▼
┌──────────────────────────────────────────┐
│        PROTECTED TEMPLATE STORAGE        │
│   templates_iris/                        │
│   • biohash_iris_{user_id}.pkl          │
│   • bloom_iris_{user_id}.bin            │
│   • mlp_iris_{user_id}.bin              │
│   • iom_grp_iris_{user_id}.pkl          │
│   • iom_urp_iris_{user_id}.pkl          │
│   • rppca_iris_{user_id}.pkl            │
└──────────────┬───────────────────────────┘
               │
               ▼
┌──────────────────────────────────────────┐
│         VERIFICATION PROCESS             │
│   Compare probe template vs enrolled     │
│   Compute similarity/distance            │
│   Apply threshold decision               │
│   ────────────────────────────────────   │
│   Output: ACCEPT / REJECT                │
└──────────────────────────────────────────┘
```

## 🔧 Module Dependencies

```
extract_embedding_iris.py
    ├── torch
    ├── torchvision.models (ResNet50)
    ├── cv2 (OpenCV)
    └── numpy
    
bio_hash.py
    ├── numpy
    └── hashlib
    
bloom_filter_hash.py
    ├── numpy
    ├── hashlib
    └── pickle
    
mlp_hash.py
    ├── numpy
    └── hashlib
    
iom_grp_hash.py
    ├── numpy
    └── hashlib
    
iom_urp_hash.py
    ├── numpy
    └── hashlib
    
rp_pca_hash.py
    ├── numpy
    ├── hashlib
    └── sklearn.decomposition (PCA)
```

## 📁 File Organization

```
BTP_IRIS/
│
├── 📂 Core Modules
│   ├── extract_embedding_iris.py      ★ Feature extraction (ResNet50)
│   ├── bio_hash.py                    ★ BioHash algorithm
│   ├── bloom_filter_hash.py           ★ Bloom Filter algorithm
│   ├── mlp_hash.py                    ★ MLP-Hash algorithm
│   ├── iom_grp_hash.py                ★ IOM-GRP algorithm
│   ├── iom_urp_hash.py                ★ IOM-URP algorithm
│   └── rp_pca_hash.py                 ★ RP-PCA algorithm
│
├── 📂 Enrollment Scripts
│   ├── enroll_templates_biohash_iris.py
│   ├── enroll_templates_bloom_iris.py
│   ├── enroll_templates_mlp_iris.py
│   ├── enroll_templates_iom_grp_iris.py
│   ├── enroll_templates_iom_urp_iris.py
│   └── enroll_templates_rppca_iris.py
│
├── 📂 Verification Scripts
│   ├── verify_face_biohash_iris.py
│   ├── verify_face_bloom_iris.py
│   ├── verify_face_mlp_iris.py
│   ├── verify_face_iom_grp_iris.py
│   ├── verify_face_iom_urp_iris.py
│   └── verify_face_rppca_iris.py
│
├── 📂 Analysis & Comparison
│   ├── iris_models.py                 ★ Model architectures
│   ├── iris_comparison.py             ★ Model benchmarking
│   ├── compare_iris_models.py         ★ Performance comparison
│   └── show_users_iris.py             ★ Enrollment status
│
├── 📂 Utilities
│   ├── main_iris.py                   ★ Main menu interface
│   └── download_pretrained_models.py  ★ Model downloader
│
└── 📂 Data & Results
    ├── dataset/                        ★ IITD iris images
    ├── templates_iris/                 ★ Protected templates
    ├── pretrained_models/              ★ Model weights
    ├── model_comparison_results/       ★ Benchmark results
    └── backup/                         ★ Backup files
```

## 🔄 Enrollment Workflow

```
START
  │
  ├─► Load all iris images for user
  │
  ├─► Extract embeddings (ResNet50)
  │    └─► Get 2048-dim vector per image
  │
  ├─► Compute mean embedding
  │    └─► Average across all images
  │
  ├─► Apply template protection
  │    ├─► BioHash: Random projection + binarization
  │    ├─► Bloom: Hash to bit array positions
  │    ├─► MLP: Multi-layer projection + binarization
  │    ├─► IOM-GRP: Gaussian random proj. + index selection
  │    ├─► IOM-URP: User-specific permutation + index selection
  │    └─► RP-PCA: PCA transform + permutation + binarization
  │
  └─► Save protected template
       └─► Store in templates_iris/
END
```

## 🔍 Verification Workflow

```
START
  │
  ├─► Load probe iris image
  │
  ├─► Extract embedding (ResNet50)
  │    └─► Get 2048-dim vector
  │
  ├─► Load enrolled template for claimed ID
  │
  ├─► Apply same template protection to probe
  │    └─► Use same user-specific parameters
  │
  ├─► Compare protected templates
  │    ├─► BioHash: Hamming distance
  │    ├─► Bloom: Query membership
  │    ├─► MLP: Euclidean/Hamming distance
  │    ├─► IOM-GRP: Hamming similarity on indices
  │    ├─► IOM-URP: Hamming similarity on indices
  │    └─► RP-PCA: Distance in PCA space
  │
  ├─► Apply threshold decision
  │    └─► Distance < threshold → ACCEPT
  │         Distance ≥ threshold → REJECT
  │
END
```

## 🎯 Template Protection Methods Comparison

| Method | Type | Template Size | Security | Speed | Accuracy |
|--------|------|---------------|----------|-------|----------|
| **BioHash** | Random Projection | 1KB | High | Fast | High |
| **Bloom Filter** | Probabilistic | 10KB | Medium | Very Fast | Medium |
| **MLP-Hash** | Neural Network | 2KB | High | Medium | High |
| **IOM-GRP** | Index Selection | 600B | High | Fast | High |
| **IOM-URP** | Permutation | 600B | High | Fast | High |
| **RP-PCA** | PCA Transform | 1KB | Medium | Fast | Medium |

## 🔐 Security Properties

### Cancelability
All methods support template revocation:
- Generate new template with different seed/key
- Old template becomes invalid
- No need to re-capture biometric data

### Non-invertibility
Protected templates cannot be reversed:
- One-way transformation
- Cannot reconstruct original embedding
- Cannot reconstruct original iris image

### Unlinkability
Templates from different applications are unlinkable:
- Different user-specific keys per application
- Cross-matching between databases is prevented
- Privacy is preserved

## 📈 Performance Metrics

### Evaluation Metrics
- **FAR** (False Accept Rate): Impostor accepted as genuine
- **FRR** (False Reject Rate): Genuine rejected as impostor
- **EER** (Equal Error Rate): Point where FAR = FRR
- **Rank-1 Accuracy**: Top match is correct identity
- **Rank-5 Accuracy**: Correct identity in top 5 matches

### Expected Performance (IITD Dataset)
```
Method          EER      Rank-1    Enrollment    Verification
─────────────────────────────────────────────────────────────
BioHash         <5%      >95%      ~50ms         ~30ms
Bloom Filter    <8%      >90%      ~100ms        ~50ms
MLP-Hash        <6%      >93%      ~80ms         ~40ms
IOM-GRP         <7%      >92%      ~60ms         ~35ms
IOM-URP         <7%      >92%      ~60ms         ~35ms
RP-PCA          <6%      >93%      ~70ms         ~35ms
```

## 🧪 Testing Strategy

### Unit Tests
- Test each hash algorithm independently
- Verify reproducibility (same input → same output)
- Test with different user IDs

### Integration Tests
- Enrollment → Verification pipeline
- Cross-method comparison
- Error handling

### Performance Tests
- Speed benchmarks
- Memory usage
- Scalability (number of users)

### Security Tests
- Non-invertibility
- Unlinkability
- Revocability

## 🚀 Optimization Opportunities

### Current Bottlenecks
1. **Feature Extraction**: ResNet-50 forward pass (~30-50ms)
2. **Template Generation**: Varies by method (5-50ms)
3. **Disk I/O**: Template loading/saving

### Potential Improvements
1. **GPU Acceleration**: Use CUDA for batch processing
2. **Model Quantization**: Reduce ResNet-50 size
3. **Caching**: Keep templates in memory
4. **Parallel Processing**: Multi-threaded verification
5. **Lighter Models**: Use MobileNet-v2 for embedded systems

## 🎓 Research Extensions

### Possible Enhancements
1. **Multi-modal Fusion**: Combine iris with face/fingerprint
2. **Adaptive Thresholds**: Per-user threshold optimization
3. **Deep Hashing**: End-to-end trainable hashing
4. **Homomorphic Encryption**: Encrypted template matching
5. **Federated Learning**: Distributed template protection

---

*Architecture Version: 1.0*  
*Last Updated: 2025-01-09*
