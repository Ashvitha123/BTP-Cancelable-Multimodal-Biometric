import pickle
import numpy as np


try:
    with open('biohash_enroll_db.pkl', 'rb') as f:
        protected_db = pickle.load(f)
    
    print("BioHash Protected Database Contents:")
    print("=" * 40)
    
    for user_id, templates in protected_db.items():
        print(f"\nUser: {user_id}")
        print(f"Number of enrolled templates: {len(templates)}")
        
        for i, (ref_id, protected_template) in enumerate(templates, 1):
            print(f"  Template {i}: {ref_id}")
            print(f"    BioHash length: {len(protected_template)}")
            print(f"    Ones ratio: {np.sum(protected_template) / len(protected_template):.3f}")
    
    print(f"\nTotal users: {len(protected_db)}")
    total_templates = sum(len(templates) for templates in protected_db.values())
    print(f"Total templates: {total_templates}")
    
except FileNotFoundError:
    print("Error: biohash_enroll_db.pkl not found. Please run enrollment first.")
except Exception as e:
    print(f"Error reading database: {str(e)}")
