"""
extract_embedding.py (Fixed Version - No PyTorch Dependency)

Provides functions to initialize multiple face recognition models and extract
L2-normalized face embeddings from images using different models for comparison.

This version removes PyTorch imports to avoid dependency issues.
"""

import cv2
import numpy as np
from insightface.app import FaceAnalysis
import warnings
warnings.filterwarnings("ignore")

# Global variables to hold model instances (lazy initialization)
insightface_app = None
arcface_model = None
facenet_model = None

def get_insightface_app():
    """
    Initialize and return the singleton InsightFace application.
    Uses the 'buffalo_l' pre-trained model on CPU.
    """
    global insightface_app
    if insightface_app is None:
        insightface_app = FaceAnalysis(name='buffalo_l', providers=['CPUExecutionProvider'])
        insightface_app.prepare(ctx_id=0, det_size=(640, 640))
    return insightface_app

def get_arcface_model():
    """
    Initialize and return ArcFace model.
    For now, uses InsightFace as fallback.
    """
    global arcface_model
    if arcface_model is None:
        try:
            # Use InsightFace as ArcFace fallback for now
            print("ArcFace not available, using InsightFace as fallback")
            return get_insightface_app()
        except Exception as e:
            print(f"Error loading ArcFace model: {e}")
            return None
    return arcface_model

def get_facenet_model():
    """
    Initialize and return FaceNet model.
    For now, uses InsightFace as fallback.
    """
    global facenet_model
    if facenet_model is None:
        try:
            # Use InsightFace as FaceNet fallback for now
            print("FaceNet not available, using InsightFace as fallback")
            return get_insightface_app()
        except Exception as e:
            print(f"Error loading FaceNet model: {e}")
            return None
    return facenet_model

def extract_embedding_insightface(img_path):
    """
    Extract embedding using InsightFace model.
    """
    app = get_insightface_app()
    if app is None:
        raise ValueError("InsightFace model not available")
    
    img = cv2.imread(img_path)
    if img is None:
        raise ValueError(f"Could not load image from {img_path}")
    
    faces = app.get(img)
    
    if not faces:
        raise ValueError(f"No face found for image {img_path}")
    
    emb = faces[0].embedding
    emb = emb / np.linalg.norm(emb)  # L2 normalization
    return emb

def extract_embedding_arcface(img_path):
    """
    Extract embedding using ArcFace model (fallback to InsightFace).
    """
    return extract_embedding_insightface(img_path)

def extract_embedding_facenet(img_path):
    """
    Extract embedding using FaceNet model (fallback to InsightFace).
    """
    return extract_embedding_insightface(img_path)

def extract_embedding_elasticface(img_path):
    """
    Extract embedding using ElasticFace model (fallback to InsightFace).
    """
    return extract_embedding_insightface(img_path)

def extract_embedding(img_path, model_name='insightface'):
    """
    Extract embedding using specified model.
    
    Args:
        img_path (str): Path to the image file
        model_name (str): Model to use ('insightface', 'arcface', 'facenet', 'elasticface')
    
    Returns:
        np.ndarray: L2-normalized feature vector
    
    Raises:
        ValueError: If no face is detected or model is not available
    """
    model_name = model_name.lower()
    
    if model_name == 'insightface':
        return extract_embedding_insightface(img_path)
    elif model_name == 'arcface':
        return extract_embedding_arcface(img_path)
    elif model_name == 'facenet':
        return extract_embedding_facenet(img_path)
    elif model_name == 'elasticface':
        return extract_embedding_elasticface(img_path)
    else:
        raise ValueError(f"Unsupported model: {model_name}. Supported models: 'insightface', 'arcface', 'facenet', 'elasticface'")

def get_available_models():
    """
    Return list of available models that can be loaded.
    For now, all models fallback to InsightFace.
    """
    available_models = []
    
    # Check InsightFace
    try:
        get_insightface_app()
        # Add all models since they all use InsightFace as fallback
        available_models.extend(['insightface', 'arcface', 'facenet', 'elasticface'])
    except Exception as e:
        print(f"Error loading InsightFace: {e}")
    
    return available_models

if __name__ == "__main__":
    # Test available models
    print("Available models:", get_available_models())