"""
verify_face.py (Updated Multi-Model Version)

Verifies a probe face image against enrolled protected templates using multiple models.
Allows comparison of verification performance across different face recognition models.

1. Extracts the probe embedding using specified model and applies MLP-hash.
2. Computes similarity scores against all enrolled templates for claimed user.
3. Provides detailed comparison results across models.
"""

import pickle
import os
import numpy as np
from mlp_hash import MLPHashTransformer
from extract_embedding import extract_embedding, get_available_models

def hamming_score(a, b):
    """
    Compute similarity score between two binary arrays.
    Score = 1 - (Hamming distance / length)
    Returns value in [0, 1], where 1 = identical.
    """
    return 1 - np.count_nonzero(a != b) / len(a)

def cosine_similarity(a, b):
    """
    Compute cosine similarity between two feature vectors.
    """
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

def euclidean_distance(a, b):
    """
    Compute Euclidean distance between two feature vectors.
    Returns distance (lower is more similar).
    """
    return np.linalg.norm(a - b)

def verify_single_model(probe_img_path, claimed_user, model_name, threshold=0.95):
    """
    Verify face using a single model.
    
    Args:
        probe_img_path (str): Path to probe image
        claimed_user (str): Claimed user ID
        model_name (str): Model to use for verification
        threshold (float): Acceptance threshold
    
    Returns:
        dict: Verification results including scores and decision
    """
    # Initialize transformer
    mlphash = MLPHashTransformer()
    
    # Load the enrolled database for this model
    db_filename = f'enroll_db_{model_name}.pkl'
    
    if not os.path.exists(db_filename):
        return {
            'error': f"Database file '{db_filename}' not found",
            'model': model_name,
            'success': False
        }
    
    try:
        with open(db_filename, 'rb') as f:
            protected_db = pickle.load(f)
    except Exception as e:
        return {
            'error': f"Error loading database: {e}",
            'model': model_name,
            'success': False
        }
    
    # Check if claimed user exists in database
    if claimed_user not in protected_db:
        return {
            'error': f"User '{claimed_user}' not found in {model_name} database",
            'model': model_name,
            'success': False,
            'available_users': list(protected_db.keys())
        }
    
    try:
        # Extract probe embedding
        probe_emb = extract_embedding(probe_img_path, model_name)
        
        # Create probe reference ID
        probe_reference = os.path.splitext(os.path.basename(probe_img_path))[0]
        
        # Create protected template for probe
        probe_protected = mlphash.create_mlp_hash(probe_emb, probe_reference)
        
        # Compare against enrolled templates
        scores = []
        reference_ids = []
        
        for ref_id, enrolled_tpl in protected_db[claimed_user]:
            score = hamming_score(probe_protected, enrolled_tpl)
            scores.append(score)
            reference_ids.append(ref_id)
        
        # Calculate statistics
        max_score = max(scores) if scores else 0
        avg_score = np.mean(scores) if scores else 0
        min_score = min(scores) if scores else 0
        
        # Make decision
        authentication_success = max_score > threshold
        
        return {
            'model': model_name,
            'success': True,
            'scores': scores,
            'reference_ids': reference_ids,
            'max_score': max_score,
            'avg_score': avg_score,
            'min_score': min_score,
            'threshold': threshold,
            'authentication_success': authentication_success,
            'num_templates': len(scores)
        }
        
    except Exception as e:
        return {
            'error': f"Error during verification: {e}",
            'model': model_name,
            'success': False
        }

def verify_multi_model(probe_img_path, claimed_user, models=None, threshold=0.95):
    """
    Verify face using multiple models and compare results.
    
    Args:
        probe_img_path (str): Path to probe image
        claimed_user (str): Claimed user ID
        models (list): List of models to use. If None, uses all available models.
        threshold (float): Acceptance threshold
    
    Returns:
        dict: Comprehensive verification results across all models
    """
    if models is None:
        models = get_available_models()
    
    results = {}
    
    print(f"Verifying '{probe_img_path}' against user '{claimed_user}' using {len(models)} models...")
    print("=" * 70)
    
    for model_name in models:
        print(f"\nTesting {model_name.upper()}...")
        result = verify_single_model(probe_img_path, claimed_user, model_name, threshold)
        results[model_name] = result
        
        if result['success']:
            print(f"  ✓ Authentication: {'SUCCESS' if result['authentication_success'] else 'FAILED'}")
            print(f"  ✓ Max Score: {result['max_score']:.4f}")
            print(f"  ✓ Avg Score: {result['avg_score']:.4f}")
            print(f"  ✓ Templates: {result['num_templates']}")
        else:
            print(f"  ✗ Error: {result['error']}")
    
    return results

def compare_verification_results(results):
    """
    Compare and analyze verification results across models.
    
    Args:
        results (dict): Verification results from multiple models
    """
    print(f"\n{'='*70}")
    print("VERIFICATION RESULTS COMPARISON")
    print(f"{'='*70}")
    
    # Table header
    print(f"{'Model':<12} {'Auth':<6} {'Max Score':<10} {'Avg Score':<10} {'Templates':<10} {'Status'}")
    print("-" * 70)
    
    successful_models = []
    failed_models = []
    
    for model_name, result in results.items():
        if result['success']:
            auth_status = "PASS" if result['authentication_success'] else "FAIL"
            print(f"{model_name:<12} {auth_status:<6} {result['max_score']:<10.4f} "
                  f"{result['avg_score']:<10.4f} {result['num_templates']:<10} {'OK'}")
            
            if result['authentication_success']:
                successful_models.append((model_name, result['max_score']))
            else:
                failed_models.append(model_name)
        else:
            print(f"{model_name:<12} {'ERROR':<6} {'-':<10} {'-':<10} {'-':<10} {'FAIL'}")
            failed_models.append(model_name)
    
    # Summary
    print(f"\n{'='*70}")
    print("SUMMARY")
    print(f"{'='*70}")
    
    if successful_models:
        print(f"✓ Models that authenticated successfully:")
        for model, score in successful_models:
            print(f"  - {model}: {score:.4f}")
    
    if failed_models:
        print(f"✗ Models that failed authentication:")
        for model in failed_models:
            print(f"  - {model}")
    
    # Best performing model
    if successful_models:
        best_model, best_score = max(successful_models, key=lambda x: x[1])
        print(f"\n🏆 Best performing model: {best_model} (score: {best_score:.4f})")

def main():
    print("MLP-Hashing Verification")
    print("=" * 50)

    probe = input("Enter probe image path: ").strip()
    user  = input("Enter claimed user ID: ").strip()

    threshold = 0.95
    models = get_available_models()
    print(f"Threshold: {threshold}")
    print(f"Models: {models}")

    results = verify_multi_model(probe, user, models, threshold)
    compare_verification_results(results)


if __name__ == "__main__":
    main()