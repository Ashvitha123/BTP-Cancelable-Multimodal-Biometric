"""
hash_comparison.py

Comprehensive comparison tool for MLP-hashing vs BioHashing template protection methods.
This script provides detailed analysis and comparison of both hashing approaches
on the same face recognition datasets and models.

Features:
1. Performance comparison (accuracy, EER, etc.)
2. Security analysis (entropy, balance, etc.)
3. Computational efficiency analysis
4. Template quality assessment
5. Cross-method validation
"""

import os
import pickle
import numpy as np
import time
from mlp_hash import MLPHashTransformer
from bio_hash import BioHashTransformer
from extract_embedding import extract_embedding, get_available_models

def extract_and_protect_embeddings(image_path, reference_id, models, mlp_hash_length=[1024, 1024, 1024], bio_hash_length=1024):
    """
    Extract embeddings and create both MLP-hash and BioHash protected templates.
    
    Args:
        image_path (str): Path to face image
        reference_id (str): Reference identifier for user
        models (list): List of face recognition models to use
        mlp_hash_length (list): MLP network architecture
        bio_hash_length (int): BioHash length
    
    Returns:
        dict: Dictionary containing both types of protected templates for each model
    """
    results = {}
    
    # Initialize transformers
    mlp_transformer = MLPHashTransformer(mlp_length=mlp_hash_length)
    bio_transformer = BioHashTransformer(hash_length=bio_hash_length)
    
    for model_name in models:
        try:
            # Extract embedding
            start_time = time.time()
            embedding = extract_embedding(image_path, model_name)
            embedding_time = time.time() - start_time
            
            # Create MLP-hash
            start_time = time.time()
            mlp_hash = mlp_transformer.create_mlp_hash(embedding, reference_id)
            mlp_time = time.time() - start_time
            
            # Create BioHash
            start_time = time.time()
            bio_hash = bio_transformer.create_bio_hash(embedding, reference_id)
            bio_time = time.time() - start_time
            
            # Get statistics for both methods
            mlp_stats = {
                'length': len(mlp_hash),
                'ones_count': int(np.sum(mlp_hash)),
                'ones_ratio': np.mean(mlp_hash),
                'entropy': calculate_binary_entropy(mlp_hash)
            }
            
            bio_stats = bio_transformer.get_hash_statistics(bio_hash)
            
            results[model_name] = {
                'embedding': embedding,
                'embedding_time': embedding_time,
                'mlp_hash': {
                    'template': mlp_hash,
                    'creation_time': mlp_time,
                    'statistics': mlp_stats
                },
                'bio_hash': {
                    'template': bio_hash,
                    'creation_time': bio_time,
                    'statistics': bio_stats
                }
            }
            
        except Exception as e:
            print(f"Error processing {model_name} for {reference_id}: {e}")
            results[model_name] = None
    
    return results

def calculate_binary_entropy(binary_array):
    """Calculate Shannon entropy of binary array."""
    ones_ratio = np.mean(binary_array)
    zeros_ratio = 1.0 - ones_ratio
    
    if ones_ratio > 0 and zeros_ratio > 0:
        entropy = -(ones_ratio * np.log2(ones_ratio) + zeros_ratio * np.log2(zeros_ratio))
    else:
        entropy = 0.0
    
    return entropy

def create_test_pairs_for_comparison(dataset_folder="dataset", max_pairs=100):
    """
    Create test pairs for comparing both hashing methods.
    
    Args:
        dataset_folder (str): Dataset folder
        max_pairs (int): Maximum number of pairs to create
    
    Returns:
        tuple: (same_person_pairs, different_person_pairs)
    """
    if not os.path.exists(dataset_folder):
        return [], []
    
    image_files = [f for f in os.listdir(dataset_folder) if f.endswith('.jpg')]
    
    # Group images by user
    user_images = {}
    for fname in image_files:
        name_parts = fname.split('_')
        user_id = "_".join(name_parts[:2])
        if user_id not in user_images:
            user_images[user_id] = []
        user_images[user_id].append(os.path.join(dataset_folder, fname))
    
    same_pairs = []
    different_pairs = []
    
    # Create same-person pairs
    pair_count = 0
    for user_id, images in user_images.items():
        if len(images) >= 2:
            for i in range(len(images)):
                for j in range(i + 1, len(images)):
                    if pair_count >= max_pairs // 2:
                        break
                    same_pairs.append((images[i], images[j], True))
                    pair_count += 1
                if pair_count >= max_pairs // 2:
                    break
    
    # Create different-person pairs
    users = list(user_images.keys())
    pair_count = 0
    
    for i in range(len(users)):
        for j in range(i + 1, len(users)):
            if pair_count >= max_pairs // 2:
                break
            if user_images[users[i]] and user_images[users[j]]:
                different_pairs.append((
                    user_images[users[i]][0], 
                    user_images[users[j]][0], 
                    False
                ))
                pair_count += 1
    
    return same_pairs, different_pairs

def compare_hashing_methods_performance(test_pairs, models, mlp_threshold=0.95, bio_threshold=0.5):
    """
    Compare performance of MLP-hashing vs BioHashing on test pairs.
    
    Args:
        test_pairs (list): List of test pairs
        models (list): List of models to test
        mlp_threshold (float): MLP-hash similarity threshold
        bio_threshold (float): BioHash similarity threshold
    
    Returns:
        dict: Performance comparison results
    """
    # Initialize transformers
    mlp_transformer = MLPHashTransformer()
    bio_transformer = BioHashTransformer()
    
    results = {
        'models': models,
        'mlp_results': {model: {'scores': [], 'labels': [], 'times': []} for model in models},
        'bio_results': {model: {'scores': [], 'labels': [], 'times': []} for model in models},
        'template_stats': {model: {'mlp': [], 'bio': []} for model in models}
    }
    
    print(f"Comparing hashing methods on {len(test_pairs)} pairs...")
    
    for i, (img1_path, img2_path, is_same) in enumerate(test_pairs):
        if i % 10 == 0:
            print(f"Processing pair {i+1}/{len(test_pairs)}...")
        
        ref1 = os.path.splitext(os.path.basename(img1_path))[0]
        ref2 = os.path.splitext(os.path.basename(img2_path))[0]
        
        for model_name in models:
            try:
                # Extract embeddings
                emb1 = extract_embedding(img1_path, model_name)
                emb2 = extract_embedding(img2_path, model_name)
                
                # MLP-hash comparison
                start_time = time.time()
                mlp_hash1 = mlp_transformer.create_mlp_hash(emb1, ref1)
                mlp_hash2 = mlp_transformer.create_mlp_hash(emb2, ref2)
                mlp_similarity = 1 - np.count_nonzero(mlp_hash1 != mlp_hash2) / len(mlp_hash1)
                mlp_time = time.time() - start_time
                
                # BioHash comparison  
                start_time = time.time()
                bio_hash1 = bio_transformer.create_bio_hash(emb1, ref1)
                bio_hash2 = bio_transformer.create_bio_hash(emb2, ref2)
                bio_similarity = bio_transformer.hamming_similarity(bio_hash1, bio_hash2)
                bio_time = time.time() - start_time
                
                # Store results
                results['mlp_results'][model_name]['scores'].append(mlp_similarity)
                results['mlp_results'][model_name]['labels'].append(is_same)
                results['mlp_results'][model_name]['times'].append(mlp_time)
                
                results['bio_results'][model_name]['scores'].append(bio_similarity)
                results['bio_results'][model_name]['labels'].append(is_same)
                results['bio_results'][model_name]['times'].append(bio_time)
                
                # Template statistics (only for first pair to avoid redundancy)
                if i == 0:
                    mlp_stats = {
                        'entropy': calculate_binary_entropy(mlp_hash1),
                        'ones_ratio': np.mean(mlp_hash1),
                        'length': len(mlp_hash1)
                    }
                    bio_stats = bio_transformer.get_hash_statistics(bio_hash1)
                    
                    results['template_stats'][model_name]['mlp'].append(mlp_stats)
                    results['template_stats'][model_name]['bio'].append(bio_stats)
                
            except Exception as e:
                print(f"Error processing pair with {model_name}: {e}")
                continue
    
    return results

def calculate_performance_metrics(scores, labels, threshold):
    """Calculate performance metrics given scores, labels, and threshold."""
    if len(scores) == 0:
        return {}
    
    predictions = [score >= threshold for score in scores]
    
    # Calculate confusion matrix elements
    tp = sum(1 for pred, label in zip(predictions, labels) if pred and label)
    tn = sum(1 for pred, label in zip(predictions, labels) if not pred and not label)
    fp = sum(1 for pred, label in zip(predictions, labels) if pred and not label)
    fn = sum(1 for pred, label in zip(predictions, labels) if not pred and label)
    
    # Calculate metrics
    accuracy = (tp + tn) / len(labels) if len(labels) > 0 else 0
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1_score = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
    
    # False acceptance and rejection rates
    far = fp / (fp + tn) if (fp + tn) > 0 else 0
    frr = fn / (fn + tp) if (fn + tp) > 0 else 0
    
    # Separate scores by class
    same_scores = [s for s, l in zip(scores, labels) if l]
    diff_scores = [s for s, l in zip(scores, labels) if not l]
    
    return {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1_score': f1_score,
        'far': far,
        'frr': frr,
        'avg_same_score': np.mean(same_scores) if same_scores else 0,
        'avg_diff_score': np.mean(diff_scores) if diff_scores else 0,
        'score_separation': (np.mean(same_scores) - np.mean(diff_scores)) if same_scores and diff_scores else 0
    }

def analyze_comparison_results(results, mlp_threshold=0.95, bio_threshold=0.5):
    """
    Analyze and compare results from both hashing methods.
    
    Args:
        results (dict): Results from compare_hashing_methods_performance
        mlp_threshold (float): MLP-hash threshold
        bio_threshold (float): BioHash threshold
    
    Returns:
        dict: Analysis results
    """
    analysis = {
        'models': results['models'],
        'mlp_performance': {},
        'bio_performance': {},
        'comparison': {}
    }
    
    for model in results['models']:
        # Calculate MLP-hash performance
        mlp_scores = results['mlp_results'][model]['scores']
        mlp_labels = results['mlp_results'][model]['labels']
        mlp_times = results['mlp_results'][model]['times']
        
        if mlp_scores:
            analysis['mlp_performance'][model] = calculate_performance_metrics(
                mlp_scores, mlp_labels, mlp_threshold)
            analysis['mlp_performance'][model]['avg_time'] = np.mean(mlp_times)
        
        # Calculate BioHash performance
        bio_scores = results['bio_results'][model]['scores']
        bio_labels = results['bio_results'][model]['labels']
        bio_times = results['bio_results'][model]['times']
        
        if bio_scores:
            analysis['bio_performance'][model] = calculate_performance_metrics(
                bio_scores, bio_labels, bio_threshold)
            analysis['bio_performance'][model]['avg_time'] = np.mean(bio_times)
        
        # Template quality comparison
        if results['template_stats'][model]['mlp'] and results['template_stats'][model]['bio']:
            mlp_template_stats = results['template_stats'][model]['mlp'][0]
            bio_template_stats = results['template_stats'][model]['bio'][0]
            
            analysis['comparison'][model] = {
                'mlp_entropy': mlp_template_stats['entropy'],
                'bio_entropy': bio_template_stats['entropy'],
                'mlp_balance': abs(mlp_template_stats['ones_ratio'] - 0.5),
                'bio_balance': abs(bio_template_stats['ones_ratio'] - 0.5),
                'mlp_length': mlp_template_stats['length'],
                'bio_length': bio_template_stats['length']
            }
    
    return analysis

def print_comparison_report(analysis):
    """
    Print a comprehensive comparison report.
    
    Args:
        analysis (dict): Analysis results from analyze_comparison_results
    """
    print("\n" + "=" * 100)
    print("COMPREHENSIVE MLP-HASHING vs BIOHASHING COMPARISON REPORT")
    print("=" * 100)
    
    # Performance comparison table
    print("\n1. PERFORMANCE COMPARISON")
    print("-" * 80)
    print(f"{'Model':<12} {'Method':<8} {'Acc':<6} {'Prec':<6} {'Rec':<6} {'F1':<6} {'FAR':<6} {'FRR':<6} {'Sep':<6}")
    print("-" * 80)
    
    for model in analysis['models']:
        # MLP-hash performance
        if model in analysis['mlp_performance']:
            mlp = analysis['mlp_performance'][model]
            print(f"{model:<12} {'MLP':<8} {mlp['accuracy']:<6.3f} {mlp['precision']:<6.3f} "
                  f"{mlp['recall']:<6.3f} {mlp['f1_score']:<6.3f} {mlp['far']:<6.3f} "
                  f"{mlp['frr']:<6.3f} {mlp['score_separation']:<6.3f}")
        
        # BioHash performance
        if model in analysis['bio_performance']:
            bio = analysis['bio_performance'][model]
            print(f"{'':<12} {'BioHash':<8} {bio['accuracy']:<6.3f} {bio['precision']:<6.3f} "
                  f"{bio['recall']:<6.3f} {bio['f1_score']:<6.3f} {bio['far']:<6.3f} "
                  f"{bio['frr']:<6.3f} {bio['score_separation']:<6.3f}")
        
        print()  # Empty line between models
    
    # Template quality comparison
    print("\n2. TEMPLATE QUALITY COMPARISON")
    print("-" * 60)
    print(f"{'Model':<12} {'Method':<8} {'Length':<8} {'Entropy':<8} {'Balance':<8} {'Time (ms)'}")
    print("-" * 60)
    
    for model in analysis['models']:
        if model in analysis['comparison']:
            comp = analysis['comparison'][model]
            
            # MLP-hash template quality
            mlp_time = analysis['mlp_performance'][model]['avg_time'] * 1000 if model in analysis['mlp_performance'] else 0
            print(f"{model:<12} {'MLP':<8} {comp['mlp_length']:<8} {comp['mlp_entropy']:<8.3f} "
                  f"{comp['mlp_balance']:<8.3f} {mlp_time:<8.2f}")
            
            # BioHash template quality
            bio_time = analysis['bio_performance'][model]['avg_time'] * 1000 if model in analysis['bio_performance'] else 0
            print(f"{'':<12} {'BioHash':<8} {comp['bio_length']:<8} {comp['bio_entropy']:<8.3f} "
                  f"{comp['bio_balance']:<8.3f} {bio_time:<8.2f}")
            print()
    
    # Overall comparison summary
    print("\n3. OVERALL COMPARISON SUMMARY")
    print("-" * 50)
    
    # Calculate averages across all models
    mlp_avg_f1 = np.mean([perf['f1_score'] for perf in analysis['mlp_performance'].values()])
    bio_avg_f1 = np.mean([perf['f1_score'] for perf in analysis['bio_performance'].values()])
    
    mlp_avg_time = np.mean([perf['avg_time'] * 1000 for perf in analysis['mlp_performance'].values()])
    bio_avg_time = np.mean([perf['avg_time'] * 1000 for perf in analysis['bio_performance'].values()])
    
    print(f"Average F1-Score:")
    print(f"  MLP-Hashing: {mlp_avg_f1:.3f}")
    print(f"  BioHashing:  {bio_avg_f1:.3f}")
    print(f"  Winner: {'MLP-Hashing' if mlp_avg_f1 > bio_avg_f1 else 'BioHashing'}")
    
    print(f"\nAverage Processing Time:")
    print(f"  MLP-Hashing: {mlp_avg_time:.2f} ms")
    print(f"  BioHashing:  {bio_avg_time:.2f} ms") 
    print(f"  Faster: {'MLP-Hashing' if mlp_avg_time < bio_avg_time else 'BioHashing'}")
    
    print("\n" + "=" * 100)

def main():
    """
    Main function for comprehensive hashing method comparison.
    """
    print("Comprehensive MLP-Hashing vs BioHashing Comparison Tool")
    print("=" * 60)
    
    # Get available models
    available_models = get_available_models()
    
    if not available_models:
        print("No face recognition models available!")
        return
    
    print(f"Available models: {available_models}")
    
    # Create test pairs
    print("\nCreating test pairs for comparison...")
    same_pairs, diff_pairs = create_test_pairs_for_comparison()
    test_pairs = same_pairs + diff_pairs
    
    if not test_pairs:
        print("No test pairs could be created. Please check your dataset folder.")
        return
    
    print(f"Created {len(same_pairs)} same-person pairs and {len(diff_pairs)} different-person pairs")
    
    # Set thresholds
    mlp_threshold = 0.95
    bio_threshold = 0.5
    
    print(f"\nUsing thresholds:")
    print(f"  MLP-Hashing: {mlp_threshold}")
    print(f"  BioHashing: {bio_threshold}")
    
    # Perform comparison
    print(f"\nStarting performance comparison on {len(test_pairs)} pairs...")
    results = compare_hashing_methods_performance(test_pairs, available_models, mlp_threshold, bio_threshold)
    
    # Analyze results
    print("\nAnalyzing results...")
    analysis = analyze_comparison_results(results, mlp_threshold, bio_threshold)
    
    # Print comprehensive report
    print_comparison_report(analysis)
    
    # Save results
    with open('hash_comparison_results.pkl', 'wb') as f:
        pickle.dump({'results': results, 'analysis': analysis}, f)
    
    print(f"\nDetailed results saved to 'hash_comparison_results.pkl'")

if __name__ == "__main__":
    main()