"""
show_users.py (Updated Multi-Model Version)

Utility script to display all enrolled users and their reference IDs
from the protected enrollment databases across different models.
"""

import pickle
import os

def show_users_single_model(model_name):
    """
    Show users for a single model database.
    
    Args:
        model_name (str): Name of the model
    
    Returns:
        dict: User data if successful, None if error
    """
    db_filename = f'enroll_db_{model_name}.pkl'
    
    if not os.path.exists(db_filename):
        print(f"Database file '{db_filename}' not found!")
        return None
    
    try:
        with open(db_filename, 'rb') as f:
            protected_db = pickle.load(f)
        return protected_db
    except Exception as e:
        print(f"Error loading {db_filename}: {e}")
        return None

def show_users_all_models():
    """
    Show users for all available model databases.
    """
    # Find all available database files
    db_files = [f for f in os.listdir('.') if f.startswith('enroll_db_') and f.endswith('.pkl')]
    
    if not db_files:
        print("No enrollment database files found!")
        print("Expected files: enroll_db_<model_name>.pkl")
        return
    
    print("Multi-Model Enrollment Database Summary")
    print("=" * 60)
    
    # Extract model names from filenames
    models = [f.replace('enroll_db_', '').replace('.pkl', '') for f in db_files]
    models.sort()
    
    model_data = {}
    
    # Load data for each model
    for model_name in models:
        data = show_users_single_model(model_name)
        if data is not None:
            model_data[model_name] = data
    
    if not model_data:
        print("No valid databases could be loaded!")
        return
    
    # Display summary statistics
    print(f"\nFound {len(model_data)} model databases:")
    print("-" * 40)
    
    for model_name, data in model_data.items():
        total_users = len(data)
        total_templates = sum(len(templates) for templates in data.values())
        print(f"{model_name.upper()}:")
        print(f"  - Users: {total_users}")
        print(f"  - Templates: {total_templates}")
        print(f"  - Avg templates/user: {total_templates/total_users:.1f}")
    
    # Display detailed user information
    print(f"\nDetailed User Information:")
    print("=" * 60)
    
    # Get all unique users across models
    all_users = set()
    for data in model_data.values():
        all_users.update(data.keys())
    
    all_users = sorted(list(all_users))
    
    if not all_users:
        print("No users found in any database!")
        return
    
    # Display information for each user
    for user_id in all_users:
        print(f"\nUser: {user_id}")
        print("-" * 30)
        
        for model_name, data in model_data.items():
            if user_id in data:
                ref_ids = [ref for ref, _ in data[user_id]]
                print(f"  {model_name}: {len(ref_ids)} templates")
                print(f"    References: {ref_ids}")
            else:
                print(f"  {model_name}: Not enrolled")
    
    # Cross-model comparison
    print(f"\nCross-Model Enrollment Matrix:")
    print("=" * 60)
    
    # Create header
    header = f"{'User':<15}"
    for model_name in model_data.keys():
        header += f"{model_name.upper():<10}"
    print(header)
    print("-" * len(header))
    
    # Create matrix
    for user_id in all_users:
        row = f"{user_id:<15}"
        for model_name, data in model_data.items():
            count = len(data[user_id]) if user_id in data else 0
            row += f"{count:<10}"
        print(row)

def compare_model_coverage():
    """
    Compare which users are covered by which models.
    """
    # Find all available database files
    db_files = [f for f in os.listdir('.') if f.startswith('enroll_db_') and f.endswith('.pkl')]
    
    if len(db_files) < 2:
        print("Need at least 2 model databases for comparison!")
        return
    
    models = [f.replace('enroll_db_', '').replace('.pkl', '') for f in db_files]
    model_data = {}
    
    # Load all model data
    for model_name in models:
        data = show_users_single_model(model_name)
        if data is not None:
            model_data[model_name] = set(data.keys())
    
    if len(model_data) < 2:
        print("Need at least 2 valid model databases for comparison!")
        return
    
    print("Model Coverage Comparison")
    print("=" * 40)
    
    # Find common users across all models
    all_users = set.union(*model_data.values()) if model_data else set()
    common_users = set.intersection(*model_data.values()) if model_data else set()
    
    print(f"Total unique users: {len(all_users)}")
    print(f"Users in all models: {len(common_users)}")
    
    if common_users:
        print(f"Common users: {sorted(list(common_users))}")
    
    # Show users unique to each model
    print(f"\nModel-specific users:")
    for model_name, users in model_data.items():
        other_users = set.union(*[u for m, u in model_data.items() if m != model_name])
        unique_users = users - other_users
        if unique_users:
            print(f"  {model_name}: {sorted(list(unique_users))}")
        else:
            print(f"  {model_name}: None")

def main():
    print("MLP-Hashing Users")
    print("=" * 50)
    show_users_all_models()


if __name__ == "__main__":
    main()