"""
bio_hash.py   final btp

BioHashing algorithm implementation for biometric template protection.
This provides an alternative to MLP-hashing using random projections and user-specific tokens.

BioHashing combines biometric features with user-specific tokenized random numbers (TRNs)
to create protected binary templates that maintain recognition accuracy while providing
security, revocability, and diversity.
"""

import numpy as np
import hashlib
from typing import Optional, Tuple

class BioHashTransformer:
    """
    BioHashing transformer for biometric template protection.
    
    BioHashing works by:
    1. Generating user-specific random projection vectors from a seed
    2. Projecting biometric features onto these random vectors  
    3. Applying threshold-based binarization to create binary hash codes
    4. Using Hamming distance for matching in the protected domain
    """
    
    def __init__(self, 
                 hash_length: int = 1024,
                 seed_offset: int = 1000,
                 threshold_method: str = 'adaptive',
                 normalize_input: bool = True):
        """
        Initialize BioHashing parameters.
        
        Args:
            hash_length (int): Length of the binary hash code
            seed_offset (int): Offset for user seed generation
            threshold_method (str): Method for threshold selection ('adaptive', 'zero', 'mean')
            normalize_input (bool): Whether to normalize input features
        """
        self.hash_length = hash_length
        self.seed_offset = seed_offset
        self.threshold_method = threshold_method
        self.normalize_input = normalize_input
        
    def generate_user_seed(self, reference_id: str) -> int:
        """
        Generate user-specific seed from reference ID.
        
        Args:
            reference_id (str): User reference identifier
            
        Returns:
            int: User-specific seed for random projection generation
        """
        # Create deterministic seed from reference ID
        h = hashlib.sha256(reference_id.encode('utf-8')).hexdigest()
        seed = self.seed_offset + int(h, 16) % (10**8)
        return seed
    
    def generate_random_projections(self, feature_dim: int, reference_id: str) -> np.ndarray:
        """
        Generate user-specific random projection matrix.
        
        Args:
            feature_dim (int): Dimension of input biometric features
            reference_id (str): User reference identifier
            
        Returns:
            np.ndarray: Random projection matrix of shape (feature_dim, hash_length)
        """
        seed = self.generate_user_seed(reference_id)
        np.random.seed(seed)
        
        # Generate random projection matrix with Gaussian distribution
        # Each column is a random projection vector
        R = np.random.randn(feature_dim, self.hash_length)
        
        # Normalize each projection vector to unit length
        R = R / np.linalg.norm(R, axis=0, keepdims=True)
        
        return R
    
    def compute_threshold(self, projections: np.ndarray, method: str = None) -> float:
        """
        Compute binarization threshold for projections.
        
        Args:
            projections (np.ndarray): Projected feature values
            method (str): Threshold computation method
            
        Returns:
            float: Threshold value for binarization
        """
        if method is None:
            method = self.threshold_method
            
        if method == 'zero':
            return 0.0
        elif method == 'mean':
            return np.mean(projections)
        elif method == 'adaptive':
            # Use median to balance number of 1s and 0s
            return np.median(projections)
        else:
            raise ValueError(f"Unknown threshold method: {method}")
    
    def create_bio_hash(self, 
                       feature_vector: np.ndarray, 
                       reference_id: str) -> np.ndarray:
        """
        Create BioHash from biometric feature vector.
        
        Args:
            feature_vector (np.ndarray): Input biometric feature vector
            reference_id (str): User reference identifier
            
        Returns:
            np.ndarray: Binary BioHash code
        """
        # Normalize input features if requested
        if self.normalize_input:
            feature_vector = feature_vector / np.linalg.norm(feature_vector)
        
        # Generate user-specific random projection matrix
        R = self.generate_random_projections(len(feature_vector), reference_id)
        
        # Project features onto random vectors
        projections = feature_vector @ R  # Shape: (hash_length,)
        
        # Compute threshold for binarization
        threshold = self.compute_threshold(projections)
        
        # Binarize projections to create hash code
        bio_hash = (projections > threshold).astype(np.uint8)
        
        return bio_hash
    
    def hamming_distance(self, hash1: np.ndarray, hash2: np.ndarray) -> float:
        """
        Compute Hamming distance between two binary hash codes.
        
        Args:
            hash1 (np.ndarray): First binary hash code
            hash2 (np.ndarray): Second binary hash code
            
        Returns:
            float: Normalized Hamming distance (0 to 1)
        """
        if len(hash1) != len(hash2):
            raise ValueError("Hash codes must have the same length")
        
        return np.count_nonzero(hash1 != hash2) / len(hash1)
    
    def hamming_similarity(self, hash1: np.ndarray, hash2: np.ndarray) -> float:
        """
        Compute Hamming similarity between two binary hash codes.
        
        Args:
            hash1 (np.ndarray): First binary hash code  
            hash2 (np.ndarray): Second binary hash code
            
        Returns:
            float: Hamming similarity (0 to 1, where 1 is identical)
        """
        return 1.0 - self.hamming_distance(hash1, hash2)
    
    def verify_templates(self, 
                        hash1: np.ndarray, 
                        hash2: np.ndarray, 
                        threshold: float = 0.5) -> Tuple[bool, float]:
        """
        Verify if two BioHash templates belong to the same user.
        
        Args:
            hash1 (np.ndarray): First BioHash template
            hash2 (np.ndarray): Second BioHash template  
            threshold (float): Similarity threshold for verification
            
        Returns:
            Tuple[bool, float]: (verification_result, similarity_score)
        """
        similarity = self.hamming_similarity(hash1, hash2)
        is_match = similarity >= threshold
        return is_match, similarity
    
    def get_hash_statistics(self, bio_hash: np.ndarray) -> dict:
        """
        Compute statistics of a BioHash code.
        
        Args:
            bio_hash (np.ndarray): Binary BioHash code
            
        Returns:
            dict: Hash statistics including sparsity, entropy, etc.
        """
        ones_ratio = np.mean(bio_hash)
        zeros_ratio = 1.0 - ones_ratio
        
        # Shannon entropy (in bits)
        if ones_ratio > 0 and zeros_ratio > 0:
            entropy = -(ones_ratio * np.log2(ones_ratio) + zeros_ratio * np.log2(zeros_ratio))
        else:
            entropy = 0.0
            
        return {
            'length': len(bio_hash),
            'ones_count': int(np.sum(bio_hash)),
            'zeros_count': int(len(bio_hash) - np.sum(bio_hash)),
            'ones_ratio': ones_ratio,
            'zeros_ratio': zeros_ratio,
            'entropy': entropy,
            'is_balanced': abs(ones_ratio - 0.5) < 0.1  # Within 10% of balanced
        }
    
    def generate_multiple_templates(self, 
                                   feature_vector: np.ndarray,
                                   base_reference_id: str,
                                   num_templates: int = 3) -> list:
        """
        Generate multiple BioHash templates for the same user (for revocability).
        
        Args:
            feature_vector (np.ndarray): Input biometric feature vector
            base_reference_id (str): Base user reference identifier
            num_templates (int): Number of templates to generate
            
        Returns:
            list: List of BioHash templates with their reference IDs
        """
        templates = []
        
        for i in range(num_templates):
            # Create variant reference ID for diversity
            variant_ref_id = f"{base_reference_id}_variant_{i}"
            bio_hash = self.create_bio_hash(feature_vector, variant_ref_id)
            
            templates.append({
                'reference_id': variant_ref_id,
                'bio_hash': bio_hash,
                'statistics': self.get_hash_statistics(bio_hash)
            })
            
        return templates

# Utility functions for analysis and comparison

def analyze_bio_hash_quality(bio_hashes: list) -> dict:
    """
    Analyze the quality of BioHash codes.
    
    Args:
        bio_hashes (list): List of BioHash codes
        
    Returns:
        dict: Quality analysis results
    """
    if not bio_hashes:
        return {}
    
    entropies = []
    balance_scores = []
    
    for bio_hash in bio_hashes:
        transformer = BioHashTransformer()
        stats = transformer.get_hash_statistics(bio_hash)
        entropies.append(stats['entropy'])
        balance_scores.append(abs(stats['ones_ratio'] - 0.5))
    
    return {
        'average_entropy': np.mean(entropies),
        'entropy_std': np.std(entropies),
        'average_balance_score': np.mean(balance_scores),
        'balance_score_std': np.std(balance_scores),
        'min_entropy': np.min(entropies),
        'max_entropy': np.max(entropies),
        'well_balanced_ratio': np.mean([score < 0.1 for score in balance_scores])
    }

def compare_bio_hash_variants(feature_vector: np.ndarray, 
                             reference_id: str,
                             hash_lengths: list = [256, 512, 1024, 2048],
                             threshold_methods: list = ['zero', 'mean', 'adaptive']) -> dict:
    """
    Compare different BioHashing parameter configurations.
    
    Args:
        feature_vector (np.ndarray): Input biometric feature vector
        reference_id (str): User reference identifier
        hash_lengths (list): Different hash lengths to test
        threshold_methods (list): Different threshold methods to test
        
    Returns:
        dict: Comparison results across different configurations
    """
    results = {}
    
    for hash_length in hash_lengths:
        for threshold_method in threshold_methods:
            transformer = BioHashTransformer(
                hash_length=hash_length,
                threshold_method=threshold_method
            )
            
            bio_hash = transformer.create_bio_hash(feature_vector, reference_id)
            stats = transformer.get_hash_statistics(bio_hash)
            
            config_key = f"len_{hash_length}_{threshold_method}"
            results[config_key] = {
                'hash_length': hash_length,
                'threshold_method': threshold_method,
                'statistics': stats
            }
    
    return results

if __name__ == "__main__":
    # Example usage and testing
    print("BioHashing Algorithm Test")
    print("=" * 40)
    
    # Create sample biometric feature vector
    np.random.seed(42)
    sample_feature = np.random.randn(512)  # 512-dimensional feature
    sample_feature = sample_feature / np.linalg.norm(sample_feature)
    
    # Initialize BioHashing transformer
    transformer = BioHashTransformer(hash_length=1024)
    
    # Create BioHash
    reference_id = "user001_sample"
    bio_hash = transformer.create_bio_hash(sample_feature, reference_id)
    
    # Analyze hash statistics
    stats = transformer.get_hash_statistics(bio_hash)
    
    print(f"BioHash length: {stats['length']}")
    print(f"Ones ratio: {stats['ones_ratio']:.3f}")
    print(f"Entropy: {stats['entropy']:.3f} bits")
    print(f"Is balanced: {stats['is_balanced']}")
    
    # Test verification with same feature (should be identical)
    bio_hash2 = transformer.create_bio_hash(sample_feature, reference_id)
    is_match, similarity = transformer.verify_templates(bio_hash, bio_hash2)
    print(f"\nSelf-verification: {is_match}, Similarity: {similarity:.4f}")
    
    # Test with different feature (should be different)
    different_feature = np.random.randn(512)
    different_feature = different_feature / np.linalg.norm(different_feature)
    bio_hash3 = transformer.create_bio_hash(different_feature, reference_id)
    is_match, similarity = transformer.verify_templates(bio_hash, bio_hash3)
    print(f"Different feature: {is_match}, Similarity: {similarity:.4f}")
    
    print("\nBioHashing test completed successfully!")