"""
enroll_templates_biohash.py

Enrollment script for BioHashing-based face recognition system.
This creates BioHash protected templates alongside the existing MLP-hash system.
Works with the same face recognition models for direct comparison.
"""

import os
import pickle
from bio_hash import BioHashTransformer
from extract_embedding import extract_embedding, get_available_models

def enroll_templates_biohash(dataset_folder="dataset", models=None, hash_length=1024):
    """
    Enroll templates using BioHashing protection across multiple face recognition models.
    
    Args:
        dataset_folder (str): Folder containing enrollment images
        models (list): List of model names to use. If None, uses all available models.
        hash_length (int): Length of BioHash codes
    
    Returns:
        dict: Dictionary mapping model names to their BioHash databases
    """
    
    if models is None:
        models = get_available_models()
        print(f"Using available models: {models}")
    
    # Initialize the BioHash transformer
    biohash = BioHashTransformer(hash_length=hash_length)
    
    # Dictionary to hold results for each model
    model_databases = {}
    
    # Initialize databases for each model
    for model_name in models:
        model_databases[model_name] = {}
    
    # Process each image in the dataset
    if not os.path.exists(dataset_folder):
        print(f"Dataset folder '{dataset_folder}' not found!")
        return model_databases
    
    image_files = [f for f in os.listdir(dataset_folder) if f.endswith('.jpg')]
    
    if not image_files:
        print(f"No .jpg images found in '{dataset_folder}'!")
        return model_databases
    
    print(f"Processing {len(image_files)} images with {len(models)} models using BioHashing...")
    
    for fname in image_files:
        print(f"Processing: {fname}")
        
        # Derive user_id from filename
        name_parts = fname.split('_')
        user_id = "_".join(name_parts[:2])
        
        # Build full path to image
        image_path = os.path.join(dataset_folder, fname)
        
        # Use filename (without extension) as reference ID
        reference_id = fname.split('.')[0]
        
        # Extract embeddings using each model
        for model_name in models:
            try:
                print(f"  - Extracting {model_name} embedding for BioHashing...")
                
                # Extract embedding using current model
                emb = extract_embedding(image_path, model_name)
                
                # Create BioHash protected template
                protected = biohash.create_bio_hash(emb, reference_id)
                
                # Get statistics for analysis
                stats = biohash.get_hash_statistics(protected)
                
                # Initialize user list if needed
                if user_id not in model_databases[model_name]:
                    model_databases[model_name][user_id] = []
                
                # Store the protected template with metadata
                model_databases[model_name][user_id].append({
                    'reference_id': reference_id,
                    'bio_hash': protected,
                    'statistics': stats
                })
                
                print(f"    ✓ {model_name} BioHash created (entropy: {stats['entropy']:.3f}, balanced: {stats['is_balanced']})")
                
            except Exception as e:
                print(f"    ✗ Error with {model_name}: {e}")
                continue
    
    # Save databases for each model
    for model_name in models:
        if model_databases[model_name]:  # Only save if not empty
            db_filename = f'enroll_biohash_db_{model_name}.pkl'
            with open(db_filename, 'wb') as f:
                pickle.dump(model_databases[model_name], f)
            print(f"✓ {model_name} BioHash database saved to {db_filename}")
        else:
            print(f"✗ No BioHash data for {model_name}, skipping save")
    
    return model_databases

def analyze_biohash_quality(model_databases):
    """
    Analyze the quality of BioHash templates across models.
    
    Args:
        model_databases (dict): Dictionary of model databases
    """
    print("\n" + "="*60)
    print("BIOHASH QUALITY ANALYSIS")
    print("="*60)
    
    for model_name, db in model_databases.items():
        if not db:
            continue
            
        all_hashes = []
        all_entropies = []
        balanced_count = 0
        total_templates = 0
        
        for user_id, templates in db.items():
            for template_data in templates:
                stats = template_data['statistics']
                all_entropies.append(stats['entropy'])
                if stats['is_balanced']:
                    balanced_count += 1
                total_templates += 1
        
        if total_templates > 0:
            avg_entropy = sum(all_entropies) / len(all_entropies)
            balance_ratio = balanced_count / total_templates
            
            print(f"\n{model_name.upper()} BioHash Quality:")
            print(f"  - Total templates: {total_templates}")
            print(f"  - Average entropy: {avg_entropy:.3f} bits")
            print(f"  - Well-balanced ratio: {balance_ratio:.2%}")
            print(f"  - Entropy range: [{min(all_entropies):.3f}, {max(all_entropies):.3f}]")

def compare_model_statistics_biohash(model_databases):
    """
    Compare BioHash statistics across different models.
    
    Args:
        model_databases (dict): Dictionary of model databases
    """
    print("\n" + "="*60)
    print("BIOHASH MODEL COMPARISON STATISTICS")
    print("="*60)
    
    for model_name, db in model_databases.items():
        if not db:
            continue
            
        total_users = len(db)
        total_templates = sum(len(templates) for templates in db.values())
        avg_templates_per_user = total_templates / total_users if total_users > 0 else 0
        
        # Calculate quality metrics
        all_entropies = []
        ones_ratios = []
        
        for user_id, templates in db.items():
            for template_data in templates:
                stats = template_data['statistics']
                all_entropies.append(stats['entropy'])
                ones_ratios.append(stats['ones_ratio'])
        
        print(f"\n{model_name.upper()}:")
        print(f"  - Total users: {total_users}")
        print(f"  - Total templates: {total_templates}")
        print(f"  - Avg templates per user: {avg_templates_per_user:.2f}")
        
        if all_entropies:
            print(f"  - Avg entropy: {sum(all_entropies)/len(all_entropies):.3f} bits")
            print(f"  - Avg ones ratio: {sum(ones_ratios)/len(ones_ratios):.3f}")
        
        # Show user distribution
        print(f"  - User distribution:")
        for user_id, templates in db.items():
            print(f"    * {user_id}: {len(templates)} templates")

def main():
    print("Multi-Model Face Recognition Enrollment (BioHashing)")
    print("=" * 50)

    dataset_folder = "dataset"
    hash_length = 1024
    models = get_available_models()
    print(f"Dataset folder: {dataset_folder}")
    print(f"Hash length: {hash_length}")
    print(f"Models: {models}")

    model_databases = enroll_templates_biohash(dataset_folder, models, hash_length)

    analyze_biohash_quality(model_databases)
    compare_model_statistics_biohash(model_databases)
    print("BioHash enrollment completed!")


if __name__ == "__main__":
    main()