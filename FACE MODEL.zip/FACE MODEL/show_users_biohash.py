"""
show_users_biohash.py

Utility script to display enrolled users and their BioHash templates
from the BioHashing enrollment databases across different models.
Works alongside the existing MLP-hash user viewer.
"""

import pickle
import os
import numpy as np
from bio_hash import BioHashTransformer

def show_users_single_model_biohash(model_name):
    """
    Show users for a single BioHash model database.
    
    Args:
        model_name (str): Name of the model
    
    Returns:
        dict: User data if successful, None if error
    """
    db_filename = f'enroll_biohash_db_{model_name}.pkl'
    
    if not os.path.exists(db_filename):
        print(f"BioHash database file '{db_filename}' not found!")
        return None
    
    try:
        with open(db_filename, 'rb') as f:
            protected_db = pickle.load(f)
        return protected_db
    except Exception as e:
        print(f"Error loading {db_filename}: {e}")
        return None

def show_users_all_models_biohash():
    """
    Show users for all available BioHash model databases.
    """
    # Find all available BioHash database files
    db_files = [f for f in os.listdir('.') if f.startswith('enroll_biohash_db_') and f.endswith('.pkl')]
    
    if not db_files:
        print("No BioHash enrollment database files found!")
        print("Expected files: enroll_biohash_db_<model>.pkl")
        return
    
    print("Multi-Model BioHash Enrollment Database Summary")
    print("=" * 70)
    
    # Extract model names from filenames
    models = [f.replace('enroll_biohash_db_', '').replace('.pkl', '') for f in db_files]
    models.sort()
    
    model_data = {}
    
    # Load data for each model
    for model_name in models:
        data = show_users_single_model_biohash(model_name)
        if data is not None:
            model_data[model_name] = data
    
    if not model_data:
        print("No valid BioHash databases could be loaded!")
        return
    
    # Display summary statistics
    print(f"\nFound {len(model_data)} BioHash model databases:")
    print("-" * 50)
    
    for model_name, data in model_data.items():
        total_users = len(data)
        total_templates = sum(len(templates) for templates in data.values())
        
        # Calculate quality statistics
        all_entropies = []
        balanced_count = 0
        
        for user_id, templates in data.items():
            for template_data in templates:
                stats = template_data['statistics']
                all_entropies.append(stats['entropy'])
                if stats['is_balanced']:
                    balanced_count += 1
        
        avg_entropy = sum(all_entropies) / len(all_entropies) if all_entropies else 0
        balance_ratio = balanced_count / total_templates if total_templates > 0 else 0
        
        print(f"{model_name.upper()}:")
        print(f"  - Users: {total_users}")
        print(f"  - Templates: {total_templates}")
        print(f"  - Avg templates/user: {total_templates/total_users:.1f}")
        print(f"  - Avg entropy: {avg_entropy:.3f} bits")
        print(f"  - Well-balanced: {balance_ratio:.1%}")
    
    # Display detailed user information
    print(f"\nDetailed BioHash User Information:")
    print("=" * 70)
    
    # Get all unique users across models
    all_users = set()
    for data in model_data.values():
        all_users.update(data.keys())
    all_users = sorted(list(all_users))
    
    if not all_users:
        print("No users found in any BioHash database!")
        return
    
    # Display information for each user
    for user_id in all_users:
        print(f"\nUser: {user_id}")
        print("-" * 35)
        
        for model_name, data in model_data.items():
            if user_id in data:
                templates = data[user_id]
                ref_ids = [template_data['reference_id'] for template_data in templates]
                
                # Calculate average entropy for this user's templates
                entropies = [template_data['statistics']['entropy'] for template_data in templates]
                avg_entropy = sum(entropies) / len(entropies) if entropies else 0
                
                print(f"  {model_name}: {len(templates)} templates (avg entropy: {avg_entropy:.3f})")
                print(f"    References: {ref_ids}")
            else:
                print(f"  {model_name}: Not enrolled")
    
    # Cross-model comparison matrix
    print(f"\nBioHash Cross-Model Enrollment Matrix:")
    print("=" * 70)
    
    # Create header
    header = f"{'User':<15}"
    for model_name in model_data.keys():
        header += f"{model_name.upper():<12}"
    header += f"{'Avg Entropy':<12}"
    print(header)
    print("-" * len(header))
    
    # Create matrix
    for user_id in all_users:
        row = f"{user_id:<15}"
        user_entropies = []
        
        for model_name, data in model_data.items():
            if user_id in data:
                count = len(data[user_id])
                # Get average entropy for this user-model combination
                entropies = [template_data['statistics']['entropy'] for template_data in data[user_id]]
                avg_entropy = sum(entropies) / len(entropies) if entropies else 0
                user_entropies.append(avg_entropy)
                row += f"{count:<12}"
            else:
                row += f"{0:<12}"
        
        # Overall average entropy for this user
        overall_avg_entropy = sum(user_entropies) / len(user_entropies) if user_entropies else 0
        row += f"{overall_avg_entropy:<12.3f}"
        print(row)

def analyze_biohash_template_quality():
    """
    Analyze the quality of BioHash templates across all models.
    """
    # Find all available BioHash database files
    db_files = [f for f in os.listdir('.') if f.startswith('enroll_biohash_db_') and f.endswith('.pkl')]
    
    if not db_files:
        print("No BioHash enrollment database files found!")
        return
    
    print("BioHash Template Quality Analysis")
    print("=" * 50)
    
    models = [f.replace('enroll_biohash_db_', '').replace('.pkl', '') for f in db_files]
    
    overall_stats = {
        'total_templates': 0,
        'entropies': [],
        'ones_ratios': [],
        'lengths': [],
        'balanced_count': 0
    }
    
    model_stats = {}
    
    for model_name in models:
        data = show_users_single_model_biohash(model_name)
        if data is None:
            continue
        
        model_entropies = []
        model_ones_ratios = []
        model_balanced = 0
        model_total = 0
        
        for user_id, templates in data.items():
            for template_data in templates:
                stats = template_data['statistics']
                
                # Collect statistics
                model_entropies.append(stats['entropy'])
                model_ones_ratios.append(stats['ones_ratio'])
                overall_stats['entropies'].append(stats['entropy'])
                overall_stats['ones_ratios'].append(stats['ones_ratio'])
                overall_stats['lengths'].append(stats['length'])
                
                if stats['is_balanced']:
                    model_balanced += 1
                    overall_stats['balanced_count'] += 1
                
                model_total += 1
                overall_stats['total_templates'] += 1
        
        if model_total > 0:
            model_stats[model_name] = {
                'total': model_total,
                'avg_entropy': sum(model_entropies) / len(model_entropies),
                'entropy_std': np.std(model_entropies),
                'avg_ones_ratio': sum(model_ones_ratios) / len(model_ones_ratios),
                'balance_ratio': model_balanced / model_total,
                'entropy_range': (min(model_entropies), max(model_entropies))
            }
    
    # Print model-specific analysis
    print(f"\nModel-specific BioHash Quality:")
    print("-" * 40)
    print(f"{'Model':<12} {'Templates':<10} {'Avg Entropy':<12} {'Balance%':<9} {'Ones Ratio'}")
    print("-" * 60)
    
    for model_name, stats in model_stats.items():
        print(f"{model_name:<12} {stats['total']:<10} {stats['avg_entropy']:<12.3f} "
              f"{stats['balance_ratio']:<9.1%} {stats['avg_ones_ratio']:<.3f}")
    
    # Print overall analysis
    if overall_stats['total_templates'] > 0:
        avg_entropy = sum(overall_stats['entropies']) / len(overall_stats['entropies'])
        avg_ones_ratio = sum(overall_stats['ones_ratios']) / len(overall_stats['ones_ratios'])
        balance_ratio = overall_stats['balanced_count'] / overall_stats['total_templates']
        
        print(f"\nOverall BioHash Quality Analysis:")
        print("-" * 40)
        print(f"Total templates: {overall_stats['total_templates']}")
        print(f"Average entropy: {avg_entropy:.3f} bits (max: 1.000)")
        print(f"Average ones ratio: {avg_ones_ratio:.3f} (optimal: 0.500)")
        print(f"Well-balanced templates: {balance_ratio:.1%}")
        print(f"Template length: {overall_stats['lengths'][0] if overall_stats['lengths'] else 'N/A'} bits")
        print(f"Entropy range: [{min(overall_stats['entropies']):.3f}, {max(overall_stats['entropies']):.3f}]")
        
        # Quality assessment
        print(f"\nQuality Assessment:")
        if avg_entropy > 0.9:
            print("✓ Excellent entropy (high randomness)")
        elif avg_entropy > 0.8:
            print("✓ Good entropy")
        else:
            print("⚠ Low entropy (may indicate bias)")
        
        if abs(avg_ones_ratio - 0.5) < 0.05:
            print("✓ Well-balanced bit distribution")
        elif abs(avg_ones_ratio - 0.5) < 0.1:
            print("✓ Reasonably balanced bit distribution")
        else:
            print("⚠ Imbalanced bit distribution")

def compare_biohash_with_mlp():
    """
    Compare BioHash databases with MLP-hash databases if available.
    """
    # Check for both types of databases
    biohash_files = [f for f in os.listdir('.') if f.startswith('enroll_biohash_db_') and f.endswith('.pkl')]
    mlp_files = [f for f in os.listdir('.') if f.startswith('enroll_db_') and f.endswith('.pkl') and 'biohash' not in f]
    
    if not biohash_files and not mlp_files:
        print("No enrollment databases found!")
        return
    
    print("BioHash vs MLP-Hash Database Comparison")
    print("=" * 50)
    
    biohash_models = [f.replace('enroll_biohash_db_', '').replace('.pkl', '') for f in biohash_files]
    mlp_models = [f.replace('enroll_db_', '').replace('.pkl', '') for f in mlp_files]
    
    all_models = sorted(set(biohash_models + mlp_models))
    
    print(f"{'Model':<12} {'BioHash':<10} {'MLP-Hash':<10} {'Common Users':<12}")
    print("-" * 50)
    
    for model in all_models:
        biohash_users = set()
        mlp_users = set()
        
        # Get BioHash users
        if model in biohash_models:
            biohash_data = show_users_single_model_biohash(model)
            if biohash_data:
                biohash_users = set(biohash_data.keys())
        
        # Get MLP-hash users
        if model in mlp_models:
            mlp_db_file = f'enroll_db_{model}.pkl'
            if os.path.exists(mlp_db_file):
                try:
                    with open(mlp_db_file, 'rb') as f:
                        mlp_data = pickle.load(f)
                    mlp_users = set(mlp_data.keys())
                except:
                    pass
        
        common_users = len(biohash_users.intersection(mlp_users))
        
        print(f"{model:<12} {len(biohash_users):<10} {len(mlp_users):<10} {common_users:<12}")

def main():
    print("BioHashing Users")
    print("=" * 50)
    show_users_all_models_biohash()


if __name__ == "__main__":
    main()