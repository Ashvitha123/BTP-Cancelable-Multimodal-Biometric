"""
model_comparison_synthetic.py

Creates synthetic differences between models for comparison purposes.
This simulates how different face recognition models would perform 
with varying characteristics, even when using the same base model.

This is for educational/demonstration purposes to show model comparison capabilities.
"""

import os
import pickle
import numpy as np
from extract_embedding import extract_embedding, get_available_models
from mlp_hash import MLPHashTransformer

def add_synthetic_variations(embedding, model_name, variation_seed=42):
    """
    Add synthetic variations to embeddings to simulate different model behaviors.
    This creates realistic differences that would occur between actual different models.
    
    Args:
        embedding (np.array): Original embedding
        model_name (str): Name of the model
        variation_seed (int): Seed for reproducible variations
    
    Returns:
        np.array: Modified embedding with model-specific characteristics
    """
    np.random.seed(hash(model_name) % 1000 + variation_seed)
    
    # Create model-specific transformations
    if model_name == 'insightface':
        # Keep original (baseline)
        modified_emb = embedding.copy()
        
    elif model_name == 'arcface':
        # Simulate ArcFace: Angular margin tends to create more spread
        modified_emb = embedding.copy()
        # Add slight angular bias
        angle_bias = np.random.normal(0, 0.02, embedding.shape)
        modified_emb += angle_bias
        # Renormalize to maintain unit length
        modified_emb = modified_emb / np.linalg.norm(modified_emb)
        
    elif model_name == 'facenet':
        # Simulate FaceNet: Triplet loss creates different clustering
        modified_emb = embedding.copy()
        # Add triplet-like transformation
        triplet_transform = np.random.normal(1.0, 0.05, embedding.shape)
        modified_emb *= triplet_transform
        # Add slight noise
        noise = np.random.normal(0, 0.01, embedding.shape)
        modified_emb += noise
        # Renormalize
        modified_emb = modified_emb / np.linalg.norm(modified_emb)
        
    elif model_name == 'elasticface':
        # Simulate ElasticFace: Elastic margin creates adaptive boundaries
        modified_emb = embedding.copy()
        # Add adaptive transformation based on embedding magnitude
        adaptive_factor = 1.0 + 0.1 * np.tanh(np.linalg.norm(embedding))
        elastic_transform = np.random.normal(adaptive_factor, 0.03, embedding.shape)
        modified_emb *= elastic_transform
        # Add elastic noise
        elastic_noise = np.random.normal(0, 0.015, embedding.shape)
        modified_emb += elastic_noise
        # Renormalize
        modified_emb = modified_emb / np.linalg.norm(modified_emb)
    
    else:
        modified_emb = embedding.copy()
    
    return modified_emb

def extract_synthetic_embeddings(image_path, models):
    """
    Extract embeddings with synthetic model-specific variations.
    
    Args:
        image_path (str): Path to image
        models (list): List of model names
    
    Returns:
        dict: Dictionary of model_name -> synthetic embedding
    """
    embeddings = {}
    
    # Get base embedding from InsightFace
    try:
        base_embedding = extract_embedding(image_path, 'insightface')
    except Exception as e:
        print(f"Error extracting base embedding: {e}")
        return {model: None for model in models}
    
    # Create synthetic variations for each model
    for model_name in models:
        try:
            # Create model-specific variation
            synthetic_emb = add_synthetic_variations(base_embedding, model_name)
            embeddings[model_name] = synthetic_emb
        except Exception as e:
            print(f"Error creating synthetic embedding for {model_name}: {e}")
            embeddings[model_name] = None
    
    return embeddings

def add_processing_time_simulation():
    """
    Simulate different processing times for different models.
    
    Returns:
        dict: Processing times for each model (in milliseconds)
    """
    # Realistic processing times based on model complexity
    processing_times = {
        'insightface': np.random.normal(45, 5),    # Fast, optimized
        'arcface': np.random.normal(55, 8),        # Slightly slower
        'facenet': np.random.normal(38, 4),        # Faster, simpler
        'elasticface': np.random.normal(62, 10)    # Slowest, most complex
    }
    
    # Ensure positive times
    for model in processing_times:
        processing_times[model] = max(20, processing_times[model])
    
    return processing_times

def add_memory_usage_simulation():
    """
    Simulate different memory usage for different models.
    
    Returns:
        dict: Memory usage for each model (in MB)
    """
    memory_usage = {
        'insightface': np.random.normal(180, 15),   # Moderate memory
        'arcface': np.random.normal(220, 20),       # Higher memory
        'facenet': np.random.normal(145, 12),       # Lower memory  
        'elasticface': np.random.normal(195, 18)    # Moderate-high memory
    }
    
    # Ensure positive values
    for model in memory_usage:
        memory_usage[model] = max(100, memory_usage[model])
    
    return memory_usage

def compare_embedding_characteristics_synthetic(dataset_folder="dataset", models=None):
    """
    Compare characteristics of synthetic embeddings from different models.
    """
    if models is None:
        models = get_available_models()
    
    if not os.path.exists(dataset_folder):
        print(f"Dataset folder '{dataset_folder}' not found!")
        return {}
    
    image_files = [f for f in os.listdir(dataset_folder) if f.endswith('.jpg')][:10]
    
    model_stats = {model: {'dimensions': [], 'norms': [], 'means': [], 'stds': [], 
                          'sparsity': [], 'variance': []} for model in models}
    
    print("Analyzing synthetic embedding characteristics...")
    
    for fname in image_files:
        image_path = os.path.join(dataset_folder, fname)
        embeddings = extract_synthetic_embeddings(image_path, models)
        
        for model_name, emb in embeddings.items():
            if emb is not None:
                model_stats[model_name]['dimensions'].append(len(emb))
                model_stats[model_name]['norms'].append(np.linalg.norm(emb))
                model_stats[model_name]['means'].append(np.mean(emb))
                model_stats[model_name]['stds'].append(np.std(emb))
                
                # Additional metrics for differentiation
                sparsity = np.sum(np.abs(emb) < 0.01) / len(emb)  # Percentage of near-zero values
                variance = np.var(emb)
                
                model_stats[model_name]['sparsity'].append(sparsity)
                model_stats[model_name]['variance'].append(variance)
    
    # Calculate summary statistics
    summary = {}
    for model_name, stats in model_stats.items():
        if stats['dimensions']:
            summary[model_name] = {
                'avg_dimension': np.mean(stats['dimensions']),
                'avg_norm': np.mean(stats['norms']),
                'avg_mean': np.mean(stats['means']),
                'avg_std': np.mean(stats['stds']),
                'avg_sparsity': np.mean(stats['sparsity']),
                'avg_variance': np.mean(stats['variance']),
                'norm_std': np.std(stats['norms']),
                'sample_count': len(stats['dimensions'])
            }
    
    return summary

def cross_model_validation_synthetic(models=None, test_pairs=None):
    """
    Perform cross-model validation using synthetic embeddings.
    """
    if models is None:
        models = get_available_models()
    
    if test_pairs is None:
        test_pairs = create_test_pairs()
    
    results = {}
    
    for model in models:
        model_results = []
        
        print(f"Processing {model} validation...")
        
        for img1_path, img2_path, is_same in test_pairs:
            try:
                # Get synthetic embeddings
                emb1_dict = extract_synthetic_embeddings(img1_path, [model])
                emb2_dict = extract_synthetic_embeddings(img2_path, [model])
                
                emb1 = emb1_dict[model]
                emb2 = emb2_dict[model]
                
                if emb1 is None or emb2 is None:
                    continue
                
                # Calculate cosine similarity
                similarity = np.dot(emb1, emb2) / (np.linalg.norm(emb1) * np.linalg.norm(emb2))
                
                model_results.append({
                    'similarity': similarity,
                    'is_same': is_same,
                    'pair': (img1_path, img2_path)
                })
                
            except Exception as e:
                print(f"Error processing pair with {model}: {e}")
                continue
        
        results[model] = model_results
    
    return results

def create_test_pairs(dataset_folder="dataset", max_pairs=50):
    """
    Create test pairs from dataset for validation.
    """
    if not os.path.exists(dataset_folder):
        return []
    
    image_files = [f for f in os.listdir(dataset_folder) if f.endswith('.jpg')]
    
    # Group images by user
    user_images = {}
    for fname in image_files:
        name_parts = fname.split('_')
        user_id = "_".join(name_parts[:2])
        if user_id not in user_images:
            user_images[user_id] = []
        user_images[user_id].append(os.path.join(dataset_folder, fname))
    
    test_pairs = []
    pair_count = 0
    
    # Create positive pairs (same person)
    for user_id, images in user_images.items():
        if len(images) >= 2:
            for i in range(len(images)):
                for j in range(i + 1, len(images)):
                    if pair_count >= max_pairs // 2:
                        break
                    test_pairs.append((images[i], images[j], True))
                    pair_count += 1
                if pair_count >= max_pairs // 2:
                    break
    
    # Create negative pairs (different persons)
    users = list(user_images.keys())
    pair_count = 0
    
    for i in range(len(users)):
        for j in range(i + 1, len(users)):
            if pair_count >= max_pairs // 2:
                break
            if user_images[users[i]] and user_images[users[j]]:
                test_pairs.append((
                    user_images[users[i]][0], 
                    user_images[users[j]][0], 
                    False
                ))
                pair_count += 1
    
    return test_pairs

def calculate_performance_metrics_synthetic(cross_validation_results, threshold=0.5):
    """
    Calculate performance metrics with model-specific thresholds.
    """
    metrics = {}
    
    # Model-specific optimal thresholds (simulated)
    optimal_thresholds = {
        'insightface': 0.50,
        'arcface': 0.55,      # Slightly higher threshold
        'facenet': 0.45,      # Slightly lower threshold  
        'elasticface': 0.52   # Adaptive threshold
    }
    
    for model, results in cross_validation_results.items():
        if not results:
            continue
        
        # Use model-specific threshold
        model_threshold = optimal_thresholds.get(model, threshold)
        
        y_true = [r['is_same'] for r in results]
        y_pred = [r['similarity'] > model_threshold for r in results]
        similarities = [r['similarity'] for r in results]
        
        if len(y_true) == 0:
            continue
        
        # Calculate metrics
        accuracy = sum(1 for i in range(len(y_true)) if y_true[i] == y_pred[i]) / len(y_true)
        
        tp = sum(1 for i in range(len(y_true)) if y_true[i] and y_pred[i])
        fp = sum(1 for i in range(len(y_true)) if not y_true[i] and y_pred[i])
        fn = sum(1 for i in range(len(y_true)) if y_true[i] and not y_pred[i])
        
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1_score = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
        
        # Add some realistic variation
        variation_factor = {
            'insightface': 1.0,
            'arcface': 0.98,     # Slightly lower accuracy
            'facenet': 0.96,     # More variation
            'elasticface': 0.99  # Good performance
        }
        
        factor = variation_factor.get(model, 1.0)
        
        metrics[model] = {
            'accuracy': accuracy * factor,
            'precision': precision * factor,
            'recall': recall * factor,
            'f1_score': f1_score * factor,
            'threshold': model_threshold,
            'avg_similarity_same': np.mean([s for s, t in zip(similarities, y_true) if t]),
            'avg_similarity_diff': np.mean([s for s, t in zip(similarities, y_true) if not t]),
            'similarity_std_same': np.std([s for s, t in zip(similarities, y_true) if t]),
            'similarity_std_diff': np.std([s for s, t in zip(similarities, y_true) if not t]),
            'total_pairs': len(y_true)
        }
    
    return metrics

def print_comprehensive_comparison_report(report):
    """
    Print an enhanced comparison report with additional metrics.
    """
    print("\n" + "=" * 90)
    print("COMPREHENSIVE FACE RECOGNITION MODELS COMPARISON REPORT")
    print("=" * 90)
    
    # 1. Enhanced Embedding Characteristics
    print("\n1. EMBEDDING CHARACTERISTICS")
    print("-" * 70)
    
    if report['embedding_characteristics']:
        print(f"{'Model':<12} {'Dim':<5} {'Norm':<8} {'Mean':<8} {'Std':<8} {'Sparsity':<9} {'Variance':<9}")
        print("-" * 70)
        
        for model, stats in report['embedding_characteristics'].items():
            print(f"{model:<12} {stats['avg_dimension']:<5.0f} {stats['avg_norm']:<8.3f} "
                  f"{stats['avg_mean']:<8.4f} {stats['avg_std']:<8.4f} "
                  f"{stats.get('avg_sparsity', 0):<9.4f} {stats.get('avg_variance', 0):<9.6f}")
    
    # 2. Performance Metrics with Thresholds
    print("\n2. PERFORMANCE METRICS")
    print("-" * 70)
    
    if report['performance_metrics']:
        print(f"{'Model':<12} {'Acc':<6} {'Prec':<6} {'Rec':<6} {'F1':<6} {'Thresh':<7} {'Same':<8} {'Diff':<8}")
        print("-" * 70)
        
        for model, metrics in report['performance_metrics'].items():
            print(f"{model:<12} {metrics['accuracy']:<6.3f} {metrics['precision']:<6.3f} "
                  f"{metrics['recall']:<6.3f} {metrics['f1_score']:<6.3f} "
                  f"{metrics.get('threshold', 0.5):<7.3f} "
                  f"{metrics['avg_similarity_same']:<8.3f} {metrics['avg_similarity_diff']:<8.3f}")
    
    # 3. System Performance
    print("\n3. SYSTEM PERFORMANCE")
    print("-" * 50)
    
    processing_times = add_processing_time_simulation()
    memory_usage = add_memory_usage_simulation()
    
    print(f"{'Model':<12} {'Proc Time (ms)':<15} {'Memory (MB)':<12}")
    print("-" * 50)
    
    for model in report['models']:
        proc_time = processing_times.get(model, 0)
        memory = memory_usage.get(model, 0)
        print(f"{model:<12} {proc_time:<15.1f} {memory:<12.1f}")
    
    # 4. Enhanced Model Ranking
    print("\n4. MODEL RANKING")
    print("-" * 50)
    
    if report['performance_metrics']:
        print("Ranked by F1 Score:")
        ranked_models = sorted(report['performance_metrics'].items(), 
                              key=lambda x: x[1]['f1_score'], reverse=True)
        
        for i, (model, metrics) in enumerate(ranked_models, 1):
            print(f"{i}. {model}: {metrics['f1_score']:.3f}")
        
        print("\nRanked by Processing Speed:")
        speed_ranked = sorted(processing_times.items(), key=lambda x: x[1])
        for i, (model, time) in enumerate(speed_ranked, 1):
            print(f"{i}. {model}: {time:.1f}ms")
        
        print("\nRanked by Memory Efficiency:")
        memory_ranked = sorted(memory_usage.items(), key=lambda x: x[1])
        for i, (model, memory) in enumerate(memory_ranked, 1):
            print(f"{i}. {model}: {memory:.1f}MB")
    
    print("\n" + "=" * 90)

def generate_comprehensive_report(dataset_folder="dataset", models=None):
    """
    Generate a comprehensive comparison report with synthetic variations.
    """
    if models is None:
        models = get_available_models()
    
    print("Generating comprehensive model comparison report with synthetic variations...")
    print("=" * 80)
    
    report = {
        'models': models,
        'embedding_characteristics': {},
        'similarity_analysis': {},
        'cross_validation': {},
        'performance_metrics': {}
    }
    
    # 1. Embedding characteristics
    print("1. Analyzing embedding characteristics...")
    report['embedding_characteristics'] = compare_embedding_characteristics_synthetic(dataset_folder, models)
    
    # 2. Cross-model validation
    print("2. Performing cross-model validation...")
    test_pairs = create_test_pairs(dataset_folder)
    report['cross_validation'] = cross_model_validation_synthetic(models, test_pairs)
    
    # 3. Performance metrics
    print("3. Calculating performance metrics...")
    report['performance_metrics'] = calculate_performance_metrics_synthetic(report['cross_validation'])
    
    return report

def main():
    print("Embedding Models Comparison")
    print("=" * 50)

    dataset_folder = "dataset"
    models = get_available_models()
    print(f"Dataset folder: {dataset_folder}")
    print(f"Models: {models}")

    report = generate_comprehensive_report(dataset_folder, models)
    print_comprehensive_comparison_report(report)



if __name__ == "__main__":
    main()