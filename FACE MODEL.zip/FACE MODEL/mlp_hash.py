

import numpy as np
import hashlib

class MLPHashTransformer:
    def __init__(self, mlp_length=[1024, 1024, 1024], seed_offset=0):
        self.mlp_length = mlp_length
        self.seed_offset = seed_offset

    def generate_user_seed(self, reference_id):
        h = hashlib.sha256(reference_id.encode('utf-8')).hexdigest()
        seed = self.seed_offset + int(h, 16) % (10**8)
        return seed

    def relu(self, x):
        return np.maximum(0, x)

    def gram_schmidt(self, M):
        Q, _ = np.linalg.qr(M)
        return Q

    def create_mlp_hash(self, feature_vector, reference_id):
        seed = self.generate_user_seed(reference_id)
        np.random.seed(seed)
        Γ = feature_vector.copy()
        for L in self.mlp_length:
            M = np.random.randn(Γ.size, L)
            M_orth = self.gram_schmidt(M)
            Γ = self.relu(Γ @ M_orth)
        τ = np.mean(Γ)
        P = (Γ > τ).astype(np.uint8)
        return P 

      
