"""
verify_face_biohash.py

Verification script for BioHashing-based face recognition system.
This script verifies probe faces against BioHash protected templates.
Works alongside the existing MLP-hash verification system.
"""

import pickle
import os
import numpy as np
from bio_hash import BioHashTransformer
from extract_embedding import extract_embedding, get_available_models

def verify_single_model_biohash(probe_img_path, claimed_user, model_name, threshold=0.5, hash_length=1024):
    """
    Verify face using BioHashing with a single model.
    
    Args:
        probe_img_path (str): Path to probe image
        claimed_user (str): Claimed user ID
        model_name (str): Model to use for verification
        threshold (float): Hamming similarity threshold for acceptance
        hash_length (int): Length of BioHash codes
    
    Returns:
        dict: Verification results including scores and decision
    """
    # Initialize BioHash transformer
    biohash = BioHashTransformer(hash_length=hash_length)
    
    # Load the enrolled BioHash database for this model
    db_filename = f'enroll_biohash_db_{model_name}.pkl'
    
    if not os.path.exists(db_filename):
        return {
            'error': f"BioHash database file '{db_filename}' not found",
            'model': model_name,
            'success': False
        }
    
    try:
        with open(db_filename, 'rb') as f:
            protected_db = pickle.load(f)
    except Exception as e:
        return {
            'error': f"Error loading BioHash database: {e}",
            'model': model_name,
            'success': False
        }
    
    # Check if claimed user exists in database
    if claimed_user not in protected_db:
        return {
            'error': f"User '{claimed_user}' not found in {model_name} BioHash database",
            'model': model_name,
            'success': False,
            'available_users': list(protected_db.keys())
        }
    
    try:
        # Extract probe embedding
        probe_emb = extract_embedding(probe_img_path, model_name)
        
        # Create probe reference ID
        probe_reference = os.path.splitext(os.path.basename(probe_img_path))[0]
        
        # Create BioHash protected template for probe
        probe_biohash = biohash.create_bio_hash(probe_emb, probe_reference)
        
        # Compare against enrolled BioHash templates
        scores = []
        reference_ids = []
        
        for template_data in protected_db[claimed_user]:
            enrolled_biohash = template_data['bio_hash']
            ref_id = template_data['reference_id']
            
            # Calculate Hamming similarity
            similarity = biohash.hamming_similarity(probe_biohash, enrolled_biohash)
            scores.append(similarity)
            reference_ids.append(ref_id)
        
        # Calculate statistics
        max_score = max(scores) if scores else 0
        avg_score = np.mean(scores) if scores else 0
        min_score = min(scores) if scores else 0
        
        # Make decision based on threshold
        authentication_success = max_score >= threshold
        
        # Get probe BioHash statistics
        probe_stats = biohash.get_hash_statistics(probe_biohash)
        
        return {
            'model': model_name,
            'success': True,
            'scores': scores,
            'reference_ids': reference_ids,
            'max_score': max_score,
            'avg_score': avg_score,
            'min_score': min_score,
            'threshold': threshold,
            'authentication_success': authentication_success,
            'num_templates': len(scores),
            'probe_statistics': probe_stats
        }
        
    except Exception as e:
        return {
            'error': f"Error during BioHash verification: {e}",
            'model': model_name,
            'success': False
        }

def verify_multi_model_biohash(probe_img_path, claimed_user, models=None, threshold=0.5, hash_length=1024):
    """
    Verify face using BioHashing across multiple models and compare results.
    
    Args:
        probe_img_path (str): Path to probe image
        claimed_user (str): Claimed user ID
        models (list): List of models to use. If None, uses all available models.
        threshold (float): Hamming similarity threshold for acceptance
        hash_length (int): Length of BioHash codes
    
    Returns:
        dict: Comprehensive verification results across all models
    """
    if models is None:
        models = get_available_models()
    
    results = {}
    
    print(f"Verifying '{probe_img_path}' against user '{claimed_user}' using BioHashing with {len(models)} models...")
    print("=" * 80)
    
    for model_name in models:
        print(f"\nTesting {model_name.upper()} with BioHashing...")
        result = verify_single_model_biohash(probe_img_path, claimed_user, model_name, threshold, hash_length)
        results[model_name] = result
        
        if result['success']:
            print(f"  ✓ Authentication: {'SUCCESS' if result['authentication_success'] else 'FAILED'}")
            print(f"  ✓ Max Hamming Similarity: {result['max_score']:.4f}")
            print(f"  ✓ Avg Hamming Similarity: {result['avg_score']:.4f}")
            print(f"  ✓ Templates: {result['num_templates']}")
            print(f"  ✓ Probe Hash Entropy: {result['probe_statistics']['entropy']:.3f} bits")
        else:
            print(f"  ✗ Error: {result['error']}")
    
    return results

def compare_verification_results_biohash(results):
    """
    Compare and analyze BioHash verification results across models.
    
    Args:
        results (dict): Verification results from multiple models
    """
    print(f"\n{'='*80}")
    print("BIOHASH VERIFICATION RESULTS COMPARISON")
    print(f"{'='*80}")
    
    # Table header
    print(f"{'Model':<12} {'Auth':<6} {'Max Sim':<8} {'Avg Sim':<8} {'Templates':<10} {'Entropy':<8} {'Status'}")
    print("-" * 80)
    
    successful_models = []
    failed_models = []
    
    for model_name, result in results.items():
        if result['success']:
            auth_status = "PASS" if result['authentication_success'] else "FAIL"
            entropy = result['probe_statistics']['entropy']
            
            print(f"{model_name:<12} {auth_status:<6} {result['max_score']:<8.4f} "
                  f"{result['avg_score']:<8.4f} {result['num_templates']:<10} "
                  f"{entropy:<8.3f} {'OK'}")
            
            if result['authentication_success']:
                successful_models.append((model_name, result['max_score']))
            else:
                failed_models.append(model_name)
        else:
            print(f"{model_name:<12} {'ERROR':<6} {'-':<8} {'-':<8} {'-':<10} {'-':<8} {'FAIL'}")
            failed_models.append(model_name)
    
    # Summary
    print(f"\n{'='*80}")
    print("BIOHASH VERIFICATION SUMMARY")
    print(f"{'='*80}")
    
    if successful_models:
        print(f"✓ Models that authenticated successfully:")
        for model, score in successful_models:
            print(f"  - {model}: {score:.4f} Hamming similarity")
    
    if failed_models:
        print(f"✗ Models that failed authentication:")
        for model in failed_models:
            print(f"  - {model}")
    
    # Best performing model
    if successful_models:
        best_model, best_score = max(successful_models, key=lambda x: x[1])
        print(f"\n🏆 Best performing model: {best_model} (Hamming similarity: {best_score:.4f})")

def main():
    print("BioHashing Verification")
    print("=" * 50)

    probe = input("Enter probe image path: ").strip()
    user  = input("Enter claimed user ID: ").strip()

    threshold  = 0.5
    hash_length = 1024
    models     = get_available_models()
    print(f"Threshold: {threshold}, Hash length: {hash_length}")
    print(f"Models: {models}")

    results = verify_multi_model_biohash(probe, user, models, threshold, hash_length)
    compare_verification_results_biohash(results)


if __name__ == "__main__":
    main()