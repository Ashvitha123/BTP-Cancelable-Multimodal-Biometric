"""
enroll_templates.py (Updated Multi-Model Version)

This script enrolls face images from the dataset folder by:
1. Extracting normalized embeddings for each face using multiple models.
2. Applying an MLP-based hash transform to protect the embedding.
3. Grouping protected templates per user and model, saving to separate databases.

This allows for comparison of different face recognition models.
"""

import os
import pickle

from mlp_hash import MLPHashTransformer
from extract_embedding import extract_embedding, get_available_models

def enroll_templates_multi_model(dataset_folder="dataset", models=None):
    """
    Enroll templates using multiple face recognition models.
    
    Args:
        dataset_folder (str): Folder containing enrollment images
        models (list): List of model names to use. If None, uses all available models.
    
    Returns:
        dict: Dictionary mapping model names to their respective databases
    """
    
    if models is None:
        models = get_available_models()
        print(f"Using available models: {models}")
    
    # Initialize the MLP hash transformer
    mlphash = MLPHashTransformer()
    
    # Dictionary to hold results for each model
    model_databases = {}
    
    # Initialize databases for each model
    for model_name in models:
        model_databases[model_name] = {}
    
    # Process each image in the dataset
    if not os.path.exists(dataset_folder):
        print(f"Dataset folder '{dataset_folder}' not found!")
        return model_databases
    
    image_files = [f for f in os.listdir(dataset_folder) if f.endswith('.jpg')]
    
    if not image_files:
        print(f"No .jpg images found in '{dataset_folder}'!")
        return model_databases
    
    print(f"Processing {len(image_files)} images with {len(models)} models...")
    
    for fname in image_files:
        print(f"Processing: {fname}")
        
        # Derive user_id from filename
        name_parts = fname.split('_')
        user_id = "_".join(name_parts[:2])
        
        # Build full path to image
        image_path = os.path.join(dataset_folder, fname)
        
        # Use filename (without extension) as reference ID
        reference_id = fname.split('.')[0]
        
        # Extract embeddings using each model
        for model_name in models:
            try:
                print(f"  - Extracting {model_name} embedding...")
                
                # Extract embedding using current model
                emb = extract_embedding(image_path, model_name)
                
                # Create protected template
                protected = mlphash.create_mlp_hash(emb, reference_id)
                
                # Initialize user list if needed
                if user_id not in model_databases[model_name]:
                    model_databases[model_name][user_id] = []
                
                # Store the protected template
                model_databases[model_name][user_id].append((reference_id, protected))
                
                print(f"    ✓ {model_name} embedding extracted and protected")
                
            except Exception as e:
                print(f"    ✗ Error with {model_name}: {e}")
                continue
    
    # Save databases for each model
    for model_name in models:
        if model_databases[model_name]:  # Only save if not empty
            db_filename = f'enroll_db_{model_name}.pkl'
            with open(db_filename, 'wb') as f:
                pickle.dump(model_databases[model_name], f)
            print(f"✓ {model_name} database saved to {db_filename}")
        else:
            print(f"✗ No data for {model_name}, skipping save")
    
    return model_databases

def compare_model_statistics(model_databases):
    """
    Compare statistics across different models.
    
    Args:
        model_databases (dict): Dictionary of model databases
    """
    print("\n" + "="*60)
    print("MODEL COMPARISON STATISTICS")
    print("="*60)
    
    for model_name, db in model_databases.items():
        if not db:
            continue
            
        total_users = len(db)
        total_templates = sum(len(templates) for templates in db.values())
        avg_templates_per_user = total_templates / total_users if total_users > 0 else 0
        
        print(f"\n{model_name.upper()}:")
        print(f"  - Total users: {total_users}")
        print(f"  - Total templates: {total_templates}")
        print(f"  - Avg templates per user: {avg_templates_per_user:.2f}")
        
        # Show user distribution
        print(f"  - User distribution:")
        for user_id, templates in db.items():
            print(f"    * {user_id}: {len(templates)} templates")



def main():
    print("Multi-Model Face Recognition Enrollment (MLP-Hashing)")
    print("=" * 50)

    # Use default values
    dataset_folder = "dataset"
    models = get_available_models()  # all models
    print(f"Dataset folder: {dataset_folder}")
    print(f"Models: {models}")

    model_databases = enroll_templates_multi_model(dataset_folder, models)

    compare_model_statistics(model_databases)
    print("Enrollment completed!")

if __name__ == "__main__":
    main()